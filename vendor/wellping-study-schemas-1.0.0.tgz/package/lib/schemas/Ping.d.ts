import * as z from "zod";
export declare const PingSchema: z.ZodObject<{
    /**
     * The notification ID.
     *
     * Currently, it is just the concatenation `streamName` and the index of (the
     * number of) this particular stream type. For example, the second `"wellbeing"`
     * stream the user received has ID `wellbeing2`.
     */
    id: z.ZodString;
    /**
     * The time this ping was sent to the user's phone (through system notification).
     */
    notificationTime: z.ZodDate;
    /**
     * The time the user clicked the button (in the app) to start the ping.
     */
    startTime: z.ZodDate;
    /**
     * The time the user finished the ping. If the user did not finish the ping
     * (i.e., they leave the app in the middle of a ping and never come back
     * before the ping expired), `endTime` will be `null`.
     */
    endTime: z.ZodNullable<z.ZodDate>;
    /**
     * The timezone offset for the `notificationTime`, `startTime`, and `endTime`.
     *
     * Learn more about this value here:
     * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Date/getTimezoneOffset.
     */
    tzOffset: z.ZodNumber;
    /**
     * The name of the stream type of this ping.
     */
    streamName: z.ZodString;
}, "strip", z.ZodTypeAny, {
    id: string;
    notificationTime: Date;
    startTime: Date;
    endTime: Date | null;
    tzOffset: number;
    streamName: string;
}, {
    id: string;
    notificationTime: Date;
    startTime: Date;
    endTime: Date | null;
    tzOffset: number;
    streamName: string;
}>;
