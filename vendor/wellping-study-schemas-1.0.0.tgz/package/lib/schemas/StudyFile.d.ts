import * as z from "zod";
export declare const WeekStartsOnSchema: z.ZodUnion<[z.ZodLiteral<0>, z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>, z.ZodLiteral<5>, z.ZodLiteral<6>]>;
export declare const FirebaseConfigSchema: z.ZodRecord<z.ZodString, z.ZodString>;
export declare const FirebaseServerConfigSchema: z.ZodObject<{
    /**
     * The Firebase config object for the study.
     *
     * See https://firebase.google.com/docs/web/setup#config-object
     */
    config: z.ZodRecord<z.ZodString, z.ZodString>;
}, "strip", z.ZodTypeAny, {
    config: Record<string, string>;
}, {
    config: Record<string, string>;
}>;
export declare const BeiweServerConfigSchema: z.ZodObject<{
    /**
     * The server URL of Beiwe backend for the study.
     *
     * Example: `"https://beiwe.example.com/"`
     */
    serverUrl: z.ZodString;
}, "strip", z.ZodTypeAny, {
    serverUrl: string;
}, {
    serverUrl: string;
}>;
export declare const PlaceholderReplacementValueTreatmentOptionsSchema: z.ZodObject<{
    decapitalizeFirstCharacter: z.ZodOptional<z.ZodObject<{
        /**
         * The first character of the answer data replacing the placeholder will be
         * decapitalized.
         *
         * For example, if the answer is `"Friends"` and the variable is `"CONTACT"`,
         * and `decapitalizeFirstCharacter.enabled` is `true`,
         * and `decapitalizeFirstCharacter.excludes` does not include `"Friends"`
         * (or if `decapitalizeFirstCharacter.includes` includes `"Friends"`),
         * then `"Why [__CONTACT__]?"` will be replaced by `"Why friends?"`.
         */
        enabled: z.ZodBoolean;
        options: z.ZodOptional<z.ZodUnion<[z.ZodObject<{
            /**
             * If set, answer data included in it will not be decapitalize.
             */
            excludes: z.ZodArray<z.ZodString, "many">;
            includes: z.ZodOptional<z.ZodNever>;
        }, "strip", z.ZodTypeAny, {
            includes?: undefined;
            excludes: string[];
        }, {
            includes?: undefined;
            excludes: string[];
        }>, z.ZodObject<{
            /**
             * If set, only answer data included in it will be decapitalize.
             */
            includes: z.ZodArray<z.ZodString, "many">;
            excludes: z.ZodOptional<z.ZodNever>;
        }, "strip", z.ZodTypeAny, {
            excludes?: undefined;
            includes: string[];
        }, {
            excludes?: undefined;
            includes: string[];
        }>]>>;
    }, "strip", z.ZodTypeAny, {
        options?: {
            includes?: undefined;
            excludes: string[];
        } | {
            excludes?: undefined;
            includes: string[];
        } | undefined;
        enabled: boolean;
    }, {
        options?: {
            includes?: undefined;
            excludes: string[];
        } | {
            excludes?: undefined;
            includes: string[];
        } | undefined;
        enabled: boolean;
    }>>;
}, "strip", z.ZodTypeAny, {
    decapitalizeFirstCharacter?: {
        options?: {
            includes?: undefined;
            excludes: string[];
        } | {
            excludes?: undefined;
            includes: string[];
        } | undefined;
        enabled: boolean;
    } | undefined;
}, {
    decapitalizeFirstCharacter?: {
        options?: {
            includes?: undefined;
            excludes: string[];
        } | {
            excludes?: undefined;
            includes: string[];
        } | undefined;
        enabled: boolean;
    } | undefined;
}>;
export declare const StudyInfoSchema: z.ZodEffects<z.ZodEffects<z.ZodObject<{
    /**
     * The ID of the study.
     *
     * It can only include letters, numbers, and "_".
     */
    id: z.ZodString;
    /**
     * The version of the study.
     *
     * https://github.com/wellping/wellping/issues/94
     */
    version: z.ZodOptional<z.ZodString>;
    /**
     * The URL that host this study file (which could be a JSON or a YAML file).
     *
     * The app fetches this URL in the background at every start and loads the
     * downloaded new file at the next start.
     */
    studyFileURL: z.ZodString;
    /**
     * The URL of the dashboard that will be shown to the user on the home page.
     *
     * ---
     *
     * The placeholder `__USERNAME__` will be replaced by the user's username.
     * Notice that you should not return any sensitive data based on this field
     * as it can be changed by anyone.
     * In order to verify the user securely:
     * - If you are using Firebase, you should use the `__FIREBASE_ID_TOKEN__`
     *   placeholder as explained below.
     * - If you are using Beiwe, (A TODO: ITEM).
     *
     * If Firebase is used, the placeholder `__FIREBASE_ID_TOKEN__` will be
     * replaced by the user's Firebase Auth ID token if the user is signed in
     * to Firebase, and "N/A" otherwise.
     *
     * ---
     *
     * The following Placeholders are also provided for your convenience so that
     * you don't have to set up a full back-end server (with Firebase Admin SDK)
     * just to display the user's progress:
     *
     * The placeholder `__PINGS_COMPLETED_OVERALL__` will be replaced by the
     * number of pings the user has completed overall.
     *
     * The placeholder `__PINGS_COMPLETED_THIS_WEEK__` will be replaced by the
     * number of pings the user has completed this week (defined by
     * `weekStartsOn`).
     *
     * The placeholder `__PINGS_COMPLETED_TODAY__` will be replaced by the
     * number of pings the user has completed today.
     */
    dashboardURL: z.ZodOptional<z.ZodString>;
    /**
     * The backend server info for the study. Well Ping supports uploading to
     * Firebase or uploading to Beiwe.
     *
     * If Firebase backend is used, `server.firebase` should be defined.
     *
     * If Beiwe backend is used, `server.beiwe` should be defined.
     *
     * If this object is empty (i.e., `server: {}`), you will be able to log in
     * using any username password combination, and no data will be uploaded.
     * This is only intended for testing or demo purposes and should not be used
     * in production. (MARK: NO_SERVER_NOTE)
     *
     * Notice that in theory, both `server.firebase` and `server.beiwe` could be
     * set (meaning that the data will be uploaded to both Beiwe and Firebase).
     * However, such pratice is not thoroughly tested and is not guaranteed to
     * work correctly.
     */
    server: z.ZodObject<{
        firebase: z.ZodOptional<z.ZodObject<{
            /**
             * The Firebase config object for the study.
             *
             * See https://firebase.google.com/docs/web/setup#config-object
             */
            config: z.ZodRecord<z.ZodString, z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            config: Record<string, string>;
        }, {
            config: Record<string, string>;
        }>>;
        beiwe: z.ZodOptional<z.ZodObject<{
            /**
             * The server URL of Beiwe backend for the study.
             *
             * Example: `"https://beiwe.example.com/"`
             */
            serverUrl: z.ZodString;
        }, "strip", z.ZodTypeAny, {
            serverUrl: string;
        }, {
            serverUrl: string;
        }>>;
    }, "strip", z.ZodTypeAny, {
        firebase?: {
            config: Record<string, string>;
        } | undefined;
        beiwe?: {
            serverUrl: string;
        } | undefined;
    }, {
        firebase?: {
            config: Record<string, string>;
        } | undefined;
        beiwe?: {
            serverUrl: string;
        } | undefined;
    }>;
    /**
     * The URL of the study consent form (or any web page you would want the
     * user to see before they begin).
     *
     * This web page will be displayed after the user successfully logs in.
     */
    consentFormUrl: z.ZodString;
    /**
     * The email address that the user could contact for questions regarding the
     * study or the app.
     *
     * If this field is set, a "Contact Staff" button will appear at the top of
     * the screen.
     */
    contactEmail: z.ZodOptional<z.ZodString>;
    /**
     * The first day of the week.
     *
     * 0 is Sunday.
     */
    weekStartsOn: z.ZodUnion<[z.ZodLiteral<0>, z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>, z.ZodLiteral<5>, z.ZodLiteral<6>]>;
    /**
     * The start date (time) of the study.
     *
     * The first ping will be sent after this time.
     *
     * Timezone in this date string is ignored.
     */
    startDate: z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, Date, string>, z.ZodDate]>;
    /**
     * The end date (time) of the study.
     *
     * The last ping will be sent before this time.
     *
     * Timezone in this date string is ignored.
     */
    endDate: z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, Date, string>, z.ZodDate]>;
    /**
     * The time every day that ping notifications will be sent.
     *
     * Notice that the duration between every
     * `pingsFrequency[i].latestPingNotificationTime` and
     * `pingsFrequency[i+1].earliestPingNotificationTime`
     * should be greater than
     * `pingsFrequency[i].expireAfterTime`
     * so that the user will always have enough time to complete the ping no matter
     * what time they receive the ping.
     */
    pingsFrequency: z.ZodArray<z.ZodEffects<z.ZodObject<{
        /**
         * The earliest time that the ping will be sent (inclusive).
         */
        earliestPingNotificationTime: z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, number, string>, z.ZodNumber]>;
        /**
         * The latest time that the ping will be sent (inclusive).
         * If this is not specified, the ping will be sent exactly at
         * `earliestPingNotificationTime`.
         * If this is specified, the ping will be sent at a random time between
         * `earliestPingNotificationTime` and `latestPingNotificationTime`.
         */
        latestPingNotificationTime: z.ZodOptional<z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, number, string>, z.ZodNumber]>>;
        /**
         * A ping will expire after this amount of time (after the notification
         * time).
         *
         * For example, if the user receives a ping notification on 10:00:00AM,
         * and `expireAfterTime` is set to `00:45:00`, the user will no longer
         * be able to complete this ping after 10:45:00AM.
         */
        expireAfterTime: z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, number, string>, z.ZodNumber]>;
    }, "strip", z.ZodTypeAny, {
        latestPingNotificationTime?: number | undefined;
        earliestPingNotificationTime: number;
        expireAfterTime: number;
    }, {
        latestPingNotificationTime?: string | number | undefined;
        earliestPingNotificationTime: string | number;
        expireAfterTime: string | number;
    }>, {
        latestPingNotificationTime?: number | undefined;
        earliestPingNotificationTime: number;
        expireAfterTime: number;
    }, {
        latestPingNotificationTime?: string | number | undefined;
        earliestPingNotificationTime: string | number;
        expireAfterTime: string | number;
    }>, "many">;
    /**
     * The question ID of the first question of each stream.
     */
    streamsStartingQuestionIds: z.ZodRecord<z.ZodString, z.ZodString>;
    /**
     * The streams that the user will fill (in this order) every day.
     *
     * For example, if `streamsOrder.sunday` is `["dog", "cat", "wolf", "lynx"]`,
     * then on Sunday, if the user opens all four pings they received, they
     * will fill the "dog", "cat", "wolf", and "lynx" stream (in this order).
     * If the user only opens two pings, they will fill the "dog" and "cat"
     * stream (in this order).
     *
     * The number of elements each day should be equal to the number of elements
     * in `pingsFrequency` above.
     */
    streamsOrder: z.ZodUnion<[z.ZodObject<{
        0: z.ZodArray<z.ZodString, "many">;
        1: z.ZodArray<z.ZodString, "many">;
        2: z.ZodArray<z.ZodString, "many">;
        3: z.ZodArray<z.ZodString, "many">;
        4: z.ZodArray<z.ZodString, "many">;
        5: z.ZodArray<z.ZodString, "many">;
        6: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        0: string[];
        2: string[];
        1: string[];
        6: string[];
        3: string[];
        4: string[];
        5: string[];
    }, {
        0: string[];
        2: string[];
        1: string[];
        6: string[];
        3: string[];
        4: string[];
        5: string[];
    }>, z.ZodEffects<z.ZodObject<{
        sunday: z.ZodArray<z.ZodString, "many">;
        monday: z.ZodArray<z.ZodString, "many">;
        tuesday: z.ZodArray<z.ZodString, "many">;
        wednesday: z.ZodArray<z.ZodString, "many">;
        thursday: z.ZodArray<z.ZodString, "many">;
        friday: z.ZodArray<z.ZodString, "many">;
        saturday: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        sunday: string[];
        monday: string[];
        tuesday: string[];
        wednesday: string[];
        thursday: string[];
        friday: string[];
        saturday: string[];
    }, {
        sunday: string[];
        monday: string[];
        tuesday: string[];
        wednesday: string[];
        thursday: string[];
        friday: string[];
        saturday: string[];
    }>, {
        0: string[];
        2: string[];
        1: string[];
        6: string[];
        3: string[];
        4: string[];
        5: string[];
    }, {
        sunday: string[];
        monday: string[];
        tuesday: string[];
        wednesday: string[];
        thursday: string[];
        friday: string[];
        saturday: string[];
    }>, z.ZodEffects<z.ZodArray<z.ZodString, "many">, {
        0: string[];
        2: string[];
        1: string[];
        6: string[];
        3: string[];
        4: string[];
        5: string[];
    }, string[]>]>;
    /**
     * The stream type(s) for n-th ping(s). The key is the "n" in "n-th ping".
     * This will **replace** the originally sceduled stream type for that ping.
     *
     * For example,
     * ```{json}
     * "streamsForNthPings": {
     *   "1": "demographic",
     *   "10": "interests"
     * }
     * ```
     * means that the user's first ping will be `"demographic"` stream and the
     * user's 10th ping will be `"interests"` stream.
     */
    streamsForNthPings: z.ZodEffects<z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>, Record<string, string> | undefined, Record<string, string> | undefined>;
    /**
     * The stream that the user will see if there is any error in `streamsOrder`.
     */
    streamInCaseOfError: z.ZodString;
    /**
     * The streams that will not be replaced by followup streams
     * (when a YesNo question's `addFollowupStream` is set).
     */
    streamsNotReplacedByFollowupStream: z.ZodArray<z.ZodString, "many">;
    notificationContent: z.ZodObject<{
        /**
         * The default notification title and body.
         */
        default: z.ZodObject<{
            title: z.ZodString;
            body: z.ZodString;
        }, "strip", z.ZodTypeAny, {
            title: string;
            body: string;
        }, {
            title: string;
            body: string;
        }>;
        /**
         * If set, the `bonus` content for the notification will be used until
         * the number of survey completed that week is greater than
         * `bonus.numberOfCompletionEachWeek - 1`.
         *
         * "#n_ping#" in `title` and `body` will be replaced by "5 pings" or
         * "1 ping".
         *
         * Example:
         * ```
         * bonus: {
         *    title: "You can earn bonus!",
         *    body: "You are #n_ping# away from the weekly bonus.",
         *    numberOfCompletionEachWeek: 5,
         * },
         * ```
         */
        bonus: z.ZodOptional<z.ZodObject<{
            title: z.ZodString;
            body: z.ZodString;
            numberOfCompletionEachWeek: z.ZodNumber;
        }, "strip", z.ZodTypeAny, {
            title: string;
            body: string;
            numberOfCompletionEachWeek: number;
        }, {
            title: string;
            body: string;
            numberOfCompletionEachWeek: number;
        }>>;
    }, "strip", z.ZodTypeAny, {
        bonus?: {
            title: string;
            body: string;
            numberOfCompletionEachWeek: number;
        } | undefined;
        default: {
            title: string;
            body: string;
        };
    }, {
        bonus?: {
            title: string;
            body: string;
            numberOfCompletionEachWeek: number;
        } | undefined;
        default: {
            title: string;
            body: string;
        };
    }>;
    /**
     * If `true`, the "Next" button will always be enabled.
     * If `false` or undefined, the "Next" button will only be enabled after the
     * user has interacted with the question.
     */
    alwaysEnableNextButton: z.ZodOptional<z.ZodBoolean>;
    /**
     * Special treatments for variable placeholders. The key of each record is
     * the variable name as defined by supported question's `variableName`, or a
     * question ID (if you want to replace the placeholder with a previous
     * question's answer).
     */
    specialVariablePlaceholderTreatments: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
        decapitalizeFirstCharacter: z.ZodOptional<z.ZodObject<{
            /**
             * The first character of the answer data replacing the placeholder will be
             * decapitalized.
             *
             * For example, if the answer is `"Friends"` and the variable is `"CONTACT"`,
             * and `decapitalizeFirstCharacter.enabled` is `true`,
             * and `decapitalizeFirstCharacter.excludes` does not include `"Friends"`
             * (or if `decapitalizeFirstCharacter.includes` includes `"Friends"`),
             * then `"Why [__CONTACT__]?"` will be replaced by `"Why friends?"`.
             */
            enabled: z.ZodBoolean;
            options: z.ZodOptional<z.ZodUnion<[z.ZodObject<{
                /**
                 * If set, answer data included in it will not be decapitalize.
                 */
                excludes: z.ZodArray<z.ZodString, "many">;
                includes: z.ZodOptional<z.ZodNever>;
            }, "strip", z.ZodTypeAny, {
                includes?: undefined;
                excludes: string[];
            }, {
                includes?: undefined;
                excludes: string[];
            }>, z.ZodObject<{
                /**
                 * If set, only answer data included in it will be decapitalize.
                 */
                includes: z.ZodArray<z.ZodString, "many">;
                excludes: z.ZodOptional<z.ZodNever>;
            }, "strip", z.ZodTypeAny, {
                excludes?: undefined;
                includes: string[];
            }, {
                excludes?: undefined;
                includes: string[];
            }>]>>;
        }, "strip", z.ZodTypeAny, {
            options?: {
                includes?: undefined;
                excludes: string[];
            } | {
                excludes?: undefined;
                includes: string[];
            } | undefined;
            enabled: boolean;
        }, {
            options?: {
                includes?: undefined;
                excludes: string[];
            } | {
                excludes?: undefined;
                includes: string[];
            } | undefined;
            enabled: boolean;
        }>>;
    }, "strip", z.ZodTypeAny, {
        decapitalizeFirstCharacter?: {
            options?: {
                includes?: undefined;
                excludes: string[];
            } | {
                excludes?: undefined;
                includes: string[];
            } | undefined;
            enabled: boolean;
        } | undefined;
    }, {
        decapitalizeFirstCharacter?: {
            options?: {
                includes?: undefined;
                excludes: string[];
            } | {
                excludes?: undefined;
                includes: string[];
            } | undefined;
            enabled: boolean;
        } | undefined;
    }>>>;
    /**
     * Show an alert each time the app launches.
     */
    specialAlertOnLaunch: z.ZodOptional<z.ZodObject<{
        title: z.ZodDefault<z.ZodString>;
        message: z.ZodString;
        buttonText: z.ZodDefault<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        message: string;
        title: string;
        buttonText: string;
    }, {
        title?: string | undefined;
        buttonText?: string | undefined;
        message: string;
    }>>;
}, "strict", z.ZodTypeAny, {
    version?: string | undefined;
    dashboardURL?: string | undefined;
    contactEmail?: string | undefined;
    streamsForNthPings?: Record<string, string> | undefined;
    alwaysEnableNextButton?: boolean | undefined;
    specialVariablePlaceholderTreatments?: Record<string, {
        decapitalizeFirstCharacter?: {
            options?: {
                includes?: undefined;
                excludes: string[];
            } | {
                excludes?: undefined;
                includes: string[];
            } | undefined;
            enabled: boolean;
        } | undefined;
    }> | undefined;
    specialAlertOnLaunch?: {
        message: string;
        title: string;
        buttonText: string;
    } | undefined;
    id: string;
    studyFileURL: string;
    server: {
        firebase?: {
            config: Record<string, string>;
        } | undefined;
        beiwe?: {
            serverUrl: string;
        } | undefined;
    };
    consentFormUrl: string;
    weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
    startDate: Date;
    endDate: Date;
    pingsFrequency: {
        latestPingNotificationTime?: number | undefined;
        earliestPingNotificationTime: number;
        expireAfterTime: number;
    }[];
    streamsStartingQuestionIds: Record<string, string>;
    streamsOrder: {
        0: string[];
        2: string[];
        1: string[];
        6: string[];
        3: string[];
        4: string[];
        5: string[];
    };
    streamInCaseOfError: string;
    streamsNotReplacedByFollowupStream: string[];
    notificationContent: {
        bonus?: {
            title: string;
            body: string;
            numberOfCompletionEachWeek: number;
        } | undefined;
        default: {
            title: string;
            body: string;
        };
    };
}, {
    version?: string | undefined;
    dashboardURL?: string | undefined;
    contactEmail?: string | undefined;
    streamsForNthPings?: Record<string, string> | undefined;
    alwaysEnableNextButton?: boolean | undefined;
    specialVariablePlaceholderTreatments?: Record<string, {
        decapitalizeFirstCharacter?: {
            options?: {
                includes?: undefined;
                excludes: string[];
            } | {
                excludes?: undefined;
                includes: string[];
            } | undefined;
            enabled: boolean;
        } | undefined;
    }> | undefined;
    specialAlertOnLaunch?: {
        title?: string | undefined;
        buttonText?: string | undefined;
        message: string;
    } | undefined;
    id: string;
    studyFileURL: string;
    server: {
        firebase?: {
            config: Record<string, string>;
        } | undefined;
        beiwe?: {
            serverUrl: string;
        } | undefined;
    };
    consentFormUrl: string;
    weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
    startDate: string | Date;
    endDate: string | Date;
    pingsFrequency: {
        latestPingNotificationTime?: string | number | undefined;
        earliestPingNotificationTime: string | number;
        expireAfterTime: string | number;
    }[];
    streamsStartingQuestionIds: Record<string, string>;
    streamsOrder: string[] | {
        0: string[];
        2: string[];
        1: string[];
        6: string[];
        3: string[];
        4: string[];
        5: string[];
    } | {
        sunday: string[];
        monday: string[];
        tuesday: string[];
        wednesday: string[];
        thursday: string[];
        friday: string[];
        saturday: string[];
    };
    streamInCaseOfError: string;
    streamsNotReplacedByFollowupStream: string[];
    notificationContent: {
        bonus?: {
            title: string;
            body: string;
            numberOfCompletionEachWeek: number;
        } | undefined;
        default: {
            title: string;
            body: string;
        };
    };
}>, {
    version?: string | undefined;
    dashboardURL?: string | undefined;
    contactEmail?: string | undefined;
    streamsForNthPings?: Record<string, string> | undefined;
    alwaysEnableNextButton?: boolean | undefined;
    specialVariablePlaceholderTreatments?: Record<string, {
        decapitalizeFirstCharacter?: {
            options?: {
                includes?: undefined;
                excludes: string[];
            } | {
                excludes?: undefined;
                includes: string[];
            } | undefined;
            enabled: boolean;
        } | undefined;
    }> | undefined;
    specialAlertOnLaunch?: {
        message: string;
        title: string;
        buttonText: string;
    } | undefined;
    id: string;
    studyFileURL: string;
    server: {
        firebase?: {
            config: Record<string, string>;
        } | undefined;
        beiwe?: {
            serverUrl: string;
        } | undefined;
    };
    consentFormUrl: string;
    weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
    startDate: Date;
    endDate: Date;
    pingsFrequency: {
        latestPingNotificationTime?: number | undefined;
        earliestPingNotificationTime: number;
        expireAfterTime: number;
    }[];
    streamsStartingQuestionIds: Record<string, string>;
    streamsOrder: {
        0: string[];
        2: string[];
        1: string[];
        6: string[];
        3: string[];
        4: string[];
        5: string[];
    };
    streamInCaseOfError: string;
    streamsNotReplacedByFollowupStream: string[];
    notificationContent: {
        bonus?: {
            title: string;
            body: string;
            numberOfCompletionEachWeek: number;
        } | undefined;
        default: {
            title: string;
            body: string;
        };
    };
}, {
    version?: string | undefined;
    dashboardURL?: string | undefined;
    contactEmail?: string | undefined;
    streamsForNthPings?: Record<string, string> | undefined;
    alwaysEnableNextButton?: boolean | undefined;
    specialVariablePlaceholderTreatments?: Record<string, {
        decapitalizeFirstCharacter?: {
            options?: {
                includes?: undefined;
                excludes: string[];
            } | {
                excludes?: undefined;
                includes: string[];
            } | undefined;
            enabled: boolean;
        } | undefined;
    }> | undefined;
    specialAlertOnLaunch?: {
        title?: string | undefined;
        buttonText?: string | undefined;
        message: string;
    } | undefined;
    id: string;
    studyFileURL: string;
    server: {
        firebase?: {
            config: Record<string, string>;
        } | undefined;
        beiwe?: {
            serverUrl: string;
        } | undefined;
    };
    consentFormUrl: string;
    weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
    startDate: string | Date;
    endDate: string | Date;
    pingsFrequency: {
        latestPingNotificationTime?: string | number | undefined;
        earliestPingNotificationTime: string | number;
        expireAfterTime: string | number;
    }[];
    streamsStartingQuestionIds: Record<string, string>;
    streamsOrder: string[] | {
        0: string[];
        2: string[];
        1: string[];
        6: string[];
        3: string[];
        4: string[];
        5: string[];
    } | {
        sunday: string[];
        monday: string[];
        tuesday: string[];
        wednesday: string[];
        thursday: string[];
        friday: string[];
        saturday: string[];
    };
    streamInCaseOfError: string;
    streamsNotReplacedByFollowupStream: string[];
    notificationContent: {
        bonus?: {
            title: string;
            body: string;
            numberOfCompletionEachWeek: number;
        } | undefined;
        default: {
            title: string;
            body: string;
        };
    };
}>, {
    version?: string | undefined;
    dashboardURL?: string | undefined;
    contactEmail?: string | undefined;
    streamsForNthPings?: Record<string, string> | undefined;
    alwaysEnableNextButton?: boolean | undefined;
    specialVariablePlaceholderTreatments?: Record<string, {
        decapitalizeFirstCharacter?: {
            options?: {
                includes?: undefined;
                excludes: string[];
            } | {
                excludes?: undefined;
                includes: string[];
            } | undefined;
            enabled: boolean;
        } | undefined;
    }> | undefined;
    specialAlertOnLaunch?: {
        message: string;
        title: string;
        buttonText: string;
    } | undefined;
    id: string;
    studyFileURL: string;
    server: {
        firebase?: {
            config: Record<string, string>;
        } | undefined;
        beiwe?: {
            serverUrl: string;
        } | undefined;
    };
    consentFormUrl: string;
    weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
    startDate: Date;
    endDate: Date;
    pingsFrequency: {
        latestPingNotificationTime?: number | undefined;
        earliestPingNotificationTime: number;
        expireAfterTime: number;
    }[];
    streamsStartingQuestionIds: Record<string, string>;
    streamsOrder: {
        0: string[];
        2: string[];
        1: string[];
        6: string[];
        3: string[];
        4: string[];
        5: string[];
    };
    streamInCaseOfError: string;
    streamsNotReplacedByFollowupStream: string[];
    notificationContent: {
        bonus?: {
            title: string;
            body: string;
            numberOfCompletionEachWeek: number;
        } | undefined;
        default: {
            title: string;
            body: string;
        };
    };
}, {
    version?: string | undefined;
    dashboardURL?: string | undefined;
    contactEmail?: string | undefined;
    streamsForNthPings?: Record<string, string> | undefined;
    alwaysEnableNextButton?: boolean | undefined;
    specialVariablePlaceholderTreatments?: Record<string, {
        decapitalizeFirstCharacter?: {
            options?: {
                includes?: undefined;
                excludes: string[];
            } | {
                excludes?: undefined;
                includes: string[];
            } | undefined;
            enabled: boolean;
        } | undefined;
    }> | undefined;
    specialAlertOnLaunch?: {
        title?: string | undefined;
        buttonText?: string | undefined;
        message: string;
    } | undefined;
    id: string;
    studyFileURL: string;
    server: {
        firebase?: {
            config: Record<string, string>;
        } | undefined;
        beiwe?: {
            serverUrl: string;
        } | undefined;
    };
    consentFormUrl: string;
    weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
    startDate: string | Date;
    endDate: string | Date;
    pingsFrequency: {
        latestPingNotificationTime?: string | number | undefined;
        earliestPingNotificationTime: string | number;
        expireAfterTime: string | number;
    }[];
    streamsStartingQuestionIds: Record<string, string>;
    streamsOrder: string[] | {
        0: string[];
        2: string[];
        1: string[];
        6: string[];
        3: string[];
        4: string[];
        5: string[];
    } | {
        sunday: string[];
        monday: string[];
        tuesday: string[];
        wednesday: string[];
        thursday: string[];
        friday: string[];
        saturday: string[];
    };
    streamInCaseOfError: string;
    streamsNotReplacedByFollowupStream: string[];
    notificationContent: {
        bonus?: {
            title: string;
            body: string;
            numberOfCompletionEachWeek: number;
        } | undefined;
        default: {
            title: string;
            body: string;
        };
    };
}> | z.ZodEffects<z.ZodEffects<z.ZodObject<{
    /**
     * The ID of the study.
     *
     * It can only include letters, numbers, and "_".
     */
    id: z.ZodString;
    /**
     * The version of the study.
     *
     * https://github.com/wellping/wellping/issues/94
     */
    version: z.ZodOptional<z.ZodString>;
    /**
     * The URL that host this study file (which could be a JSON or a YAML file).
     *
     * The app fetches this URL in the background at every start and loads the
     * downloaded new file at the next start.
     */
    studyFileURL: z.ZodString;
    /**
     * The URL of the dashboard that will be shown to the user on the home page.
     *
     * ---
     *
     * The placeholder `__USERNAME__` will be replaced by the user's username.
     * Notice that you should not return any sensitive data based on this field
     * as it can be changed by anyone.
     * In order to verify the user securely:
     * - If you are using Firebase, you should use the `__FIREBASE_ID_TOKEN__`
     *   placeholder as explained below.
     * - If you are using Beiwe, (A TODO: ITEM).
     *
     * If Firebase is used, the placeholder `__FIREBASE_ID_TOKEN__` will be
     * replaced by the user's Firebase Auth ID token if the user is signed in
     * to Firebase, and "N/A" otherwise.
     *
     * ---
     *
     * The following Placeholders are also provided for your convenience so that
     * you don't have to set up a full back-end server (with Firebase Admin SDK)
     * just to display the user's progress:
     *
     * The placeholder `__PINGS_COMPLETED_OVERALL__` will be replaced by the
     * number of pings the user has completed overall.
     *
     * The placeholder `__PINGS_COMPLETED_THIS_WEEK__` will be replaced by the
     * number of pings the user has completed this week (defined by
     * `weekStartsOn`).
     *
     * The placeholder `__PINGS_COMPLETED_TODAY__` will be replaced by the
     * number of pings the user has completed today.
     */
    dashboardURL: z.ZodOptional<z.ZodString>;
    /**
     * The backend server info for the study. Well Ping supports uploading to
     * Firebase or uploading to Beiwe.
     *
     * If Firebase backend is used, `server.firebase` should be defined.
     *
     * If Beiwe backend is used, `server.beiwe` should be defined.
     *
     * If this object is empty (i.e., `server: {}`), you will be able to log in
     * using any username password combination, and no data will be uploaded.
     * This is only intended for testing or demo purposes and should not be used
     * in production. (MARK: NO_SERVER_NOTE)
     *
     * Notice that in theory, both `server.firebase` and `server.beiwe` could be
     * set (meaning that the data will be uploaded to both Beiwe and Firebase).
     * However, such pratice is not thoroughly tested and is not guaranteed to
     * work correctly.
     */
    server: z.ZodObject<{
        firebase: z.ZodOptional<z.ZodObject<{
            /**
             * The Firebase config object for the study.
             *
             * See https://firebase.google.com/docs/web/setup#config-object
             */
            config: z.ZodRecord<z.ZodString, z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            config: Record<string, string>;
        }, {
            config: Record<string, string>;
        }>>;
        beiwe: z.ZodOptional<z.ZodObject<{
            /**
             * The server URL of Beiwe backend for the study.
             *
             * Example: `"https://beiwe.example.com/"`
             */
            serverUrl: z.ZodString;
        }, "strip", z.ZodTypeAny, {
            serverUrl: string;
        }, {
            serverUrl: string;
        }>>;
    }, "strip", z.ZodTypeAny, {
        firebase?: {
            config: Record<string, string>;
        } | undefined;
        beiwe?: {
            serverUrl: string;
        } | undefined;
    }, {
        firebase?: {
            config: Record<string, string>;
        } | undefined;
        beiwe?: {
            serverUrl: string;
        } | undefined;
    }>;
    /**
     * The URL of the study consent form (or any web page you would want the
     * user to see before they begin).
     *
     * This web page will be displayed after the user successfully logs in.
     */
    consentFormUrl: z.ZodString;
    /**
     * The email address that the user could contact for questions regarding the
     * study or the app.
     *
     * If this field is set, a "Contact Staff" button will appear at the top of
     * the screen.
     */
    contactEmail: z.ZodOptional<z.ZodString>;
    /**
     * The first day of the week.
     *
     * 0 is Sunday.
     */
    weekStartsOn: z.ZodUnion<[z.ZodLiteral<0>, z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>, z.ZodLiteral<5>, z.ZodLiteral<6>]>;
    /**
     * The start date (time) of the study.
     *
     * The first ping will be sent after this time.
     *
     * Timezone in this date string is ignored.
     */
    startDate: z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, Date, string>, z.ZodDate]>;
    /**
     * The end date (time) of the study.
     *
     * The last ping will be sent before this time.
     *
     * Timezone in this date string is ignored.
     */
    endDate: z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, Date, string>, z.ZodDate]>;
    /**
     * The time every day that ping notifications will be sent.
     *
     * Notice that the duration between every
     * `pingsFrequency[i].latestPingNotificationTime` and
     * `pingsFrequency[i+1].earliestPingNotificationTime`
     * should be greater than
     * `pingsFrequency[i].expireAfterTime`
     * so that the user will always have enough time to complete the ping no matter
     * what time they receive the ping.
     */
    pingsFrequency: z.ZodArray<z.ZodEffects<z.ZodObject<{
        /**
         * The earliest time that the ping will be sent (inclusive).
         */
        earliestPingNotificationTime: z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, number, string>, z.ZodNumber]>;
        /**
         * The latest time that the ping will be sent (inclusive).
         * If this is not specified, the ping will be sent exactly at
         * `earliestPingNotificationTime`.
         * If this is specified, the ping will be sent at a random time between
         * `earliestPingNotificationTime` and `latestPingNotificationTime`.
         */
        latestPingNotificationTime: z.ZodOptional<z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, number, string>, z.ZodNumber]>>;
        /**
         * A ping will expire after this amount of time (after the notification
         * time).
         *
         * For example, if the user receives a ping notification on 10:00:00AM,
         * and `expireAfterTime` is set to `00:45:00`, the user will no longer
         * be able to complete this ping after 10:45:00AM.
         */
        expireAfterTime: z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, number, string>, z.ZodNumber]>;
    }, "strip", z.ZodTypeAny, {
        latestPingNotificationTime?: number | undefined;
        earliestPingNotificationTime: number;
        expireAfterTime: number;
    }, {
        latestPingNotificationTime?: string | number | undefined;
        earliestPingNotificationTime: string | number;
        expireAfterTime: string | number;
    }>, {
        latestPingNotificationTime?: number | undefined;
        earliestPingNotificationTime: number;
        expireAfterTime: number;
    }, {
        latestPingNotificationTime?: string | number | undefined;
        earliestPingNotificationTime: string | number;
        expireAfterTime: string | number;
    }>, "many">;
    /**
     * The question ID of the first question of each stream.
     */
    streamsStartingQuestionIds: z.ZodRecord<z.ZodString, z.ZodString>;
    /**
     * The streams that the user will fill (in this order) every day.
     *
     * For example, if `streamsOrder.sunday` is `["dog", "cat", "wolf", "lynx"]`,
     * then on Sunday, if the user opens all four pings they received, they
     * will fill the "dog", "cat", "wolf", and "lynx" stream (in this order).
     * If the user only opens two pings, they will fill the "dog" and "cat"
     * stream (in this order).
     *
     * The number of elements each day should be equal to the number of elements
     * in `pingsFrequency` above.
     */
    streamsOrder: z.ZodUnion<[z.ZodObject<{
        0: z.ZodArray<z.ZodString, "many">;
        1: z.ZodArray<z.ZodString, "many">;
        2: z.ZodArray<z.ZodString, "many">;
        3: z.ZodArray<z.ZodString, "many">;
        4: z.ZodArray<z.ZodString, "many">;
        5: z.ZodArray<z.ZodString, "many">;
        6: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        0: string[];
        2: string[];
        1: string[];
        6: string[];
        3: string[];
        4: string[];
        5: string[];
    }, {
        0: string[];
        2: string[];
        1: string[];
        6: string[];
        3: string[];
        4: string[];
        5: string[];
    }>, z.ZodEffects<z.ZodObject<{
        sunday: z.ZodArray<z.ZodString, "many">;
        monday: z.ZodArray<z.ZodString, "many">;
        tuesday: z.ZodArray<z.ZodString, "many">;
        wednesday: z.ZodArray<z.ZodString, "many">;
        thursday: z.ZodArray<z.ZodString, "many">;
        friday: z.ZodArray<z.ZodString, "many">;
        saturday: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        sunday: string[];
        monday: string[];
        tuesday: string[];
        wednesday: string[];
        thursday: string[];
        friday: string[];
        saturday: string[];
    }, {
        sunday: string[];
        monday: string[];
        tuesday: string[];
        wednesday: string[];
        thursday: string[];
        friday: string[];
        saturday: string[];
    }>, {
        0: string[];
        2: string[];
        1: string[];
        6: string[];
        3: string[];
        4: string[];
        5: string[];
    }, {
        sunday: string[];
        monday: string[];
        tuesday: string[];
        wednesday: string[];
        thursday: string[];
        friday: string[];
        saturday: string[];
    }>, z.ZodEffects<z.ZodArray<z.ZodString, "many">, {
        0: string[];
        2: string[];
        1: string[];
        6: string[];
        3: string[];
        4: string[];
        5: string[];
    }, string[]>]>;
    /**
     * The stream type(s) for n-th ping(s). The key is the "n" in "n-th ping".
     * This will **replace** the originally sceduled stream type for that ping.
     *
     * For example,
     * ```{json}
     * "streamsForNthPings": {
     *   "1": "demographic",
     *   "10": "interests"
     * }
     * ```
     * means that the user's first ping will be `"demographic"` stream and the
     * user's 10th ping will be `"interests"` stream.
     */
    streamsForNthPings: z.ZodEffects<z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>, Record<string, string> | undefined, Record<string, string> | undefined>;
    /**
     * The stream that the user will see if there is any error in `streamsOrder`.
     */
    streamInCaseOfError: z.ZodString;
    /**
     * The streams that will not be replaced by followup streams
     * (when a YesNo question's `addFollowupStream` is set).
     */
    streamsNotReplacedByFollowupStream: z.ZodArray<z.ZodString, "many">;
    notificationContent: z.ZodObject<{
        /**
         * The default notification title and body.
         */
        default: z.ZodObject<{
            title: z.ZodString;
            body: z.ZodString;
        }, "strip", z.ZodTypeAny, {
            title: string;
            body: string;
        }, {
            title: string;
            body: string;
        }>;
        /**
         * If set, the `bonus` content for the notification will be used until
         * the number of survey completed that week is greater than
         * `bonus.numberOfCompletionEachWeek - 1`.
         *
         * "#n_ping#" in `title` and `body` will be replaced by "5 pings" or
         * "1 ping".
         *
         * Example:
         * ```
         * bonus: {
         *    title: "You can earn bonus!",
         *    body: "You are #n_ping# away from the weekly bonus.",
         *    numberOfCompletionEachWeek: 5,
         * },
         * ```
         */
        bonus: z.ZodOptional<z.ZodObject<{
            title: z.ZodString;
            body: z.ZodString;
            numberOfCompletionEachWeek: z.ZodNumber;
        }, "strip", z.ZodTypeAny, {
            title: string;
            body: string;
            numberOfCompletionEachWeek: number;
        }, {
            title: string;
            body: string;
            numberOfCompletionEachWeek: number;
        }>>;
    }, "strip", z.ZodTypeAny, {
        bonus?: {
            title: string;
            body: string;
            numberOfCompletionEachWeek: number;
        } | undefined;
        default: {
            title: string;
            body: string;
        };
    }, {
        bonus?: {
            title: string;
            body: string;
            numberOfCompletionEachWeek: number;
        } | undefined;
        default: {
            title: string;
            body: string;
        };
    }>;
    /**
     * If `true`, the "Next" button will always be enabled.
     * If `false` or undefined, the "Next" button will only be enabled after the
     * user has interacted with the question.
     */
    alwaysEnableNextButton: z.ZodOptional<z.ZodBoolean>;
    /**
     * Special treatments for variable placeholders. The key of each record is
     * the variable name as defined by supported question's `variableName`, or a
     * question ID (if you want to replace the placeholder with a previous
     * question's answer).
     */
    specialVariablePlaceholderTreatments: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
        decapitalizeFirstCharacter: z.ZodOptional<z.ZodObject<{
            /**
             * The first character of the answer data replacing the placeholder will be
             * decapitalized.
             *
             * For example, if the answer is `"Friends"` and the variable is `"CONTACT"`,
             * and `decapitalizeFirstCharacter.enabled` is `true`,
             * and `decapitalizeFirstCharacter.excludes` does not include `"Friends"`
             * (or if `decapitalizeFirstCharacter.includes` includes `"Friends"`),
             * then `"Why [__CONTACT__]?"` will be replaced by `"Why friends?"`.
             */
            enabled: z.ZodBoolean;
            options: z.ZodOptional<z.ZodUnion<[z.ZodObject<{
                /**
                 * If set, answer data included in it will not be decapitalize.
                 */
                excludes: z.ZodArray<z.ZodString, "many">;
                includes: z.ZodOptional<z.ZodNever>;
            }, "strip", z.ZodTypeAny, {
                includes?: undefined;
                excludes: string[];
            }, {
                includes?: undefined;
                excludes: string[];
            }>, z.ZodObject<{
                /**
                 * If set, only answer data included in it will be decapitalize.
                 */
                includes: z.ZodArray<z.ZodString, "many">;
                excludes: z.ZodOptional<z.ZodNever>;
            }, "strip", z.ZodTypeAny, {
                excludes?: undefined;
                includes: string[];
            }, {
                excludes?: undefined;
                includes: string[];
            }>]>>;
        }, "strip", z.ZodTypeAny, {
            options?: {
                includes?: undefined;
                excludes: string[];
            } | {
                excludes?: undefined;
                includes: string[];
            } | undefined;
            enabled: boolean;
        }, {
            options?: {
                includes?: undefined;
                excludes: string[];
            } | {
                excludes?: undefined;
                includes: string[];
            } | undefined;
            enabled: boolean;
        }>>;
    }, "strip", z.ZodTypeAny, {
        decapitalizeFirstCharacter?: {
            options?: {
                includes?: undefined;
                excludes: string[];
            } | {
                excludes?: undefined;
                includes: string[];
            } | undefined;
            enabled: boolean;
        } | undefined;
    }, {
        decapitalizeFirstCharacter?: {
            options?: {
                includes?: undefined;
                excludes: string[];
            } | {
                excludes?: undefined;
                includes: string[];
            } | undefined;
            enabled: boolean;
        } | undefined;
    }>>>;
    /**
     * Show an alert each time the app launches.
     */
    specialAlertOnLaunch: z.ZodOptional<z.ZodObject<{
        title: z.ZodDefault<z.ZodString>;
        message: z.ZodString;
        buttonText: z.ZodDefault<z.ZodString>;
    }, "strip", z.ZodTypeAny, {
        message: string;
        title: string;
        buttonText: string;
    }, {
        title?: string | undefined;
        buttonText?: string | undefined;
        message: string;
    }>>;
}, "strip", z.ZodTypeAny, {
    version?: string | undefined;
    dashboardURL?: string | undefined;
    contactEmail?: string | undefined;
    streamsForNthPings?: Record<string, string> | undefined;
    alwaysEnableNextButton?: boolean | undefined;
    specialVariablePlaceholderTreatments?: Record<string, {
        decapitalizeFirstCharacter?: {
            options?: {
                includes?: undefined;
                excludes: string[];
            } | {
                excludes?: undefined;
                includes: string[];
            } | undefined;
            enabled: boolean;
        } | undefined;
    }> | undefined;
    specialAlertOnLaunch?: {
        message: string;
        title: string;
        buttonText: string;
    } | undefined;
    id: string;
    studyFileURL: string;
    server: {
        firebase?: {
            config: Record<string, string>;
        } | undefined;
        beiwe?: {
            serverUrl: string;
        } | undefined;
    };
    consentFormUrl: string;
    weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
    startDate: Date;
    endDate: Date;
    pingsFrequency: {
        latestPingNotificationTime?: number | undefined;
        earliestPingNotificationTime: number;
        expireAfterTime: number;
    }[];
    streamsStartingQuestionIds: Record<string, string>;
    streamsOrder: {
        0: string[];
        2: string[];
        1: string[];
        6: string[];
        3: string[];
        4: string[];
        5: string[];
    };
    streamInCaseOfError: string;
    streamsNotReplacedByFollowupStream: string[];
    notificationContent: {
        bonus?: {
            title: string;
            body: string;
            numberOfCompletionEachWeek: number;
        } | undefined;
        default: {
            title: string;
            body: string;
        };
    };
}, {
    version?: string | undefined;
    dashboardURL?: string | undefined;
    contactEmail?: string | undefined;
    streamsForNthPings?: Record<string, string> | undefined;
    alwaysEnableNextButton?: boolean | undefined;
    specialVariablePlaceholderTreatments?: Record<string, {
        decapitalizeFirstCharacter?: {
            options?: {
                includes?: undefined;
                excludes: string[];
            } | {
                excludes?: undefined;
                includes: string[];
            } | undefined;
            enabled: boolean;
        } | undefined;
    }> | undefined;
    specialAlertOnLaunch?: {
        title?: string | undefined;
        buttonText?: string | undefined;
        message: string;
    } | undefined;
    id: string;
    studyFileURL: string;
    server: {
        firebase?: {
            config: Record<string, string>;
        } | undefined;
        beiwe?: {
            serverUrl: string;
        } | undefined;
    };
    consentFormUrl: string;
    weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
    startDate: string | Date;
    endDate: string | Date;
    pingsFrequency: {
        latestPingNotificationTime?: string | number | undefined;
        earliestPingNotificationTime: string | number;
        expireAfterTime: string | number;
    }[];
    streamsStartingQuestionIds: Record<string, string>;
    streamsOrder: string[] | {
        0: string[];
        2: string[];
        1: string[];
        6: string[];
        3: string[];
        4: string[];
        5: string[];
    } | {
        sunday: string[];
        monday: string[];
        tuesday: string[];
        wednesday: string[];
        thursday: string[];
        friday: string[];
        saturday: string[];
    };
    streamInCaseOfError: string;
    streamsNotReplacedByFollowupStream: string[];
    notificationContent: {
        bonus?: {
            title: string;
            body: string;
            numberOfCompletionEachWeek: number;
        } | undefined;
        default: {
            title: string;
            body: string;
        };
    };
}>, {
    version?: string | undefined;
    dashboardURL?: string | undefined;
    contactEmail?: string | undefined;
    streamsForNthPings?: Record<string, string> | undefined;
    alwaysEnableNextButton?: boolean | undefined;
    specialVariablePlaceholderTreatments?: Record<string, {
        decapitalizeFirstCharacter?: {
            options?: {
                includes?: undefined;
                excludes: string[];
            } | {
                excludes?: undefined;
                includes: string[];
            } | undefined;
            enabled: boolean;
        } | undefined;
    }> | undefined;
    specialAlertOnLaunch?: {
        message: string;
        title: string;
        buttonText: string;
    } | undefined;
    id: string;
    studyFileURL: string;
    server: {
        firebase?: {
            config: Record<string, string>;
        } | undefined;
        beiwe?: {
            serverUrl: string;
        } | undefined;
    };
    consentFormUrl: string;
    weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
    startDate: Date;
    endDate: Date;
    pingsFrequency: {
        latestPingNotificationTime?: number | undefined;
        earliestPingNotificationTime: number;
        expireAfterTime: number;
    }[];
    streamsStartingQuestionIds: Record<string, string>;
    streamsOrder: {
        0: string[];
        2: string[];
        1: string[];
        6: string[];
        3: string[];
        4: string[];
        5: string[];
    };
    streamInCaseOfError: string;
    streamsNotReplacedByFollowupStream: string[];
    notificationContent: {
        bonus?: {
            title: string;
            body: string;
            numberOfCompletionEachWeek: number;
        } | undefined;
        default: {
            title: string;
            body: string;
        };
    };
}, {
    version?: string | undefined;
    dashboardURL?: string | undefined;
    contactEmail?: string | undefined;
    streamsForNthPings?: Record<string, string> | undefined;
    alwaysEnableNextButton?: boolean | undefined;
    specialVariablePlaceholderTreatments?: Record<string, {
        decapitalizeFirstCharacter?: {
            options?: {
                includes?: undefined;
                excludes: string[];
            } | {
                excludes?: undefined;
                includes: string[];
            } | undefined;
            enabled: boolean;
        } | undefined;
    }> | undefined;
    specialAlertOnLaunch?: {
        title?: string | undefined;
        buttonText?: string | undefined;
        message: string;
    } | undefined;
    id: string;
    studyFileURL: string;
    server: {
        firebase?: {
            config: Record<string, string>;
        } | undefined;
        beiwe?: {
            serverUrl: string;
        } | undefined;
    };
    consentFormUrl: string;
    weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
    startDate: string | Date;
    endDate: string | Date;
    pingsFrequency: {
        latestPingNotificationTime?: string | number | undefined;
        earliestPingNotificationTime: string | number;
        expireAfterTime: string | number;
    }[];
    streamsStartingQuestionIds: Record<string, string>;
    streamsOrder: string[] | {
        0: string[];
        2: string[];
        1: string[];
        6: string[];
        3: string[];
        4: string[];
        5: string[];
    } | {
        sunday: string[];
        monday: string[];
        tuesday: string[];
        wednesday: string[];
        thursday: string[];
        friday: string[];
        saturday: string[];
    };
    streamInCaseOfError: string;
    streamsNotReplacedByFollowupStream: string[];
    notificationContent: {
        bonus?: {
            title: string;
            body: string;
            numberOfCompletionEachWeek: number;
        } | undefined;
        default: {
            title: string;
            body: string;
        };
    };
}>, {
    version?: string | undefined;
    dashboardURL?: string | undefined;
    contactEmail?: string | undefined;
    streamsForNthPings?: Record<string, string> | undefined;
    alwaysEnableNextButton?: boolean | undefined;
    specialVariablePlaceholderTreatments?: Record<string, {
        decapitalizeFirstCharacter?: {
            options?: {
                includes?: undefined;
                excludes: string[];
            } | {
                excludes?: undefined;
                includes: string[];
            } | undefined;
            enabled: boolean;
        } | undefined;
    }> | undefined;
    specialAlertOnLaunch?: {
        message: string;
        title: string;
        buttonText: string;
    } | undefined;
    id: string;
    studyFileURL: string;
    server: {
        firebase?: {
            config: Record<string, string>;
        } | undefined;
        beiwe?: {
            serverUrl: string;
        } | undefined;
    };
    consentFormUrl: string;
    weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
    startDate: Date;
    endDate: Date;
    pingsFrequency: {
        latestPingNotificationTime?: number | undefined;
        earliestPingNotificationTime: number;
        expireAfterTime: number;
    }[];
    streamsStartingQuestionIds: Record<string, string>;
    streamsOrder: {
        0: string[];
        2: string[];
        1: string[];
        6: string[];
        3: string[];
        4: string[];
        5: string[];
    };
    streamInCaseOfError: string;
    streamsNotReplacedByFollowupStream: string[];
    notificationContent: {
        bonus?: {
            title: string;
            body: string;
            numberOfCompletionEachWeek: number;
        } | undefined;
        default: {
            title: string;
            body: string;
        };
    };
}, {
    version?: string | undefined;
    dashboardURL?: string | undefined;
    contactEmail?: string | undefined;
    streamsForNthPings?: Record<string, string> | undefined;
    alwaysEnableNextButton?: boolean | undefined;
    specialVariablePlaceholderTreatments?: Record<string, {
        decapitalizeFirstCharacter?: {
            options?: {
                includes?: undefined;
                excludes: string[];
            } | {
                excludes?: undefined;
                includes: string[];
            } | undefined;
            enabled: boolean;
        } | undefined;
    }> | undefined;
    specialAlertOnLaunch?: {
        title?: string | undefined;
        buttonText?: string | undefined;
        message: string;
    } | undefined;
    id: string;
    studyFileURL: string;
    server: {
        firebase?: {
            config: Record<string, string>;
        } | undefined;
        beiwe?: {
            serverUrl: string;
        } | undefined;
    };
    consentFormUrl: string;
    weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
    startDate: string | Date;
    endDate: string | Date;
    pingsFrequency: {
        latestPingNotificationTime?: string | number | undefined;
        earliestPingNotificationTime: string | number;
        expireAfterTime: string | number;
    }[];
    streamsStartingQuestionIds: Record<string, string>;
    streamsOrder: string[] | {
        0: string[];
        2: string[];
        1: string[];
        6: string[];
        3: string[];
        4: string[];
        5: string[];
    } | {
        sunday: string[];
        monday: string[];
        tuesday: string[];
        wednesday: string[];
        thursday: string[];
        friday: string[];
        saturday: string[];
    };
    streamInCaseOfError: string;
    streamsNotReplacedByFollowupStream: string[];
    notificationContent: {
        bonus?: {
            title: string;
            body: string;
            numberOfCompletionEachWeek: number;
        } | undefined;
        default: {
            title: string;
            body: string;
        };
    };
}>;
export declare const ExtraDataSchema: z.ZodObject<{
    reusableChoices: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodEffects<z.ZodArray<z.ZodString, "atleastone">, [string, ...string[]], [string, ...string[]]>>>;
}, "strip", z.ZodTypeAny, {
    reusableChoices?: Record<string, [string, ...string[]]> | undefined;
}, {
    reusableChoices?: Record<string, [string, ...string[]]> | undefined;
}> | z.ZodObject<{
    reusableChoices: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodEffects<z.ZodArray<z.ZodString, "atleastone">, [string, ...string[]], [string, ...string[]]>>>;
}, "strict", z.ZodTypeAny, {
    reusableChoices?: Record<string, [string, ...string[]]> | undefined;
}, {
    reusableChoices?: Record<string, [string, ...string[]]> | undefined;
}>;
export declare const StudyFileSchema: z.ZodObject<{
    studyInfo: z.ZodEffects<z.ZodEffects<z.ZodObject<{
        /**
         * The ID of the study.
         *
         * It can only include letters, numbers, and "_".
         */
        id: z.ZodString;
        /**
         * The version of the study.
         *
         * https://github.com/wellping/wellping/issues/94
         */
        version: z.ZodOptional<z.ZodString>;
        /**
         * The URL that host this study file (which could be a JSON or a YAML file).
         *
         * The app fetches this URL in the background at every start and loads the
         * downloaded new file at the next start.
         */
        studyFileURL: z.ZodString;
        /**
         * The URL of the dashboard that will be shown to the user on the home page.
         *
         * ---
         *
         * The placeholder `__USERNAME__` will be replaced by the user's username.
         * Notice that you should not return any sensitive data based on this field
         * as it can be changed by anyone.
         * In order to verify the user securely:
         * - If you are using Firebase, you should use the `__FIREBASE_ID_TOKEN__`
         *   placeholder as explained below.
         * - If you are using Beiwe, (A TODO: ITEM).
         *
         * If Firebase is used, the placeholder `__FIREBASE_ID_TOKEN__` will be
         * replaced by the user's Firebase Auth ID token if the user is signed in
         * to Firebase, and "N/A" otherwise.
         *
         * ---
         *
         * The following Placeholders are also provided for your convenience so that
         * you don't have to set up a full back-end server (with Firebase Admin SDK)
         * just to display the user's progress:
         *
         * The placeholder `__PINGS_COMPLETED_OVERALL__` will be replaced by the
         * number of pings the user has completed overall.
         *
         * The placeholder `__PINGS_COMPLETED_THIS_WEEK__` will be replaced by the
         * number of pings the user has completed this week (defined by
         * `weekStartsOn`).
         *
         * The placeholder `__PINGS_COMPLETED_TODAY__` will be replaced by the
         * number of pings the user has completed today.
         */
        dashboardURL: z.ZodOptional<z.ZodString>;
        /**
         * The backend server info for the study. Well Ping supports uploading to
         * Firebase or uploading to Beiwe.
         *
         * If Firebase backend is used, `server.firebase` should be defined.
         *
         * If Beiwe backend is used, `server.beiwe` should be defined.
         *
         * If this object is empty (i.e., `server: {}`), you will be able to log in
         * using any username password combination, and no data will be uploaded.
         * This is only intended for testing or demo purposes and should not be used
         * in production. (MARK: NO_SERVER_NOTE)
         *
         * Notice that in theory, both `server.firebase` and `server.beiwe` could be
         * set (meaning that the data will be uploaded to both Beiwe and Firebase).
         * However, such pratice is not thoroughly tested and is not guaranteed to
         * work correctly.
         */
        server: z.ZodObject<{
            firebase: z.ZodOptional<z.ZodObject<{
                /**
                 * The Firebase config object for the study.
                 *
                 * See https://firebase.google.com/docs/web/setup#config-object
                 */
                config: z.ZodRecord<z.ZodString, z.ZodString>;
            }, "strip", z.ZodTypeAny, {
                config: Record<string, string>;
            }, {
                config: Record<string, string>;
            }>>;
            beiwe: z.ZodOptional<z.ZodObject<{
                /**
                 * The server URL of Beiwe backend for the study.
                 *
                 * Example: `"https://beiwe.example.com/"`
                 */
                serverUrl: z.ZodString;
            }, "strip", z.ZodTypeAny, {
                serverUrl: string;
            }, {
                serverUrl: string;
            }>>;
        }, "strip", z.ZodTypeAny, {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        }, {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        }>;
        /**
         * The URL of the study consent form (or any web page you would want the
         * user to see before they begin).
         *
         * This web page will be displayed after the user successfully logs in.
         */
        consentFormUrl: z.ZodString;
        /**
         * The email address that the user could contact for questions regarding the
         * study or the app.
         *
         * If this field is set, a "Contact Staff" button will appear at the top of
         * the screen.
         */
        contactEmail: z.ZodOptional<z.ZodString>;
        /**
         * The first day of the week.
         *
         * 0 is Sunday.
         */
        weekStartsOn: z.ZodUnion<[z.ZodLiteral<0>, z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>, z.ZodLiteral<5>, z.ZodLiteral<6>]>;
        /**
         * The start date (time) of the study.
         *
         * The first ping will be sent after this time.
         *
         * Timezone in this date string is ignored.
         */
        startDate: z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, Date, string>, z.ZodDate]>;
        /**
         * The end date (time) of the study.
         *
         * The last ping will be sent before this time.
         *
         * Timezone in this date string is ignored.
         */
        endDate: z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, Date, string>, z.ZodDate]>;
        /**
         * The time every day that ping notifications will be sent.
         *
         * Notice that the duration between every
         * `pingsFrequency[i].latestPingNotificationTime` and
         * `pingsFrequency[i+1].earliestPingNotificationTime`
         * should be greater than
         * `pingsFrequency[i].expireAfterTime`
         * so that the user will always have enough time to complete the ping no matter
         * what time they receive the ping.
         */
        pingsFrequency: z.ZodArray<z.ZodEffects<z.ZodObject<{
            /**
             * The earliest time that the ping will be sent (inclusive).
             */
            earliestPingNotificationTime: z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, number, string>, z.ZodNumber]>;
            /**
             * The latest time that the ping will be sent (inclusive).
             * If this is not specified, the ping will be sent exactly at
             * `earliestPingNotificationTime`.
             * If this is specified, the ping will be sent at a random time between
             * `earliestPingNotificationTime` and `latestPingNotificationTime`.
             */
            latestPingNotificationTime: z.ZodOptional<z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, number, string>, z.ZodNumber]>>;
            /**
             * A ping will expire after this amount of time (after the notification
             * time).
             *
             * For example, if the user receives a ping notification on 10:00:00AM,
             * and `expireAfterTime` is set to `00:45:00`, the user will no longer
             * be able to complete this ping after 10:45:00AM.
             */
            expireAfterTime: z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, number, string>, z.ZodNumber]>;
        }, "strip", z.ZodTypeAny, {
            latestPingNotificationTime?: number | undefined;
            earliestPingNotificationTime: number;
            expireAfterTime: number;
        }, {
            latestPingNotificationTime?: string | number | undefined;
            earliestPingNotificationTime: string | number;
            expireAfterTime: string | number;
        }>, {
            latestPingNotificationTime?: number | undefined;
            earliestPingNotificationTime: number;
            expireAfterTime: number;
        }, {
            latestPingNotificationTime?: string | number | undefined;
            earliestPingNotificationTime: string | number;
            expireAfterTime: string | number;
        }>, "many">;
        /**
         * The question ID of the first question of each stream.
         */
        streamsStartingQuestionIds: z.ZodRecord<z.ZodString, z.ZodString>;
        /**
         * The streams that the user will fill (in this order) every day.
         *
         * For example, if `streamsOrder.sunday` is `["dog", "cat", "wolf", "lynx"]`,
         * then on Sunday, if the user opens all four pings they received, they
         * will fill the "dog", "cat", "wolf", and "lynx" stream (in this order).
         * If the user only opens two pings, they will fill the "dog" and "cat"
         * stream (in this order).
         *
         * The number of elements each day should be equal to the number of elements
         * in `pingsFrequency` above.
         */
        streamsOrder: z.ZodUnion<[z.ZodObject<{
            0: z.ZodArray<z.ZodString, "many">;
            1: z.ZodArray<z.ZodString, "many">;
            2: z.ZodArray<z.ZodString, "many">;
            3: z.ZodArray<z.ZodString, "many">;
            4: z.ZodArray<z.ZodString, "many">;
            5: z.ZodArray<z.ZodString, "many">;
            6: z.ZodArray<z.ZodString, "many">;
        }, "strip", z.ZodTypeAny, {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        }, {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        }>, z.ZodEffects<z.ZodObject<{
            sunday: z.ZodArray<z.ZodString, "many">;
            monday: z.ZodArray<z.ZodString, "many">;
            tuesday: z.ZodArray<z.ZodString, "many">;
            wednesday: z.ZodArray<z.ZodString, "many">;
            thursday: z.ZodArray<z.ZodString, "many">;
            friday: z.ZodArray<z.ZodString, "many">;
            saturday: z.ZodArray<z.ZodString, "many">;
        }, "strip", z.ZodTypeAny, {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        }, {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        }>, {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        }, {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        }>, z.ZodEffects<z.ZodArray<z.ZodString, "many">, {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        }, string[]>]>;
        /**
         * The stream type(s) for n-th ping(s). The key is the "n" in "n-th ping".
         * This will **replace** the originally sceduled stream type for that ping.
         *
         * For example,
         * ```{json}
         * "streamsForNthPings": {
         *   "1": "demographic",
         *   "10": "interests"
         * }
         * ```
         * means that the user's first ping will be `"demographic"` stream and the
         * user's 10th ping will be `"interests"` stream.
         */
        streamsForNthPings: z.ZodEffects<z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>, Record<string, string> | undefined, Record<string, string> | undefined>;
        /**
         * The stream that the user will see if there is any error in `streamsOrder`.
         */
        streamInCaseOfError: z.ZodString;
        /**
         * The streams that will not be replaced by followup streams
         * (when a YesNo question's `addFollowupStream` is set).
         */
        streamsNotReplacedByFollowupStream: z.ZodArray<z.ZodString, "many">;
        notificationContent: z.ZodObject<{
            /**
             * The default notification title and body.
             */
            default: z.ZodObject<{
                title: z.ZodString;
                body: z.ZodString;
            }, "strip", z.ZodTypeAny, {
                title: string;
                body: string;
            }, {
                title: string;
                body: string;
            }>;
            /**
             * If set, the `bonus` content for the notification will be used until
             * the number of survey completed that week is greater than
             * `bonus.numberOfCompletionEachWeek - 1`.
             *
             * "#n_ping#" in `title` and `body` will be replaced by "5 pings" or
             * "1 ping".
             *
             * Example:
             * ```
             * bonus: {
             *    title: "You can earn bonus!",
             *    body: "You are #n_ping# away from the weekly bonus.",
             *    numberOfCompletionEachWeek: 5,
             * },
             * ```
             */
            bonus: z.ZodOptional<z.ZodObject<{
                title: z.ZodString;
                body: z.ZodString;
                numberOfCompletionEachWeek: z.ZodNumber;
            }, "strip", z.ZodTypeAny, {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            }, {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            }>>;
        }, "strip", z.ZodTypeAny, {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        }, {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        }>;
        /**
         * If `true`, the "Next" button will always be enabled.
         * If `false` or undefined, the "Next" button will only be enabled after the
         * user has interacted with the question.
         */
        alwaysEnableNextButton: z.ZodOptional<z.ZodBoolean>;
        /**
         * Special treatments for variable placeholders. The key of each record is
         * the variable name as defined by supported question's `variableName`, or a
         * question ID (if you want to replace the placeholder with a previous
         * question's answer).
         */
        specialVariablePlaceholderTreatments: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
            decapitalizeFirstCharacter: z.ZodOptional<z.ZodObject<{
                /**
                 * The first character of the answer data replacing the placeholder will be
                 * decapitalized.
                 *
                 * For example, if the answer is `"Friends"` and the variable is `"CONTACT"`,
                 * and `decapitalizeFirstCharacter.enabled` is `true`,
                 * and `decapitalizeFirstCharacter.excludes` does not include `"Friends"`
                 * (or if `decapitalizeFirstCharacter.includes` includes `"Friends"`),
                 * then `"Why [__CONTACT__]?"` will be replaced by `"Why friends?"`.
                 */
                enabled: z.ZodBoolean;
                options: z.ZodOptional<z.ZodUnion<[z.ZodObject<{
                    /**
                     * If set, answer data included in it will not be decapitalize.
                     */
                    excludes: z.ZodArray<z.ZodString, "many">;
                    includes: z.ZodOptional<z.ZodNever>;
                }, "strip", z.ZodTypeAny, {
                    includes?: undefined;
                    excludes: string[];
                }, {
                    includes?: undefined;
                    excludes: string[];
                }>, z.ZodObject<{
                    /**
                     * If set, only answer data included in it will be decapitalize.
                     */
                    includes: z.ZodArray<z.ZodString, "many">;
                    excludes: z.ZodOptional<z.ZodNever>;
                }, "strip", z.ZodTypeAny, {
                    excludes?: undefined;
                    includes: string[];
                }, {
                    excludes?: undefined;
                    includes: string[];
                }>]>>;
            }, "strip", z.ZodTypeAny, {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            }, {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            }>>;
        }, "strip", z.ZodTypeAny, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }>>>;
        /**
         * Show an alert each time the app launches.
         */
        specialAlertOnLaunch: z.ZodOptional<z.ZodObject<{
            title: z.ZodDefault<z.ZodString>;
            message: z.ZodString;
            buttonText: z.ZodDefault<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            message: string;
            title: string;
            buttonText: string;
        }, {
            title?: string | undefined;
            buttonText?: string | undefined;
            message: string;
        }>>;
    }, "strict", z.ZodTypeAny, {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            message: string;
            title: string;
            buttonText: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: Date;
        endDate: Date;
        pingsFrequency: {
            latestPingNotificationTime?: number | undefined;
            earliestPingNotificationTime: number;
            expireAfterTime: number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    }, {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            title?: string | undefined;
            buttonText?: string | undefined;
            message: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: string | Date;
        endDate: string | Date;
        pingsFrequency: {
            latestPingNotificationTime?: string | number | undefined;
            earliestPingNotificationTime: string | number;
            expireAfterTime: string | number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: string[] | {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        } | {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    }>, {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            message: string;
            title: string;
            buttonText: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: Date;
        endDate: Date;
        pingsFrequency: {
            latestPingNotificationTime?: number | undefined;
            earliestPingNotificationTime: number;
            expireAfterTime: number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    }, {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            title?: string | undefined;
            buttonText?: string | undefined;
            message: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: string | Date;
        endDate: string | Date;
        pingsFrequency: {
            latestPingNotificationTime?: string | number | undefined;
            earliestPingNotificationTime: string | number;
            expireAfterTime: string | number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: string[] | {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        } | {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    }>, {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            message: string;
            title: string;
            buttonText: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: Date;
        endDate: Date;
        pingsFrequency: {
            latestPingNotificationTime?: number | undefined;
            earliestPingNotificationTime: number;
            expireAfterTime: number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    }, {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            title?: string | undefined;
            buttonText?: string | undefined;
            message: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: string | Date;
        endDate: string | Date;
        pingsFrequency: {
            latestPingNotificationTime?: string | number | undefined;
            earliestPingNotificationTime: string | number;
            expireAfterTime: string | number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: string[] | {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        } | {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    }> | z.ZodEffects<z.ZodEffects<z.ZodObject<{
        /**
         * The ID of the study.
         *
         * It can only include letters, numbers, and "_".
         */
        id: z.ZodString;
        /**
         * The version of the study.
         *
         * https://github.com/wellping/wellping/issues/94
         */
        version: z.ZodOptional<z.ZodString>;
        /**
         * The URL that host this study file (which could be a JSON or a YAML file).
         *
         * The app fetches this URL in the background at every start and loads the
         * downloaded new file at the next start.
         */
        studyFileURL: z.ZodString;
        /**
         * The URL of the dashboard that will be shown to the user on the home page.
         *
         * ---
         *
         * The placeholder `__USERNAME__` will be replaced by the user's username.
         * Notice that you should not return any sensitive data based on this field
         * as it can be changed by anyone.
         * In order to verify the user securely:
         * - If you are using Firebase, you should use the `__FIREBASE_ID_TOKEN__`
         *   placeholder as explained below.
         * - If you are using Beiwe, (A TODO: ITEM).
         *
         * If Firebase is used, the placeholder `__FIREBASE_ID_TOKEN__` will be
         * replaced by the user's Firebase Auth ID token if the user is signed in
         * to Firebase, and "N/A" otherwise.
         *
         * ---
         *
         * The following Placeholders are also provided for your convenience so that
         * you don't have to set up a full back-end server (with Firebase Admin SDK)
         * just to display the user's progress:
         *
         * The placeholder `__PINGS_COMPLETED_OVERALL__` will be replaced by the
         * number of pings the user has completed overall.
         *
         * The placeholder `__PINGS_COMPLETED_THIS_WEEK__` will be replaced by the
         * number of pings the user has completed this week (defined by
         * `weekStartsOn`).
         *
         * The placeholder `__PINGS_COMPLETED_TODAY__` will be replaced by the
         * number of pings the user has completed today.
         */
        dashboardURL: z.ZodOptional<z.ZodString>;
        /**
         * The backend server info for the study. Well Ping supports uploading to
         * Firebase or uploading to Beiwe.
         *
         * If Firebase backend is used, `server.firebase` should be defined.
         *
         * If Beiwe backend is used, `server.beiwe` should be defined.
         *
         * If this object is empty (i.e., `server: {}`), you will be able to log in
         * using any username password combination, and no data will be uploaded.
         * This is only intended for testing or demo purposes and should not be used
         * in production. (MARK: NO_SERVER_NOTE)
         *
         * Notice that in theory, both `server.firebase` and `server.beiwe` could be
         * set (meaning that the data will be uploaded to both Beiwe and Firebase).
         * However, such pratice is not thoroughly tested and is not guaranteed to
         * work correctly.
         */
        server: z.ZodObject<{
            firebase: z.ZodOptional<z.ZodObject<{
                /**
                 * The Firebase config object for the study.
                 *
                 * See https://firebase.google.com/docs/web/setup#config-object
                 */
                config: z.ZodRecord<z.ZodString, z.ZodString>;
            }, "strip", z.ZodTypeAny, {
                config: Record<string, string>;
            }, {
                config: Record<string, string>;
            }>>;
            beiwe: z.ZodOptional<z.ZodObject<{
                /**
                 * The server URL of Beiwe backend for the study.
                 *
                 * Example: `"https://beiwe.example.com/"`
                 */
                serverUrl: z.ZodString;
            }, "strip", z.ZodTypeAny, {
                serverUrl: string;
            }, {
                serverUrl: string;
            }>>;
        }, "strip", z.ZodTypeAny, {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        }, {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        }>;
        /**
         * The URL of the study consent form (or any web page you would want the
         * user to see before they begin).
         *
         * This web page will be displayed after the user successfully logs in.
         */
        consentFormUrl: z.ZodString;
        /**
         * The email address that the user could contact for questions regarding the
         * study or the app.
         *
         * If this field is set, a "Contact Staff" button will appear at the top of
         * the screen.
         */
        contactEmail: z.ZodOptional<z.ZodString>;
        /**
         * The first day of the week.
         *
         * 0 is Sunday.
         */
        weekStartsOn: z.ZodUnion<[z.ZodLiteral<0>, z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>, z.ZodLiteral<5>, z.ZodLiteral<6>]>;
        /**
         * The start date (time) of the study.
         *
         * The first ping will be sent after this time.
         *
         * Timezone in this date string is ignored.
         */
        startDate: z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, Date, string>, z.ZodDate]>;
        /**
         * The end date (time) of the study.
         *
         * The last ping will be sent before this time.
         *
         * Timezone in this date string is ignored.
         */
        endDate: z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, Date, string>, z.ZodDate]>;
        /**
         * The time every day that ping notifications will be sent.
         *
         * Notice that the duration between every
         * `pingsFrequency[i].latestPingNotificationTime` and
         * `pingsFrequency[i+1].earliestPingNotificationTime`
         * should be greater than
         * `pingsFrequency[i].expireAfterTime`
         * so that the user will always have enough time to complete the ping no matter
         * what time they receive the ping.
         */
        pingsFrequency: z.ZodArray<z.ZodEffects<z.ZodObject<{
            /**
             * The earliest time that the ping will be sent (inclusive).
             */
            earliestPingNotificationTime: z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, number, string>, z.ZodNumber]>;
            /**
             * The latest time that the ping will be sent (inclusive).
             * If this is not specified, the ping will be sent exactly at
             * `earliestPingNotificationTime`.
             * If this is specified, the ping will be sent at a random time between
             * `earliestPingNotificationTime` and `latestPingNotificationTime`.
             */
            latestPingNotificationTime: z.ZodOptional<z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, number, string>, z.ZodNumber]>>;
            /**
             * A ping will expire after this amount of time (after the notification
             * time).
             *
             * For example, if the user receives a ping notification on 10:00:00AM,
             * and `expireAfterTime` is set to `00:45:00`, the user will no longer
             * be able to complete this ping after 10:45:00AM.
             */
            expireAfterTime: z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, number, string>, z.ZodNumber]>;
        }, "strip", z.ZodTypeAny, {
            latestPingNotificationTime?: number | undefined;
            earliestPingNotificationTime: number;
            expireAfterTime: number;
        }, {
            latestPingNotificationTime?: string | number | undefined;
            earliestPingNotificationTime: string | number;
            expireAfterTime: string | number;
        }>, {
            latestPingNotificationTime?: number | undefined;
            earliestPingNotificationTime: number;
            expireAfterTime: number;
        }, {
            latestPingNotificationTime?: string | number | undefined;
            earliestPingNotificationTime: string | number;
            expireAfterTime: string | number;
        }>, "many">;
        /**
         * The question ID of the first question of each stream.
         */
        streamsStartingQuestionIds: z.ZodRecord<z.ZodString, z.ZodString>;
        /**
         * The streams that the user will fill (in this order) every day.
         *
         * For example, if `streamsOrder.sunday` is `["dog", "cat", "wolf", "lynx"]`,
         * then on Sunday, if the user opens all four pings they received, they
         * will fill the "dog", "cat", "wolf", and "lynx" stream (in this order).
         * If the user only opens two pings, they will fill the "dog" and "cat"
         * stream (in this order).
         *
         * The number of elements each day should be equal to the number of elements
         * in `pingsFrequency` above.
         */
        streamsOrder: z.ZodUnion<[z.ZodObject<{
            0: z.ZodArray<z.ZodString, "many">;
            1: z.ZodArray<z.ZodString, "many">;
            2: z.ZodArray<z.ZodString, "many">;
            3: z.ZodArray<z.ZodString, "many">;
            4: z.ZodArray<z.ZodString, "many">;
            5: z.ZodArray<z.ZodString, "many">;
            6: z.ZodArray<z.ZodString, "many">;
        }, "strip", z.ZodTypeAny, {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        }, {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        }>, z.ZodEffects<z.ZodObject<{
            sunday: z.ZodArray<z.ZodString, "many">;
            monday: z.ZodArray<z.ZodString, "many">;
            tuesday: z.ZodArray<z.ZodString, "many">;
            wednesday: z.ZodArray<z.ZodString, "many">;
            thursday: z.ZodArray<z.ZodString, "many">;
            friday: z.ZodArray<z.ZodString, "many">;
            saturday: z.ZodArray<z.ZodString, "many">;
        }, "strip", z.ZodTypeAny, {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        }, {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        }>, {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        }, {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        }>, z.ZodEffects<z.ZodArray<z.ZodString, "many">, {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        }, string[]>]>;
        /**
         * The stream type(s) for n-th ping(s). The key is the "n" in "n-th ping".
         * This will **replace** the originally sceduled stream type for that ping.
         *
         * For example,
         * ```{json}
         * "streamsForNthPings": {
         *   "1": "demographic",
         *   "10": "interests"
         * }
         * ```
         * means that the user's first ping will be `"demographic"` stream and the
         * user's 10th ping will be `"interests"` stream.
         */
        streamsForNthPings: z.ZodEffects<z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>, Record<string, string> | undefined, Record<string, string> | undefined>;
        /**
         * The stream that the user will see if there is any error in `streamsOrder`.
         */
        streamInCaseOfError: z.ZodString;
        /**
         * The streams that will not be replaced by followup streams
         * (when a YesNo question's `addFollowupStream` is set).
         */
        streamsNotReplacedByFollowupStream: z.ZodArray<z.ZodString, "many">;
        notificationContent: z.ZodObject<{
            /**
             * The default notification title and body.
             */
            default: z.ZodObject<{
                title: z.ZodString;
                body: z.ZodString;
            }, "strip", z.ZodTypeAny, {
                title: string;
                body: string;
            }, {
                title: string;
                body: string;
            }>;
            /**
             * If set, the `bonus` content for the notification will be used until
             * the number of survey completed that week is greater than
             * `bonus.numberOfCompletionEachWeek - 1`.
             *
             * "#n_ping#" in `title` and `body` will be replaced by "5 pings" or
             * "1 ping".
             *
             * Example:
             * ```
             * bonus: {
             *    title: "You can earn bonus!",
             *    body: "You are #n_ping# away from the weekly bonus.",
             *    numberOfCompletionEachWeek: 5,
             * },
             * ```
             */
            bonus: z.ZodOptional<z.ZodObject<{
                title: z.ZodString;
                body: z.ZodString;
                numberOfCompletionEachWeek: z.ZodNumber;
            }, "strip", z.ZodTypeAny, {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            }, {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            }>>;
        }, "strip", z.ZodTypeAny, {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        }, {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        }>;
        /**
         * If `true`, the "Next" button will always be enabled.
         * If `false` or undefined, the "Next" button will only be enabled after the
         * user has interacted with the question.
         */
        alwaysEnableNextButton: z.ZodOptional<z.ZodBoolean>;
        /**
         * Special treatments for variable placeholders. The key of each record is
         * the variable name as defined by supported question's `variableName`, or a
         * question ID (if you want to replace the placeholder with a previous
         * question's answer).
         */
        specialVariablePlaceholderTreatments: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
            decapitalizeFirstCharacter: z.ZodOptional<z.ZodObject<{
                /**
                 * The first character of the answer data replacing the placeholder will be
                 * decapitalized.
                 *
                 * For example, if the answer is `"Friends"` and the variable is `"CONTACT"`,
                 * and `decapitalizeFirstCharacter.enabled` is `true`,
                 * and `decapitalizeFirstCharacter.excludes` does not include `"Friends"`
                 * (or if `decapitalizeFirstCharacter.includes` includes `"Friends"`),
                 * then `"Why [__CONTACT__]?"` will be replaced by `"Why friends?"`.
                 */
                enabled: z.ZodBoolean;
                options: z.ZodOptional<z.ZodUnion<[z.ZodObject<{
                    /**
                     * If set, answer data included in it will not be decapitalize.
                     */
                    excludes: z.ZodArray<z.ZodString, "many">;
                    includes: z.ZodOptional<z.ZodNever>;
                }, "strip", z.ZodTypeAny, {
                    includes?: undefined;
                    excludes: string[];
                }, {
                    includes?: undefined;
                    excludes: string[];
                }>, z.ZodObject<{
                    /**
                     * If set, only answer data included in it will be decapitalize.
                     */
                    includes: z.ZodArray<z.ZodString, "many">;
                    excludes: z.ZodOptional<z.ZodNever>;
                }, "strip", z.ZodTypeAny, {
                    excludes?: undefined;
                    includes: string[];
                }, {
                    excludes?: undefined;
                    includes: string[];
                }>]>>;
            }, "strip", z.ZodTypeAny, {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            }, {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            }>>;
        }, "strip", z.ZodTypeAny, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }>>>;
        /**
         * Show an alert each time the app launches.
         */
        specialAlertOnLaunch: z.ZodOptional<z.ZodObject<{
            title: z.ZodDefault<z.ZodString>;
            message: z.ZodString;
            buttonText: z.ZodDefault<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            message: string;
            title: string;
            buttonText: string;
        }, {
            title?: string | undefined;
            buttonText?: string | undefined;
            message: string;
        }>>;
    }, "strip", z.ZodTypeAny, {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            message: string;
            title: string;
            buttonText: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: Date;
        endDate: Date;
        pingsFrequency: {
            latestPingNotificationTime?: number | undefined;
            earliestPingNotificationTime: number;
            expireAfterTime: number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    }, {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            title?: string | undefined;
            buttonText?: string | undefined;
            message: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: string | Date;
        endDate: string | Date;
        pingsFrequency: {
            latestPingNotificationTime?: string | number | undefined;
            earliestPingNotificationTime: string | number;
            expireAfterTime: string | number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: string[] | {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        } | {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    }>, {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            message: string;
            title: string;
            buttonText: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: Date;
        endDate: Date;
        pingsFrequency: {
            latestPingNotificationTime?: number | undefined;
            earliestPingNotificationTime: number;
            expireAfterTime: number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    }, {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            title?: string | undefined;
            buttonText?: string | undefined;
            message: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: string | Date;
        endDate: string | Date;
        pingsFrequency: {
            latestPingNotificationTime?: string | number | undefined;
            earliestPingNotificationTime: string | number;
            expireAfterTime: string | number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: string[] | {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        } | {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    }>, {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            message: string;
            title: string;
            buttonText: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: Date;
        endDate: Date;
        pingsFrequency: {
            latestPingNotificationTime?: number | undefined;
            earliestPingNotificationTime: number;
            expireAfterTime: number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    }, {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            title?: string | undefined;
            buttonText?: string | undefined;
            message: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: string | Date;
        endDate: string | Date;
        pingsFrequency: {
            latestPingNotificationTime?: string | number | undefined;
            earliestPingNotificationTime: string | number;
            expireAfterTime: string | number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: string[] | {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        } | {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    }>;
    streams: z.ZodRecord<z.ZodString, z.ZodEffects<z.ZodEffects<z.ZodRecord<z.ZodString, z.ZodEffects<z.ZodUnion<[z.ZodEffects<z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"Slider">;
        slider: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        minimumValue: z.ZodOptional<z.ZodNumber>;
        maximumValue: z.ZodOptional<z.ZodNumber>;
        step: z.ZodOptional<z.ZodNumber>;
        defaultValue: z.ZodOptional<z.ZodNumber>;
        defaultValueFromQuestionId: z.ZodOptional<z.ZodString>;
        displayCurrentValueToUser: z.ZodOptional<z.ZodBoolean>;
    }>, "strict", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    }> | z.ZodEffects<z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"Slider">;
        slider: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        minimumValue: z.ZodOptional<z.ZodNumber>;
        maximumValue: z.ZodOptional<z.ZodNumber>;
        step: z.ZodOptional<z.ZodNumber>;
        defaultValue: z.ZodOptional<z.ZodNumber>;
        defaultValueFromQuestionId: z.ZodOptional<z.ZodString>;
        displayCurrentValueToUser: z.ZodOptional<z.ZodBoolean>;
    }>, "strip", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    }>, z.ZodEffects<z.ZodEffects<z.ZodEffects<z.ZodEffects<z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodUnion<[z.ZodLiteral<"ChoicesWithSingleAnswer">, z.ZodLiteral<"ChoicesWithMultipleAnswers">]>;
        choices: z.ZodUnion<[z.ZodString, z.ZodEffects<z.ZodArray<z.ZodString, "atleastone">, [string, ...string[]], [string, ...string[]]>]>;
        specialCasesStartId: z.ZodOptional<z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodNullable<z.ZodString>], null>, "many">>;
        randomizeChoicesOrder: z.ZodOptional<z.ZodBoolean>;
        randomizeExceptForChoiceIds: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
    }>, "strip", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }> | z.ZodEffects<z.ZodEffects<z.ZodEffects<z.ZodEffects<z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodUnion<[z.ZodLiteral<"ChoicesWithSingleAnswer">, z.ZodLiteral<"ChoicesWithMultipleAnswers">]>;
        choices: z.ZodUnion<[z.ZodString, z.ZodEffects<z.ZodArray<z.ZodString, "atleastone">, [string, ...string[]], [string, ...string[]]>]>;
        specialCasesStartId: z.ZodOptional<z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodNullable<z.ZodString>], null>, "many">>;
        randomizeChoicesOrder: z.ZodOptional<z.ZodBoolean>;
        randomizeExceptForChoiceIds: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
    }>, "strict", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, z.ZodEffects<z.ZodEffects<z.ZodEffects<z.ZodEffects<z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodUnion<[z.ZodLiteral<"ChoicesWithSingleAnswer">, z.ZodLiteral<"ChoicesWithMultipleAnswers">]>;
        choices: z.ZodUnion<[z.ZodString, z.ZodEffects<z.ZodArray<z.ZodString, "atleastone">, [string, ...string[]], [string, ...string[]]>]>;
        specialCasesStartId: z.ZodOptional<z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodNullable<z.ZodString>], null>, "many">>;
        randomizeChoicesOrder: z.ZodOptional<z.ZodBoolean>;
        randomizeExceptForChoiceIds: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
    }>, "strip", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }> | z.ZodEffects<z.ZodEffects<z.ZodEffects<z.ZodEffects<z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodUnion<[z.ZodLiteral<"ChoicesWithSingleAnswer">, z.ZodLiteral<"ChoicesWithMultipleAnswers">]>;
        choices: z.ZodUnion<[z.ZodString, z.ZodEffects<z.ZodArray<z.ZodString, "atleastone">, [string, ...string[]], [string, ...string[]]>]>;
        specialCasesStartId: z.ZodOptional<z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodNullable<z.ZodString>], null>, "many">>;
        randomizeChoicesOrder: z.ZodOptional<z.ZodBoolean>;
        randomizeExceptForChoiceIds: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
    }>, "strict", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"YesNo">;
        branchStartId: z.ZodOptional<z.ZodObject<{
            yes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            no: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strict", z.ZodTypeAny, {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        }, {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        }>>;
        /**
         * The end date (time) of the study.
         *
         * The last ping will be sent before this time.
         *
         * Timezone in this date string is ignored.
         */
        addFollowupStream: z.ZodOptional<z.ZodObject<{
            yes: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            yes?: string | undefined;
        }, {
            yes?: string | undefined;
        }>>;
    }>, "strict", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        branchStartId?: {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        } | undefined;
        addFollowupStream?: {
            yes?: string | undefined;
        } | undefined;
        type: "YesNo";
        id: string;
        question: string;
        next: string | null;
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        branchStartId?: {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        } | undefined;
        addFollowupStream?: {
            yes?: string | undefined;
        } | undefined;
        type: "YesNo";
        id: string;
        question: string;
        next: string | null;
    }> | z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"YesNo">;
        branchStartId: z.ZodOptional<z.ZodObject<{
            yes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            no: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strict", z.ZodTypeAny, {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        }, {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        }>>;
        /**
         * The end date (time) of the study.
         *
         * The last ping will be sent before this time.
         *
         * Timezone in this date string is ignored.
         */
        addFollowupStream: z.ZodOptional<z.ZodObject<{
            yes: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            yes?: string | undefined;
        }, {
            yes?: string | undefined;
        }>>;
    }>, "strip", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        branchStartId?: {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        } | undefined;
        addFollowupStream?: {
            yes?: string | undefined;
        } | undefined;
        type: "YesNo";
        id: string;
        question: string;
        next: string | null;
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        branchStartId?: {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        } | undefined;
        addFollowupStream?: {
            yes?: string | undefined;
        } | undefined;
        type: "YesNo";
        id: string;
        question: string;
        next: string | null;
    }>, z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"MultipleText">;
        indexName: z.ZodString;
        variableName: z.ZodString;
        placeholder: z.ZodOptional<z.ZodString>;
        keyboardType: z.ZodOptional<z.ZodString>;
        dropdownChoices: z.ZodOptional<z.ZodObject<{
            choices: z.ZodUnion<[z.ZodString, z.ZodEffects<z.ZodArray<z.ZodString, "atleastone">, [string, ...string[]], [string, ...string[]]>]>;
            forceChoice: z.ZodOptional<z.ZodBoolean>;
            alwaysShowChoices: z.ZodOptional<z.ZodBoolean>;
        }, "strip", z.ZodTypeAny, {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        }, {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        }>>;
        max: z.ZodNumber;
        maxMinus: z.ZodOptional<z.ZodString>;
        repeatedItemStartId: z.ZodOptional<z.ZodString>;
    }>, "strict", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        placeholder?: string | undefined;
        keyboardType?: string | undefined;
        dropdownChoices?: {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        } | undefined;
        maxMinus?: string | undefined;
        repeatedItemStartId?: string | undefined;
        type: "MultipleText";
        id: string;
        question: string;
        next: string | null;
        indexName: string;
        variableName: string;
        max: number;
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        placeholder?: string | undefined;
        keyboardType?: string | undefined;
        dropdownChoices?: {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        } | undefined;
        maxMinus?: string | undefined;
        repeatedItemStartId?: string | undefined;
        type: "MultipleText";
        id: string;
        question: string;
        next: string | null;
        indexName: string;
        variableName: string;
        max: number;
    }> | z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"MultipleText">;
        indexName: z.ZodString;
        variableName: z.ZodString;
        placeholder: z.ZodOptional<z.ZodString>;
        keyboardType: z.ZodOptional<z.ZodString>;
        dropdownChoices: z.ZodOptional<z.ZodObject<{
            choices: z.ZodUnion<[z.ZodString, z.ZodEffects<z.ZodArray<z.ZodString, "atleastone">, [string, ...string[]], [string, ...string[]]>]>;
            forceChoice: z.ZodOptional<z.ZodBoolean>;
            alwaysShowChoices: z.ZodOptional<z.ZodBoolean>;
        }, "strip", z.ZodTypeAny, {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        }, {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        }>>;
        max: z.ZodNumber;
        maxMinus: z.ZodOptional<z.ZodString>;
        repeatedItemStartId: z.ZodOptional<z.ZodString>;
    }>, "strip", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        placeholder?: string | undefined;
        keyboardType?: string | undefined;
        dropdownChoices?: {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        } | undefined;
        maxMinus?: string | undefined;
        repeatedItemStartId?: string | undefined;
        type: "MultipleText";
        id: string;
        question: string;
        next: string | null;
        indexName: string;
        variableName: string;
        max: number;
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        placeholder?: string | undefined;
        keyboardType?: string | undefined;
        dropdownChoices?: {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        } | undefined;
        maxMinus?: string | undefined;
        repeatedItemStartId?: string | undefined;
        type: "MultipleText";
        id: string;
        question: string;
        next: string | null;
        indexName: string;
        variableName: string;
        max: number;
    }>, z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"HowLongAgo">;
    }>, "strict", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "HowLongAgo";
        id: string;
        question: string;
        next: string | null;
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "HowLongAgo";
        id: string;
        question: string;
        next: string | null;
    }> | z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"HowLongAgo">;
    }>, "strip", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "HowLongAgo";
        id: string;
        question: string;
        next: string | null;
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "HowLongAgo";
        id: string;
        question: string;
        next: string | null;
    }>, z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"Branch">;
        condition: z.ZodObject<{
            questionId: z.ZodString;
            questionType: z.ZodUnion<[z.ZodLiteral<"MultipleText">, z.ZodLiteral<"ChoicesWithSingleAnswer">]>;
            compare: z.ZodLiteral<"equal">;
            target: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
        }, "strip", z.ZodTypeAny, {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        }, {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        }>;
        branchStartId: z.ZodObject<{
            true: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            false: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            true?: string | null | undefined;
            false?: string | null | undefined;
        }, {
            true?: string | null | undefined;
            false?: string | null | undefined;
        }>;
    }>, "strict", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Branch";
        id: string;
        question: string;
        next: string | null;
        branchStartId: {
            true?: string | null | undefined;
            false?: string | null | undefined;
        };
        condition: {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        };
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Branch";
        id: string;
        question: string;
        next: string | null;
        branchStartId: {
            true?: string | null | undefined;
            false?: string | null | undefined;
        };
        condition: {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        };
    }> | z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"Branch">;
        condition: z.ZodObject<{
            questionId: z.ZodString;
            questionType: z.ZodUnion<[z.ZodLiteral<"MultipleText">, z.ZodLiteral<"ChoicesWithSingleAnswer">]>;
            compare: z.ZodLiteral<"equal">;
            target: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
        }, "strip", z.ZodTypeAny, {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        }, {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        }>;
        branchStartId: z.ZodObject<{
            true: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            false: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            true?: string | null | undefined;
            false?: string | null | undefined;
        }, {
            true?: string | null | undefined;
            false?: string | null | undefined;
        }>;
    }>, "strip", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Branch";
        id: string;
        question: string;
        next: string | null;
        branchStartId: {
            true?: string | null | undefined;
            false?: string | null | undefined;
        };
        condition: {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        };
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Branch";
        id: string;
        question: string;
        next: string | null;
        branchStartId: {
            true?: string | null | undefined;
            false?: string | null | undefined;
        };
        condition: {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        };
    }>, z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"BranchWithRelativeComparison">;
        branchStartId: z.ZodRecord<z.ZodString, z.ZodNullable<z.ZodString>>;
    }>, "strict", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "BranchWithRelativeComparison";
        id: string;
        question: string;
        next: string | null;
        branchStartId: Record<string, string | null>;
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "BranchWithRelativeComparison";
        id: string;
        question: string;
        next: string | null;
        branchStartId: Record<string, string | null>;
    }> | z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"BranchWithRelativeComparison">;
        branchStartId: z.ZodRecord<z.ZodString, z.ZodNullable<z.ZodString>>;
    }>, "strip", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "BranchWithRelativeComparison";
        id: string;
        question: string;
        next: string | null;
        branchStartId: Record<string, string | null>;
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "BranchWithRelativeComparison";
        id: string;
        question: string;
        next: string | null;
        branchStartId: Record<string, string | null>;
    }>, z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"Wrapper">;
        innerNext: z.ZodString;
    }>, "strict", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Wrapper";
        id: string;
        question: string;
        next: string | null;
        innerNext: string;
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Wrapper";
        id: string;
        question: string;
        next: string | null;
        innerNext: string;
    }> | z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"Wrapper">;
        innerNext: z.ZodString;
    }>, "strip", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Wrapper";
        id: string;
        question: string;
        next: string | null;
        innerNext: string;
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Wrapper";
        id: string;
        question: string;
        next: string | null;
        innerNext: string;
    }>]>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        branchStartId?: {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        } | undefined;
        addFollowupStream?: {
            yes?: string | undefined;
        } | undefined;
        type: "YesNo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        placeholder?: string | undefined;
        keyboardType?: string | undefined;
        dropdownChoices?: {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        } | undefined;
        maxMinus?: string | undefined;
        repeatedItemStartId?: string | undefined;
        type: "MultipleText";
        id: string;
        question: string;
        next: string | null;
        indexName: string;
        variableName: string;
        max: number;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "HowLongAgo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Branch";
        id: string;
        question: string;
        next: string | null;
        branchStartId: {
            true?: string | null | undefined;
            false?: string | null | undefined;
        };
        condition: {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        };
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "BranchWithRelativeComparison";
        id: string;
        question: string;
        next: string | null;
        branchStartId: Record<string, string | null>;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Wrapper";
        id: string;
        question: string;
        next: string | null;
        innerNext: string;
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        branchStartId?: {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        } | undefined;
        addFollowupStream?: {
            yes?: string | undefined;
        } | undefined;
        type: "YesNo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        placeholder?: string | undefined;
        keyboardType?: string | undefined;
        dropdownChoices?: {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        } | undefined;
        maxMinus?: string | undefined;
        repeatedItemStartId?: string | undefined;
        type: "MultipleText";
        id: string;
        question: string;
        next: string | null;
        indexName: string;
        variableName: string;
        max: number;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "HowLongAgo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Branch";
        id: string;
        question: string;
        next: string | null;
        branchStartId: {
            true?: string | null | undefined;
            false?: string | null | undefined;
        };
        condition: {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        };
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "BranchWithRelativeComparison";
        id: string;
        question: string;
        next: string | null;
        branchStartId: Record<string, string | null>;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Wrapper";
        id: string;
        question: string;
        next: string | null;
        innerNext: string;
    }>>, Record<string, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        branchStartId?: {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        } | undefined;
        addFollowupStream?: {
            yes?: string | undefined;
        } | undefined;
        type: "YesNo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        placeholder?: string | undefined;
        keyboardType?: string | undefined;
        dropdownChoices?: {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        } | undefined;
        maxMinus?: string | undefined;
        repeatedItemStartId?: string | undefined;
        type: "MultipleText";
        id: string;
        question: string;
        next: string | null;
        indexName: string;
        variableName: string;
        max: number;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "HowLongAgo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Branch";
        id: string;
        question: string;
        next: string | null;
        branchStartId: {
            true?: string | null | undefined;
            false?: string | null | undefined;
        };
        condition: {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        };
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "BranchWithRelativeComparison";
        id: string;
        question: string;
        next: string | null;
        branchStartId: Record<string, string | null>;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Wrapper";
        id: string;
        question: string;
        next: string | null;
        innerNext: string;
    }>, Record<string, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        branchStartId?: {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        } | undefined;
        addFollowupStream?: {
            yes?: string | undefined;
        } | undefined;
        type: "YesNo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        placeholder?: string | undefined;
        keyboardType?: string | undefined;
        dropdownChoices?: {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        } | undefined;
        maxMinus?: string | undefined;
        repeatedItemStartId?: string | undefined;
        type: "MultipleText";
        id: string;
        question: string;
        next: string | null;
        indexName: string;
        variableName: string;
        max: number;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "HowLongAgo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Branch";
        id: string;
        question: string;
        next: string | null;
        branchStartId: {
            true?: string | null | undefined;
            false?: string | null | undefined;
        };
        condition: {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        };
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "BranchWithRelativeComparison";
        id: string;
        question: string;
        next: string | null;
        branchStartId: Record<string, string | null>;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Wrapper";
        id: string;
        question: string;
        next: string | null;
        innerNext: string;
    }>>, Record<string, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        branchStartId?: {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        } | undefined;
        addFollowupStream?: {
            yes?: string | undefined;
        } | undefined;
        type: "YesNo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        placeholder?: string | undefined;
        keyboardType?: string | undefined;
        dropdownChoices?: {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        } | undefined;
        maxMinus?: string | undefined;
        repeatedItemStartId?: string | undefined;
        type: "MultipleText";
        id: string;
        question: string;
        next: string | null;
        indexName: string;
        variableName: string;
        max: number;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "HowLongAgo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Branch";
        id: string;
        question: string;
        next: string | null;
        branchStartId: {
            true?: string | null | undefined;
            false?: string | null | undefined;
        };
        condition: {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        };
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "BranchWithRelativeComparison";
        id: string;
        question: string;
        next: string | null;
        branchStartId: Record<string, string | null>;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Wrapper";
        id: string;
        question: string;
        next: string | null;
        innerNext: string;
    }>, Record<string, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        branchStartId?: {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        } | undefined;
        addFollowupStream?: {
            yes?: string | undefined;
        } | undefined;
        type: "YesNo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        placeholder?: string | undefined;
        keyboardType?: string | undefined;
        dropdownChoices?: {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        } | undefined;
        maxMinus?: string | undefined;
        repeatedItemStartId?: string | undefined;
        type: "MultipleText";
        id: string;
        question: string;
        next: string | null;
        indexName: string;
        variableName: string;
        max: number;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "HowLongAgo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Branch";
        id: string;
        question: string;
        next: string | null;
        branchStartId: {
            true?: string | null | undefined;
            false?: string | null | undefined;
        };
        condition: {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        };
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "BranchWithRelativeComparison";
        id: string;
        question: string;
        next: string | null;
        branchStartId: Record<string, string | null>;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Wrapper";
        id: string;
        question: string;
        next: string | null;
        innerNext: string;
    }>>>;
    extraData: z.ZodObject<{
        reusableChoices: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodEffects<z.ZodArray<z.ZodString, "atleastone">, [string, ...string[]], [string, ...string[]]>>>;
    }, "strip", z.ZodTypeAny, {
        reusableChoices?: Record<string, [string, ...string[]]> | undefined;
    }, {
        reusableChoices?: Record<string, [string, ...string[]]> | undefined;
    }> | z.ZodObject<{
        reusableChoices: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodEffects<z.ZodArray<z.ZodString, "atleastone">, [string, ...string[]], [string, ...string[]]>>>;
    }, "strict", z.ZodTypeAny, {
        reusableChoices?: Record<string, [string, ...string[]]> | undefined;
    }, {
        reusableChoices?: Record<string, [string, ...string[]]> | undefined;
    }>;
}, "strip", z.ZodTypeAny, {
    studyInfo: {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            message: string;
            title: string;
            buttonText: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: Date;
        endDate: Date;
        pingsFrequency: {
            latestPingNotificationTime?: number | undefined;
            earliestPingNotificationTime: number;
            expireAfterTime: number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    } | {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            message: string;
            title: string;
            buttonText: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: Date;
        endDate: Date;
        pingsFrequency: {
            latestPingNotificationTime?: number | undefined;
            earliestPingNotificationTime: number;
            expireAfterTime: number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    };
    streams: Record<string, Record<string, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        branchStartId?: {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        } | undefined;
        addFollowupStream?: {
            yes?: string | undefined;
        } | undefined;
        type: "YesNo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        placeholder?: string | undefined;
        keyboardType?: string | undefined;
        dropdownChoices?: {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        } | undefined;
        maxMinus?: string | undefined;
        repeatedItemStartId?: string | undefined;
        type: "MultipleText";
        id: string;
        question: string;
        next: string | null;
        indexName: string;
        variableName: string;
        max: number;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "HowLongAgo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Branch";
        id: string;
        question: string;
        next: string | null;
        branchStartId: {
            true?: string | null | undefined;
            false?: string | null | undefined;
        };
        condition: {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        };
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "BranchWithRelativeComparison";
        id: string;
        question: string;
        next: string | null;
        branchStartId: Record<string, string | null>;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Wrapper";
        id: string;
        question: string;
        next: string | null;
        innerNext: string;
    }>>;
    extraData: {
        reusableChoices?: Record<string, [string, ...string[]]> | undefined;
    } | {
        reusableChoices?: Record<string, [string, ...string[]]> | undefined;
    };
}, {
    studyInfo: {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            title?: string | undefined;
            buttonText?: string | undefined;
            message: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: string | Date;
        endDate: string | Date;
        pingsFrequency: {
            latestPingNotificationTime?: string | number | undefined;
            earliestPingNotificationTime: string | number;
            expireAfterTime: string | number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: string[] | {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        } | {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    } | {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            title?: string | undefined;
            buttonText?: string | undefined;
            message: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: string | Date;
        endDate: string | Date;
        pingsFrequency: {
            latestPingNotificationTime?: string | number | undefined;
            earliestPingNotificationTime: string | number;
            expireAfterTime: string | number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: string[] | {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        } | {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    };
    streams: Record<string, Record<string, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        branchStartId?: {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        } | undefined;
        addFollowupStream?: {
            yes?: string | undefined;
        } | undefined;
        type: "YesNo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        placeholder?: string | undefined;
        keyboardType?: string | undefined;
        dropdownChoices?: {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        } | undefined;
        maxMinus?: string | undefined;
        repeatedItemStartId?: string | undefined;
        type: "MultipleText";
        id: string;
        question: string;
        next: string | null;
        indexName: string;
        variableName: string;
        max: number;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "HowLongAgo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Branch";
        id: string;
        question: string;
        next: string | null;
        branchStartId: {
            true?: string | null | undefined;
            false?: string | null | undefined;
        };
        condition: {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        };
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "BranchWithRelativeComparison";
        id: string;
        question: string;
        next: string | null;
        branchStartId: Record<string, string | null>;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Wrapper";
        id: string;
        question: string;
        next: string | null;
        innerNext: string;
    }>>;
    extraData: {
        reusableChoices?: Record<string, [string, ...string[]]> | undefined;
    } | {
        reusableChoices?: Record<string, [string, ...string[]]> | undefined;
    };
}> | z.ZodObject<{
    studyInfo: z.ZodEffects<z.ZodEffects<z.ZodObject<{
        /**
         * The ID of the study.
         *
         * It can only include letters, numbers, and "_".
         */
        id: z.ZodString;
        /**
         * The version of the study.
         *
         * https://github.com/wellping/wellping/issues/94
         */
        version: z.ZodOptional<z.ZodString>;
        /**
         * The URL that host this study file (which could be a JSON or a YAML file).
         *
         * The app fetches this URL in the background at every start and loads the
         * downloaded new file at the next start.
         */
        studyFileURL: z.ZodString;
        /**
         * The URL of the dashboard that will be shown to the user on the home page.
         *
         * ---
         *
         * The placeholder `__USERNAME__` will be replaced by the user's username.
         * Notice that you should not return any sensitive data based on this field
         * as it can be changed by anyone.
         * In order to verify the user securely:
         * - If you are using Firebase, you should use the `__FIREBASE_ID_TOKEN__`
         *   placeholder as explained below.
         * - If you are using Beiwe, (A TODO: ITEM).
         *
         * If Firebase is used, the placeholder `__FIREBASE_ID_TOKEN__` will be
         * replaced by the user's Firebase Auth ID token if the user is signed in
         * to Firebase, and "N/A" otherwise.
         *
         * ---
         *
         * The following Placeholders are also provided for your convenience so that
         * you don't have to set up a full back-end server (with Firebase Admin SDK)
         * just to display the user's progress:
         *
         * The placeholder `__PINGS_COMPLETED_OVERALL__` will be replaced by the
         * number of pings the user has completed overall.
         *
         * The placeholder `__PINGS_COMPLETED_THIS_WEEK__` will be replaced by the
         * number of pings the user has completed this week (defined by
         * `weekStartsOn`).
         *
         * The placeholder `__PINGS_COMPLETED_TODAY__` will be replaced by the
         * number of pings the user has completed today.
         */
        dashboardURL: z.ZodOptional<z.ZodString>;
        /**
         * The backend server info for the study. Well Ping supports uploading to
         * Firebase or uploading to Beiwe.
         *
         * If Firebase backend is used, `server.firebase` should be defined.
         *
         * If Beiwe backend is used, `server.beiwe` should be defined.
         *
         * If this object is empty (i.e., `server: {}`), you will be able to log in
         * using any username password combination, and no data will be uploaded.
         * This is only intended for testing or demo purposes and should not be used
         * in production. (MARK: NO_SERVER_NOTE)
         *
         * Notice that in theory, both `server.firebase` and `server.beiwe` could be
         * set (meaning that the data will be uploaded to both Beiwe and Firebase).
         * However, such pratice is not thoroughly tested and is not guaranteed to
         * work correctly.
         */
        server: z.ZodObject<{
            firebase: z.ZodOptional<z.ZodObject<{
                /**
                 * The Firebase config object for the study.
                 *
                 * See https://firebase.google.com/docs/web/setup#config-object
                 */
                config: z.ZodRecord<z.ZodString, z.ZodString>;
            }, "strip", z.ZodTypeAny, {
                config: Record<string, string>;
            }, {
                config: Record<string, string>;
            }>>;
            beiwe: z.ZodOptional<z.ZodObject<{
                /**
                 * The server URL of Beiwe backend for the study.
                 *
                 * Example: `"https://beiwe.example.com/"`
                 */
                serverUrl: z.ZodString;
            }, "strip", z.ZodTypeAny, {
                serverUrl: string;
            }, {
                serverUrl: string;
            }>>;
        }, "strip", z.ZodTypeAny, {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        }, {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        }>;
        /**
         * The URL of the study consent form (or any web page you would want the
         * user to see before they begin).
         *
         * This web page will be displayed after the user successfully logs in.
         */
        consentFormUrl: z.ZodString;
        /**
         * The email address that the user could contact for questions regarding the
         * study or the app.
         *
         * If this field is set, a "Contact Staff" button will appear at the top of
         * the screen.
         */
        contactEmail: z.ZodOptional<z.ZodString>;
        /**
         * The first day of the week.
         *
         * 0 is Sunday.
         */
        weekStartsOn: z.ZodUnion<[z.ZodLiteral<0>, z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>, z.ZodLiteral<5>, z.ZodLiteral<6>]>;
        /**
         * The start date (time) of the study.
         *
         * The first ping will be sent after this time.
         *
         * Timezone in this date string is ignored.
         */
        startDate: z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, Date, string>, z.ZodDate]>;
        /**
         * The end date (time) of the study.
         *
         * The last ping will be sent before this time.
         *
         * Timezone in this date string is ignored.
         */
        endDate: z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, Date, string>, z.ZodDate]>;
        /**
         * The time every day that ping notifications will be sent.
         *
         * Notice that the duration between every
         * `pingsFrequency[i].latestPingNotificationTime` and
         * `pingsFrequency[i+1].earliestPingNotificationTime`
         * should be greater than
         * `pingsFrequency[i].expireAfterTime`
         * so that the user will always have enough time to complete the ping no matter
         * what time they receive the ping.
         */
        pingsFrequency: z.ZodArray<z.ZodEffects<z.ZodObject<{
            /**
             * The earliest time that the ping will be sent (inclusive).
             */
            earliestPingNotificationTime: z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, number, string>, z.ZodNumber]>;
            /**
             * The latest time that the ping will be sent (inclusive).
             * If this is not specified, the ping will be sent exactly at
             * `earliestPingNotificationTime`.
             * If this is specified, the ping will be sent at a random time between
             * `earliestPingNotificationTime` and `latestPingNotificationTime`.
             */
            latestPingNotificationTime: z.ZodOptional<z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, number, string>, z.ZodNumber]>>;
            /**
             * A ping will expire after this amount of time (after the notification
             * time).
             *
             * For example, if the user receives a ping notification on 10:00:00AM,
             * and `expireAfterTime` is set to `00:45:00`, the user will no longer
             * be able to complete this ping after 10:45:00AM.
             */
            expireAfterTime: z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, number, string>, z.ZodNumber]>;
        }, "strip", z.ZodTypeAny, {
            latestPingNotificationTime?: number | undefined;
            earliestPingNotificationTime: number;
            expireAfterTime: number;
        }, {
            latestPingNotificationTime?: string | number | undefined;
            earliestPingNotificationTime: string | number;
            expireAfterTime: string | number;
        }>, {
            latestPingNotificationTime?: number | undefined;
            earliestPingNotificationTime: number;
            expireAfterTime: number;
        }, {
            latestPingNotificationTime?: string | number | undefined;
            earliestPingNotificationTime: string | number;
            expireAfterTime: string | number;
        }>, "many">;
        /**
         * The question ID of the first question of each stream.
         */
        streamsStartingQuestionIds: z.ZodRecord<z.ZodString, z.ZodString>;
        /**
         * The streams that the user will fill (in this order) every day.
         *
         * For example, if `streamsOrder.sunday` is `["dog", "cat", "wolf", "lynx"]`,
         * then on Sunday, if the user opens all four pings they received, they
         * will fill the "dog", "cat", "wolf", and "lynx" stream (in this order).
         * If the user only opens two pings, they will fill the "dog" and "cat"
         * stream (in this order).
         *
         * The number of elements each day should be equal to the number of elements
         * in `pingsFrequency` above.
         */
        streamsOrder: z.ZodUnion<[z.ZodObject<{
            0: z.ZodArray<z.ZodString, "many">;
            1: z.ZodArray<z.ZodString, "many">;
            2: z.ZodArray<z.ZodString, "many">;
            3: z.ZodArray<z.ZodString, "many">;
            4: z.ZodArray<z.ZodString, "many">;
            5: z.ZodArray<z.ZodString, "many">;
            6: z.ZodArray<z.ZodString, "many">;
        }, "strip", z.ZodTypeAny, {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        }, {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        }>, z.ZodEffects<z.ZodObject<{
            sunday: z.ZodArray<z.ZodString, "many">;
            monday: z.ZodArray<z.ZodString, "many">;
            tuesday: z.ZodArray<z.ZodString, "many">;
            wednesday: z.ZodArray<z.ZodString, "many">;
            thursday: z.ZodArray<z.ZodString, "many">;
            friday: z.ZodArray<z.ZodString, "many">;
            saturday: z.ZodArray<z.ZodString, "many">;
        }, "strip", z.ZodTypeAny, {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        }, {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        }>, {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        }, {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        }>, z.ZodEffects<z.ZodArray<z.ZodString, "many">, {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        }, string[]>]>;
        /**
         * The stream type(s) for n-th ping(s). The key is the "n" in "n-th ping".
         * This will **replace** the originally sceduled stream type for that ping.
         *
         * For example,
         * ```{json}
         * "streamsForNthPings": {
         *   "1": "demographic",
         *   "10": "interests"
         * }
         * ```
         * means that the user's first ping will be `"demographic"` stream and the
         * user's 10th ping will be `"interests"` stream.
         */
        streamsForNthPings: z.ZodEffects<z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>, Record<string, string> | undefined, Record<string, string> | undefined>;
        /**
         * The stream that the user will see if there is any error in `streamsOrder`.
         */
        streamInCaseOfError: z.ZodString;
        /**
         * The streams that will not be replaced by followup streams
         * (when a YesNo question's `addFollowupStream` is set).
         */
        streamsNotReplacedByFollowupStream: z.ZodArray<z.ZodString, "many">;
        notificationContent: z.ZodObject<{
            /**
             * The default notification title and body.
             */
            default: z.ZodObject<{
                title: z.ZodString;
                body: z.ZodString;
            }, "strip", z.ZodTypeAny, {
                title: string;
                body: string;
            }, {
                title: string;
                body: string;
            }>;
            /**
             * If set, the `bonus` content for the notification will be used until
             * the number of survey completed that week is greater than
             * `bonus.numberOfCompletionEachWeek - 1`.
             *
             * "#n_ping#" in `title` and `body` will be replaced by "5 pings" or
             * "1 ping".
             *
             * Example:
             * ```
             * bonus: {
             *    title: "You can earn bonus!",
             *    body: "You are #n_ping# away from the weekly bonus.",
             *    numberOfCompletionEachWeek: 5,
             * },
             * ```
             */
            bonus: z.ZodOptional<z.ZodObject<{
                title: z.ZodString;
                body: z.ZodString;
                numberOfCompletionEachWeek: z.ZodNumber;
            }, "strip", z.ZodTypeAny, {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            }, {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            }>>;
        }, "strip", z.ZodTypeAny, {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        }, {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        }>;
        /**
         * If `true`, the "Next" button will always be enabled.
         * If `false` or undefined, the "Next" button will only be enabled after the
         * user has interacted with the question.
         */
        alwaysEnableNextButton: z.ZodOptional<z.ZodBoolean>;
        /**
         * Special treatments for variable placeholders. The key of each record is
         * the variable name as defined by supported question's `variableName`, or a
         * question ID (if you want to replace the placeholder with a previous
         * question's answer).
         */
        specialVariablePlaceholderTreatments: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
            decapitalizeFirstCharacter: z.ZodOptional<z.ZodObject<{
                /**
                 * The first character of the answer data replacing the placeholder will be
                 * decapitalized.
                 *
                 * For example, if the answer is `"Friends"` and the variable is `"CONTACT"`,
                 * and `decapitalizeFirstCharacter.enabled` is `true`,
                 * and `decapitalizeFirstCharacter.excludes` does not include `"Friends"`
                 * (or if `decapitalizeFirstCharacter.includes` includes `"Friends"`),
                 * then `"Why [__CONTACT__]?"` will be replaced by `"Why friends?"`.
                 */
                enabled: z.ZodBoolean;
                options: z.ZodOptional<z.ZodUnion<[z.ZodObject<{
                    /**
                     * If set, answer data included in it will not be decapitalize.
                     */
                    excludes: z.ZodArray<z.ZodString, "many">;
                    includes: z.ZodOptional<z.ZodNever>;
                }, "strip", z.ZodTypeAny, {
                    includes?: undefined;
                    excludes: string[];
                }, {
                    includes?: undefined;
                    excludes: string[];
                }>, z.ZodObject<{
                    /**
                     * If set, only answer data included in it will be decapitalize.
                     */
                    includes: z.ZodArray<z.ZodString, "many">;
                    excludes: z.ZodOptional<z.ZodNever>;
                }, "strip", z.ZodTypeAny, {
                    excludes?: undefined;
                    includes: string[];
                }, {
                    excludes?: undefined;
                    includes: string[];
                }>]>>;
            }, "strip", z.ZodTypeAny, {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            }, {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            }>>;
        }, "strip", z.ZodTypeAny, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }>>>;
        /**
         * Show an alert each time the app launches.
         */
        specialAlertOnLaunch: z.ZodOptional<z.ZodObject<{
            title: z.ZodDefault<z.ZodString>;
            message: z.ZodString;
            buttonText: z.ZodDefault<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            message: string;
            title: string;
            buttonText: string;
        }, {
            title?: string | undefined;
            buttonText?: string | undefined;
            message: string;
        }>>;
    }, "strict", z.ZodTypeAny, {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            message: string;
            title: string;
            buttonText: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: Date;
        endDate: Date;
        pingsFrequency: {
            latestPingNotificationTime?: number | undefined;
            earliestPingNotificationTime: number;
            expireAfterTime: number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    }, {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            title?: string | undefined;
            buttonText?: string | undefined;
            message: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: string | Date;
        endDate: string | Date;
        pingsFrequency: {
            latestPingNotificationTime?: string | number | undefined;
            earliestPingNotificationTime: string | number;
            expireAfterTime: string | number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: string[] | {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        } | {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    }>, {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            message: string;
            title: string;
            buttonText: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: Date;
        endDate: Date;
        pingsFrequency: {
            latestPingNotificationTime?: number | undefined;
            earliestPingNotificationTime: number;
            expireAfterTime: number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    }, {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            title?: string | undefined;
            buttonText?: string | undefined;
            message: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: string | Date;
        endDate: string | Date;
        pingsFrequency: {
            latestPingNotificationTime?: string | number | undefined;
            earliestPingNotificationTime: string | number;
            expireAfterTime: string | number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: string[] | {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        } | {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    }>, {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            message: string;
            title: string;
            buttonText: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: Date;
        endDate: Date;
        pingsFrequency: {
            latestPingNotificationTime?: number | undefined;
            earliestPingNotificationTime: number;
            expireAfterTime: number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    }, {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            title?: string | undefined;
            buttonText?: string | undefined;
            message: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: string | Date;
        endDate: string | Date;
        pingsFrequency: {
            latestPingNotificationTime?: string | number | undefined;
            earliestPingNotificationTime: string | number;
            expireAfterTime: string | number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: string[] | {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        } | {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    }> | z.ZodEffects<z.ZodEffects<z.ZodObject<{
        /**
         * The ID of the study.
         *
         * It can only include letters, numbers, and "_".
         */
        id: z.ZodString;
        /**
         * The version of the study.
         *
         * https://github.com/wellping/wellping/issues/94
         */
        version: z.ZodOptional<z.ZodString>;
        /**
         * The URL that host this study file (which could be a JSON or a YAML file).
         *
         * The app fetches this URL in the background at every start and loads the
         * downloaded new file at the next start.
         */
        studyFileURL: z.ZodString;
        /**
         * The URL of the dashboard that will be shown to the user on the home page.
         *
         * ---
         *
         * The placeholder `__USERNAME__` will be replaced by the user's username.
         * Notice that you should not return any sensitive data based on this field
         * as it can be changed by anyone.
         * In order to verify the user securely:
         * - If you are using Firebase, you should use the `__FIREBASE_ID_TOKEN__`
         *   placeholder as explained below.
         * - If you are using Beiwe, (A TODO: ITEM).
         *
         * If Firebase is used, the placeholder `__FIREBASE_ID_TOKEN__` will be
         * replaced by the user's Firebase Auth ID token if the user is signed in
         * to Firebase, and "N/A" otherwise.
         *
         * ---
         *
         * The following Placeholders are also provided for your convenience so that
         * you don't have to set up a full back-end server (with Firebase Admin SDK)
         * just to display the user's progress:
         *
         * The placeholder `__PINGS_COMPLETED_OVERALL__` will be replaced by the
         * number of pings the user has completed overall.
         *
         * The placeholder `__PINGS_COMPLETED_THIS_WEEK__` will be replaced by the
         * number of pings the user has completed this week (defined by
         * `weekStartsOn`).
         *
         * The placeholder `__PINGS_COMPLETED_TODAY__` will be replaced by the
         * number of pings the user has completed today.
         */
        dashboardURL: z.ZodOptional<z.ZodString>;
        /**
         * The backend server info for the study. Well Ping supports uploading to
         * Firebase or uploading to Beiwe.
         *
         * If Firebase backend is used, `server.firebase` should be defined.
         *
         * If Beiwe backend is used, `server.beiwe` should be defined.
         *
         * If this object is empty (i.e., `server: {}`), you will be able to log in
         * using any username password combination, and no data will be uploaded.
         * This is only intended for testing or demo purposes and should not be used
         * in production. (MARK: NO_SERVER_NOTE)
         *
         * Notice that in theory, both `server.firebase` and `server.beiwe` could be
         * set (meaning that the data will be uploaded to both Beiwe and Firebase).
         * However, such pratice is not thoroughly tested and is not guaranteed to
         * work correctly.
         */
        server: z.ZodObject<{
            firebase: z.ZodOptional<z.ZodObject<{
                /**
                 * The Firebase config object for the study.
                 *
                 * See https://firebase.google.com/docs/web/setup#config-object
                 */
                config: z.ZodRecord<z.ZodString, z.ZodString>;
            }, "strip", z.ZodTypeAny, {
                config: Record<string, string>;
            }, {
                config: Record<string, string>;
            }>>;
            beiwe: z.ZodOptional<z.ZodObject<{
                /**
                 * The server URL of Beiwe backend for the study.
                 *
                 * Example: `"https://beiwe.example.com/"`
                 */
                serverUrl: z.ZodString;
            }, "strip", z.ZodTypeAny, {
                serverUrl: string;
            }, {
                serverUrl: string;
            }>>;
        }, "strip", z.ZodTypeAny, {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        }, {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        }>;
        /**
         * The URL of the study consent form (or any web page you would want the
         * user to see before they begin).
         *
         * This web page will be displayed after the user successfully logs in.
         */
        consentFormUrl: z.ZodString;
        /**
         * The email address that the user could contact for questions regarding the
         * study or the app.
         *
         * If this field is set, a "Contact Staff" button will appear at the top of
         * the screen.
         */
        contactEmail: z.ZodOptional<z.ZodString>;
        /**
         * The first day of the week.
         *
         * 0 is Sunday.
         */
        weekStartsOn: z.ZodUnion<[z.ZodLiteral<0>, z.ZodLiteral<1>, z.ZodLiteral<2>, z.ZodLiteral<3>, z.ZodLiteral<4>, z.ZodLiteral<5>, z.ZodLiteral<6>]>;
        /**
         * The start date (time) of the study.
         *
         * The first ping will be sent after this time.
         *
         * Timezone in this date string is ignored.
         */
        startDate: z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, Date, string>, z.ZodDate]>;
        /**
         * The end date (time) of the study.
         *
         * The last ping will be sent before this time.
         *
         * Timezone in this date string is ignored.
         */
        endDate: z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, Date, string>, z.ZodDate]>;
        /**
         * The time every day that ping notifications will be sent.
         *
         * Notice that the duration between every
         * `pingsFrequency[i].latestPingNotificationTime` and
         * `pingsFrequency[i+1].earliestPingNotificationTime`
         * should be greater than
         * `pingsFrequency[i].expireAfterTime`
         * so that the user will always have enough time to complete the ping no matter
         * what time they receive the ping.
         */
        pingsFrequency: z.ZodArray<z.ZodEffects<z.ZodObject<{
            /**
             * The earliest time that the ping will be sent (inclusive).
             */
            earliestPingNotificationTime: z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, number, string>, z.ZodNumber]>;
            /**
             * The latest time that the ping will be sent (inclusive).
             * If this is not specified, the ping will be sent exactly at
             * `earliestPingNotificationTime`.
             * If this is specified, the ping will be sent at a random time between
             * `earliestPingNotificationTime` and `latestPingNotificationTime`.
             */
            latestPingNotificationTime: z.ZodOptional<z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, number, string>, z.ZodNumber]>>;
            /**
             * A ping will expire after this amount of time (after the notification
             * time).
             *
             * For example, if the user receives a ping notification on 10:00:00AM,
             * and `expireAfterTime` is set to `00:45:00`, the user will no longer
             * be able to complete this ping after 10:45:00AM.
             */
            expireAfterTime: z.ZodUnion<[z.ZodEffects<z.ZodEffects<z.ZodString, string, string>, number, string>, z.ZodNumber]>;
        }, "strip", z.ZodTypeAny, {
            latestPingNotificationTime?: number | undefined;
            earliestPingNotificationTime: number;
            expireAfterTime: number;
        }, {
            latestPingNotificationTime?: string | number | undefined;
            earliestPingNotificationTime: string | number;
            expireAfterTime: string | number;
        }>, {
            latestPingNotificationTime?: number | undefined;
            earliestPingNotificationTime: number;
            expireAfterTime: number;
        }, {
            latestPingNotificationTime?: string | number | undefined;
            earliestPingNotificationTime: string | number;
            expireAfterTime: string | number;
        }>, "many">;
        /**
         * The question ID of the first question of each stream.
         */
        streamsStartingQuestionIds: z.ZodRecord<z.ZodString, z.ZodString>;
        /**
         * The streams that the user will fill (in this order) every day.
         *
         * For example, if `streamsOrder.sunday` is `["dog", "cat", "wolf", "lynx"]`,
         * then on Sunday, if the user opens all four pings they received, they
         * will fill the "dog", "cat", "wolf", and "lynx" stream (in this order).
         * If the user only opens two pings, they will fill the "dog" and "cat"
         * stream (in this order).
         *
         * The number of elements each day should be equal to the number of elements
         * in `pingsFrequency` above.
         */
        streamsOrder: z.ZodUnion<[z.ZodObject<{
            0: z.ZodArray<z.ZodString, "many">;
            1: z.ZodArray<z.ZodString, "many">;
            2: z.ZodArray<z.ZodString, "many">;
            3: z.ZodArray<z.ZodString, "many">;
            4: z.ZodArray<z.ZodString, "many">;
            5: z.ZodArray<z.ZodString, "many">;
            6: z.ZodArray<z.ZodString, "many">;
        }, "strip", z.ZodTypeAny, {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        }, {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        }>, z.ZodEffects<z.ZodObject<{
            sunday: z.ZodArray<z.ZodString, "many">;
            monday: z.ZodArray<z.ZodString, "many">;
            tuesday: z.ZodArray<z.ZodString, "many">;
            wednesday: z.ZodArray<z.ZodString, "many">;
            thursday: z.ZodArray<z.ZodString, "many">;
            friday: z.ZodArray<z.ZodString, "many">;
            saturday: z.ZodArray<z.ZodString, "many">;
        }, "strip", z.ZodTypeAny, {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        }, {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        }>, {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        }, {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        }>, z.ZodEffects<z.ZodArray<z.ZodString, "many">, {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        }, string[]>]>;
        /**
         * The stream type(s) for n-th ping(s). The key is the "n" in "n-th ping".
         * This will **replace** the originally sceduled stream type for that ping.
         *
         * For example,
         * ```{json}
         * "streamsForNthPings": {
         *   "1": "demographic",
         *   "10": "interests"
         * }
         * ```
         * means that the user's first ping will be `"demographic"` stream and the
         * user's 10th ping will be `"interests"` stream.
         */
        streamsForNthPings: z.ZodEffects<z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>, Record<string, string> | undefined, Record<string, string> | undefined>;
        /**
         * The stream that the user will see if there is any error in `streamsOrder`.
         */
        streamInCaseOfError: z.ZodString;
        /**
         * The streams that will not be replaced by followup streams
         * (when a YesNo question's `addFollowupStream` is set).
         */
        streamsNotReplacedByFollowupStream: z.ZodArray<z.ZodString, "many">;
        notificationContent: z.ZodObject<{
            /**
             * The default notification title and body.
             */
            default: z.ZodObject<{
                title: z.ZodString;
                body: z.ZodString;
            }, "strip", z.ZodTypeAny, {
                title: string;
                body: string;
            }, {
                title: string;
                body: string;
            }>;
            /**
             * If set, the `bonus` content for the notification will be used until
             * the number of survey completed that week is greater than
             * `bonus.numberOfCompletionEachWeek - 1`.
             *
             * "#n_ping#" in `title` and `body` will be replaced by "5 pings" or
             * "1 ping".
             *
             * Example:
             * ```
             * bonus: {
             *    title: "You can earn bonus!",
             *    body: "You are #n_ping# away from the weekly bonus.",
             *    numberOfCompletionEachWeek: 5,
             * },
             * ```
             */
            bonus: z.ZodOptional<z.ZodObject<{
                title: z.ZodString;
                body: z.ZodString;
                numberOfCompletionEachWeek: z.ZodNumber;
            }, "strip", z.ZodTypeAny, {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            }, {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            }>>;
        }, "strip", z.ZodTypeAny, {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        }, {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        }>;
        /**
         * If `true`, the "Next" button will always be enabled.
         * If `false` or undefined, the "Next" button will only be enabled after the
         * user has interacted with the question.
         */
        alwaysEnableNextButton: z.ZodOptional<z.ZodBoolean>;
        /**
         * Special treatments for variable placeholders. The key of each record is
         * the variable name as defined by supported question's `variableName`, or a
         * question ID (if you want to replace the placeholder with a previous
         * question's answer).
         */
        specialVariablePlaceholderTreatments: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodObject<{
            decapitalizeFirstCharacter: z.ZodOptional<z.ZodObject<{
                /**
                 * The first character of the answer data replacing the placeholder will be
                 * decapitalized.
                 *
                 * For example, if the answer is `"Friends"` and the variable is `"CONTACT"`,
                 * and `decapitalizeFirstCharacter.enabled` is `true`,
                 * and `decapitalizeFirstCharacter.excludes` does not include `"Friends"`
                 * (or if `decapitalizeFirstCharacter.includes` includes `"Friends"`),
                 * then `"Why [__CONTACT__]?"` will be replaced by `"Why friends?"`.
                 */
                enabled: z.ZodBoolean;
                options: z.ZodOptional<z.ZodUnion<[z.ZodObject<{
                    /**
                     * If set, answer data included in it will not be decapitalize.
                     */
                    excludes: z.ZodArray<z.ZodString, "many">;
                    includes: z.ZodOptional<z.ZodNever>;
                }, "strip", z.ZodTypeAny, {
                    includes?: undefined;
                    excludes: string[];
                }, {
                    includes?: undefined;
                    excludes: string[];
                }>, z.ZodObject<{
                    /**
                     * If set, only answer data included in it will be decapitalize.
                     */
                    includes: z.ZodArray<z.ZodString, "many">;
                    excludes: z.ZodOptional<z.ZodNever>;
                }, "strip", z.ZodTypeAny, {
                    excludes?: undefined;
                    includes: string[];
                }, {
                    excludes?: undefined;
                    includes: string[];
                }>]>>;
            }, "strip", z.ZodTypeAny, {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            }, {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            }>>;
        }, "strip", z.ZodTypeAny, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }>>>;
        /**
         * Show an alert each time the app launches.
         */
        specialAlertOnLaunch: z.ZodOptional<z.ZodObject<{
            title: z.ZodDefault<z.ZodString>;
            message: z.ZodString;
            buttonText: z.ZodDefault<z.ZodString>;
        }, "strip", z.ZodTypeAny, {
            message: string;
            title: string;
            buttonText: string;
        }, {
            title?: string | undefined;
            buttonText?: string | undefined;
            message: string;
        }>>;
    }, "strip", z.ZodTypeAny, {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            message: string;
            title: string;
            buttonText: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: Date;
        endDate: Date;
        pingsFrequency: {
            latestPingNotificationTime?: number | undefined;
            earliestPingNotificationTime: number;
            expireAfterTime: number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    }, {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            title?: string | undefined;
            buttonText?: string | undefined;
            message: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: string | Date;
        endDate: string | Date;
        pingsFrequency: {
            latestPingNotificationTime?: string | number | undefined;
            earliestPingNotificationTime: string | number;
            expireAfterTime: string | number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: string[] | {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        } | {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    }>, {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            message: string;
            title: string;
            buttonText: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: Date;
        endDate: Date;
        pingsFrequency: {
            latestPingNotificationTime?: number | undefined;
            earliestPingNotificationTime: number;
            expireAfterTime: number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    }, {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            title?: string | undefined;
            buttonText?: string | undefined;
            message: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: string | Date;
        endDate: string | Date;
        pingsFrequency: {
            latestPingNotificationTime?: string | number | undefined;
            earliestPingNotificationTime: string | number;
            expireAfterTime: string | number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: string[] | {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        } | {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    }>, {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            message: string;
            title: string;
            buttonText: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: Date;
        endDate: Date;
        pingsFrequency: {
            latestPingNotificationTime?: number | undefined;
            earliestPingNotificationTime: number;
            expireAfterTime: number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    }, {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            title?: string | undefined;
            buttonText?: string | undefined;
            message: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: string | Date;
        endDate: string | Date;
        pingsFrequency: {
            latestPingNotificationTime?: string | number | undefined;
            earliestPingNotificationTime: string | number;
            expireAfterTime: string | number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: string[] | {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        } | {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    }>;
    streams: z.ZodRecord<z.ZodString, z.ZodEffects<z.ZodEffects<z.ZodRecord<z.ZodString, z.ZodEffects<z.ZodUnion<[z.ZodEffects<z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"Slider">;
        slider: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        minimumValue: z.ZodOptional<z.ZodNumber>;
        maximumValue: z.ZodOptional<z.ZodNumber>;
        step: z.ZodOptional<z.ZodNumber>;
        defaultValue: z.ZodOptional<z.ZodNumber>;
        defaultValueFromQuestionId: z.ZodOptional<z.ZodString>;
        displayCurrentValueToUser: z.ZodOptional<z.ZodBoolean>;
    }>, "strict", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    }> | z.ZodEffects<z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"Slider">;
        slider: z.ZodTuple<[z.ZodString, z.ZodString], null>;
        minimumValue: z.ZodOptional<z.ZodNumber>;
        maximumValue: z.ZodOptional<z.ZodNumber>;
        step: z.ZodOptional<z.ZodNumber>;
        defaultValue: z.ZodOptional<z.ZodNumber>;
        defaultValueFromQuestionId: z.ZodOptional<z.ZodString>;
        displayCurrentValueToUser: z.ZodOptional<z.ZodBoolean>;
    }>, "strip", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    }>, z.ZodEffects<z.ZodEffects<z.ZodEffects<z.ZodEffects<z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodUnion<[z.ZodLiteral<"ChoicesWithSingleAnswer">, z.ZodLiteral<"ChoicesWithMultipleAnswers">]>;
        choices: z.ZodUnion<[z.ZodString, z.ZodEffects<z.ZodArray<z.ZodString, "atleastone">, [string, ...string[]], [string, ...string[]]>]>;
        specialCasesStartId: z.ZodOptional<z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodNullable<z.ZodString>], null>, "many">>;
        randomizeChoicesOrder: z.ZodOptional<z.ZodBoolean>;
        randomizeExceptForChoiceIds: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
    }>, "strip", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }> | z.ZodEffects<z.ZodEffects<z.ZodEffects<z.ZodEffects<z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodUnion<[z.ZodLiteral<"ChoicesWithSingleAnswer">, z.ZodLiteral<"ChoicesWithMultipleAnswers">]>;
        choices: z.ZodUnion<[z.ZodString, z.ZodEffects<z.ZodArray<z.ZodString, "atleastone">, [string, ...string[]], [string, ...string[]]>]>;
        specialCasesStartId: z.ZodOptional<z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodNullable<z.ZodString>], null>, "many">>;
        randomizeChoicesOrder: z.ZodOptional<z.ZodBoolean>;
        randomizeExceptForChoiceIds: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
    }>, "strict", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, z.ZodEffects<z.ZodEffects<z.ZodEffects<z.ZodEffects<z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodUnion<[z.ZodLiteral<"ChoicesWithSingleAnswer">, z.ZodLiteral<"ChoicesWithMultipleAnswers">]>;
        choices: z.ZodUnion<[z.ZodString, z.ZodEffects<z.ZodArray<z.ZodString, "atleastone">, [string, ...string[]], [string, ...string[]]>]>;
        specialCasesStartId: z.ZodOptional<z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodNullable<z.ZodString>], null>, "many">>;
        randomizeChoicesOrder: z.ZodOptional<z.ZodBoolean>;
        randomizeExceptForChoiceIds: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
    }>, "strip", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }> | z.ZodEffects<z.ZodEffects<z.ZodEffects<z.ZodEffects<z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodUnion<[z.ZodLiteral<"ChoicesWithSingleAnswer">, z.ZodLiteral<"ChoicesWithMultipleAnswers">]>;
        choices: z.ZodUnion<[z.ZodString, z.ZodEffects<z.ZodArray<z.ZodString, "atleastone">, [string, ...string[]], [string, ...string[]]>]>;
        specialCasesStartId: z.ZodOptional<z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodNullable<z.ZodString>], null>, "many">>;
        randomizeChoicesOrder: z.ZodOptional<z.ZodBoolean>;
        randomizeExceptForChoiceIds: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
    }>, "strict", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    }>, z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"YesNo">;
        branchStartId: z.ZodOptional<z.ZodObject<{
            yes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            no: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strict", z.ZodTypeAny, {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        }, {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        }>>;
        /**
         * The end date (time) of the study.
         *
         * The last ping will be sent before this time.
         *
         * Timezone in this date string is ignored.
         */
        addFollowupStream: z.ZodOptional<z.ZodObject<{
            yes: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            yes?: string | undefined;
        }, {
            yes?: string | undefined;
        }>>;
    }>, "strict", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        branchStartId?: {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        } | undefined;
        addFollowupStream?: {
            yes?: string | undefined;
        } | undefined;
        type: "YesNo";
        id: string;
        question: string;
        next: string | null;
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        branchStartId?: {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        } | undefined;
        addFollowupStream?: {
            yes?: string | undefined;
        } | undefined;
        type: "YesNo";
        id: string;
        question: string;
        next: string | null;
    }> | z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"YesNo">;
        branchStartId: z.ZodOptional<z.ZodObject<{
            yes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            no: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strict", z.ZodTypeAny, {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        }, {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        }>>;
        /**
         * The end date (time) of the study.
         *
         * The last ping will be sent before this time.
         *
         * Timezone in this date string is ignored.
         */
        addFollowupStream: z.ZodOptional<z.ZodObject<{
            yes: z.ZodOptional<z.ZodString>;
        }, "strict", z.ZodTypeAny, {
            yes?: string | undefined;
        }, {
            yes?: string | undefined;
        }>>;
    }>, "strip", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        branchStartId?: {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        } | undefined;
        addFollowupStream?: {
            yes?: string | undefined;
        } | undefined;
        type: "YesNo";
        id: string;
        question: string;
        next: string | null;
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        branchStartId?: {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        } | undefined;
        addFollowupStream?: {
            yes?: string | undefined;
        } | undefined;
        type: "YesNo";
        id: string;
        question: string;
        next: string | null;
    }>, z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"MultipleText">;
        indexName: z.ZodString;
        variableName: z.ZodString;
        placeholder: z.ZodOptional<z.ZodString>;
        keyboardType: z.ZodOptional<z.ZodString>;
        dropdownChoices: z.ZodOptional<z.ZodObject<{
            choices: z.ZodUnion<[z.ZodString, z.ZodEffects<z.ZodArray<z.ZodString, "atleastone">, [string, ...string[]], [string, ...string[]]>]>;
            forceChoice: z.ZodOptional<z.ZodBoolean>;
            alwaysShowChoices: z.ZodOptional<z.ZodBoolean>;
        }, "strip", z.ZodTypeAny, {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        }, {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        }>>;
        max: z.ZodNumber;
        maxMinus: z.ZodOptional<z.ZodString>;
        repeatedItemStartId: z.ZodOptional<z.ZodString>;
    }>, "strict", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        placeholder?: string | undefined;
        keyboardType?: string | undefined;
        dropdownChoices?: {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        } | undefined;
        maxMinus?: string | undefined;
        repeatedItemStartId?: string | undefined;
        type: "MultipleText";
        id: string;
        question: string;
        next: string | null;
        indexName: string;
        variableName: string;
        max: number;
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        placeholder?: string | undefined;
        keyboardType?: string | undefined;
        dropdownChoices?: {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        } | undefined;
        maxMinus?: string | undefined;
        repeatedItemStartId?: string | undefined;
        type: "MultipleText";
        id: string;
        question: string;
        next: string | null;
        indexName: string;
        variableName: string;
        max: number;
    }> | z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"MultipleText">;
        indexName: z.ZodString;
        variableName: z.ZodString;
        placeholder: z.ZodOptional<z.ZodString>;
        keyboardType: z.ZodOptional<z.ZodString>;
        dropdownChoices: z.ZodOptional<z.ZodObject<{
            choices: z.ZodUnion<[z.ZodString, z.ZodEffects<z.ZodArray<z.ZodString, "atleastone">, [string, ...string[]], [string, ...string[]]>]>;
            forceChoice: z.ZodOptional<z.ZodBoolean>;
            alwaysShowChoices: z.ZodOptional<z.ZodBoolean>;
        }, "strip", z.ZodTypeAny, {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        }, {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        }>>;
        max: z.ZodNumber;
        maxMinus: z.ZodOptional<z.ZodString>;
        repeatedItemStartId: z.ZodOptional<z.ZodString>;
    }>, "strip", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        placeholder?: string | undefined;
        keyboardType?: string | undefined;
        dropdownChoices?: {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        } | undefined;
        maxMinus?: string | undefined;
        repeatedItemStartId?: string | undefined;
        type: "MultipleText";
        id: string;
        question: string;
        next: string | null;
        indexName: string;
        variableName: string;
        max: number;
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        placeholder?: string | undefined;
        keyboardType?: string | undefined;
        dropdownChoices?: {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        } | undefined;
        maxMinus?: string | undefined;
        repeatedItemStartId?: string | undefined;
        type: "MultipleText";
        id: string;
        question: string;
        next: string | null;
        indexName: string;
        variableName: string;
        max: number;
    }>, z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"HowLongAgo">;
    }>, "strict", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "HowLongAgo";
        id: string;
        question: string;
        next: string | null;
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "HowLongAgo";
        id: string;
        question: string;
        next: string | null;
    }> | z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"HowLongAgo">;
    }>, "strip", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "HowLongAgo";
        id: string;
        question: string;
        next: string | null;
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "HowLongAgo";
        id: string;
        question: string;
        next: string | null;
    }>, z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"Branch">;
        condition: z.ZodObject<{
            questionId: z.ZodString;
            questionType: z.ZodUnion<[z.ZodLiteral<"MultipleText">, z.ZodLiteral<"ChoicesWithSingleAnswer">]>;
            compare: z.ZodLiteral<"equal">;
            target: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
        }, "strip", z.ZodTypeAny, {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        }, {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        }>;
        branchStartId: z.ZodObject<{
            true: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            false: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            true?: string | null | undefined;
            false?: string | null | undefined;
        }, {
            true?: string | null | undefined;
            false?: string | null | undefined;
        }>;
    }>, "strict", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Branch";
        id: string;
        question: string;
        next: string | null;
        branchStartId: {
            true?: string | null | undefined;
            false?: string | null | undefined;
        };
        condition: {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        };
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Branch";
        id: string;
        question: string;
        next: string | null;
        branchStartId: {
            true?: string | null | undefined;
            false?: string | null | undefined;
        };
        condition: {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        };
    }> | z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"Branch">;
        condition: z.ZodObject<{
            questionId: z.ZodString;
            questionType: z.ZodUnion<[z.ZodLiteral<"MultipleText">, z.ZodLiteral<"ChoicesWithSingleAnswer">]>;
            compare: z.ZodLiteral<"equal">;
            target: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
        }, "strip", z.ZodTypeAny, {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        }, {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        }>;
        branchStartId: z.ZodObject<{
            true: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            false: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            true?: string | null | undefined;
            false?: string | null | undefined;
        }, {
            true?: string | null | undefined;
            false?: string | null | undefined;
        }>;
    }>, "strip", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Branch";
        id: string;
        question: string;
        next: string | null;
        branchStartId: {
            true?: string | null | undefined;
            false?: string | null | undefined;
        };
        condition: {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        };
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Branch";
        id: string;
        question: string;
        next: string | null;
        branchStartId: {
            true?: string | null | undefined;
            false?: string | null | undefined;
        };
        condition: {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        };
    }>, z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"BranchWithRelativeComparison">;
        branchStartId: z.ZodRecord<z.ZodString, z.ZodNullable<z.ZodString>>;
    }>, "strict", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "BranchWithRelativeComparison";
        id: string;
        question: string;
        next: string | null;
        branchStartId: Record<string, string | null>;
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "BranchWithRelativeComparison";
        id: string;
        question: string;
        next: string | null;
        branchStartId: Record<string, string | null>;
    }> | z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"BranchWithRelativeComparison">;
        branchStartId: z.ZodRecord<z.ZodString, z.ZodNullable<z.ZodString>>;
    }>, "strip", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "BranchWithRelativeComparison";
        id: string;
        question: string;
        next: string | null;
        branchStartId: Record<string, string | null>;
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "BranchWithRelativeComparison";
        id: string;
        question: string;
        next: string | null;
        branchStartId: Record<string, string | null>;
    }>, z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"Wrapper">;
        innerNext: z.ZodString;
    }>, "strict", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Wrapper";
        id: string;
        question: string;
        next: string | null;
        innerNext: string;
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Wrapper";
        id: string;
        question: string;
        next: string | null;
        innerNext: string;
    }> | z.ZodObject<z.extendShape<{
        id: z.ZodString;
        type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
        question: z.ZodString;
        description: z.ZodOptional<z.ZodString>;
        image: z.ZodOptional<z.ZodObject<{
            url: z.ZodString;
            style: z.ZodObject<{
                width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
                maxHeight: z.ZodOptional<z.ZodNumber>;
                maxWidth: z.ZodOptional<z.ZodNumber>;
                aspectRatio: z.ZodOptional<z.ZodNumber>;
            }, "strip", z.ZodTypeAny, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }, {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            }>;
            position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
        }, "strip", z.ZodTypeAny, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }, {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        }>>; /**
         * If set, answer data included in it will not be decapitalize.
         */
        extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
        defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
        fallbackNext: z.ZodOptional<z.ZodObject<{
            preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
            nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, "strip", z.ZodTypeAny, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }, {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        }>>;
        next: z.ZodNullable<z.ZodString>;
    }, {
        type: z.ZodLiteral<"Wrapper">;
        innerNext: z.ZodString;
    }>, "strip", z.ZodTypeAny, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Wrapper";
        id: string;
        question: string;
        next: string | null;
        innerNext: string;
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Wrapper";
        id: string;
        question: string;
        next: string | null;
        innerNext: string;
    }>]>, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        branchStartId?: {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        } | undefined;
        addFollowupStream?: {
            yes?: string | undefined;
        } | undefined;
        type: "YesNo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        placeholder?: string | undefined;
        keyboardType?: string | undefined;
        dropdownChoices?: {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        } | undefined;
        maxMinus?: string | undefined;
        repeatedItemStartId?: string | undefined;
        type: "MultipleText";
        id: string;
        question: string;
        next: string | null;
        indexName: string;
        variableName: string;
        max: number;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "HowLongAgo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Branch";
        id: string;
        question: string;
        next: string | null;
        branchStartId: {
            true?: string | null | undefined;
            false?: string | null | undefined;
        };
        condition: {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        };
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "BranchWithRelativeComparison";
        id: string;
        question: string;
        next: string | null;
        branchStartId: Record<string, string | null>;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Wrapper";
        id: string;
        question: string;
        next: string | null;
        innerNext: string;
    }, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        branchStartId?: {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        } | undefined;
        addFollowupStream?: {
            yes?: string | undefined;
        } | undefined;
        type: "YesNo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        placeholder?: string | undefined;
        keyboardType?: string | undefined;
        dropdownChoices?: {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        } | undefined;
        maxMinus?: string | undefined;
        repeatedItemStartId?: string | undefined;
        type: "MultipleText";
        id: string;
        question: string;
        next: string | null;
        indexName: string;
        variableName: string;
        max: number;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "HowLongAgo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Branch";
        id: string;
        question: string;
        next: string | null;
        branchStartId: {
            true?: string | null | undefined;
            false?: string | null | undefined;
        };
        condition: {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        };
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "BranchWithRelativeComparison";
        id: string;
        question: string;
        next: string | null;
        branchStartId: Record<string, string | null>;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Wrapper";
        id: string;
        question: string;
        next: string | null;
        innerNext: string;
    }>>, Record<string, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        branchStartId?: {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        } | undefined;
        addFollowupStream?: {
            yes?: string | undefined;
        } | undefined;
        type: "YesNo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        placeholder?: string | undefined;
        keyboardType?: string | undefined;
        dropdownChoices?: {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        } | undefined;
        maxMinus?: string | undefined;
        repeatedItemStartId?: string | undefined;
        type: "MultipleText";
        id: string;
        question: string;
        next: string | null;
        indexName: string;
        variableName: string;
        max: number;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "HowLongAgo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Branch";
        id: string;
        question: string;
        next: string | null;
        branchStartId: {
            true?: string | null | undefined;
            false?: string | null | undefined;
        };
        condition: {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        };
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "BranchWithRelativeComparison";
        id: string;
        question: string;
        next: string | null;
        branchStartId: Record<string, string | null>;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Wrapper";
        id: string;
        question: string;
        next: string | null;
        innerNext: string;
    }>, Record<string, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        branchStartId?: {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        } | undefined;
        addFollowupStream?: {
            yes?: string | undefined;
        } | undefined;
        type: "YesNo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        placeholder?: string | undefined;
        keyboardType?: string | undefined;
        dropdownChoices?: {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        } | undefined;
        maxMinus?: string | undefined;
        repeatedItemStartId?: string | undefined;
        type: "MultipleText";
        id: string;
        question: string;
        next: string | null;
        indexName: string;
        variableName: string;
        max: number;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "HowLongAgo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Branch";
        id: string;
        question: string;
        next: string | null;
        branchStartId: {
            true?: string | null | undefined;
            false?: string | null | undefined;
        };
        condition: {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        };
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "BranchWithRelativeComparison";
        id: string;
        question: string;
        next: string | null;
        branchStartId: Record<string, string | null>;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Wrapper";
        id: string;
        question: string;
        next: string | null;
        innerNext: string;
    }>>, Record<string, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        branchStartId?: {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        } | undefined;
        addFollowupStream?: {
            yes?: string | undefined;
        } | undefined;
        type: "YesNo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        placeholder?: string | undefined;
        keyboardType?: string | undefined;
        dropdownChoices?: {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        } | undefined;
        maxMinus?: string | undefined;
        repeatedItemStartId?: string | undefined;
        type: "MultipleText";
        id: string;
        question: string;
        next: string | null;
        indexName: string;
        variableName: string;
        max: number;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "HowLongAgo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Branch";
        id: string;
        question: string;
        next: string | null;
        branchStartId: {
            true?: string | null | undefined;
            false?: string | null | undefined;
        };
        condition: {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        };
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "BranchWithRelativeComparison";
        id: string;
        question: string;
        next: string | null;
        branchStartId: Record<string, string | null>;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Wrapper";
        id: string;
        question: string;
        next: string | null;
        innerNext: string;
    }>, Record<string, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        branchStartId?: {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        } | undefined;
        addFollowupStream?: {
            yes?: string | undefined;
        } | undefined;
        type: "YesNo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        placeholder?: string | undefined;
        keyboardType?: string | undefined;
        dropdownChoices?: {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        } | undefined;
        maxMinus?: string | undefined;
        repeatedItemStartId?: string | undefined;
        type: "MultipleText";
        id: string;
        question: string;
        next: string | null;
        indexName: string;
        variableName: string;
        max: number;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "HowLongAgo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Branch";
        id: string;
        question: string;
        next: string | null;
        branchStartId: {
            true?: string | null | undefined;
            false?: string | null | undefined;
        };
        condition: {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        };
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "BranchWithRelativeComparison";
        id: string;
        question: string;
        next: string | null;
        branchStartId: Record<string, string | null>;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Wrapper";
        id: string;
        question: string;
        next: string | null;
        innerNext: string;
    }>>>;
    extraData: z.ZodObject<{
        reusableChoices: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodEffects<z.ZodArray<z.ZodString, "atleastone">, [string, ...string[]], [string, ...string[]]>>>;
    }, "strip", z.ZodTypeAny, {
        reusableChoices?: Record<string, [string, ...string[]]> | undefined;
    }, {
        reusableChoices?: Record<string, [string, ...string[]]> | undefined;
    }> | z.ZodObject<{
        reusableChoices: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodEffects<z.ZodArray<z.ZodString, "atleastone">, [string, ...string[]], [string, ...string[]]>>>;
    }, "strict", z.ZodTypeAny, {
        reusableChoices?: Record<string, [string, ...string[]]> | undefined;
    }, {
        reusableChoices?: Record<string, [string, ...string[]]> | undefined;
    }>;
}, "strict", z.ZodTypeAny, {
    studyInfo: {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            message: string;
            title: string;
            buttonText: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: Date;
        endDate: Date;
        pingsFrequency: {
            latestPingNotificationTime?: number | undefined;
            earliestPingNotificationTime: number;
            expireAfterTime: number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    } | {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            message: string;
            title: string;
            buttonText: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: Date;
        endDate: Date;
        pingsFrequency: {
            latestPingNotificationTime?: number | undefined;
            earliestPingNotificationTime: number;
            expireAfterTime: number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    };
    streams: Record<string, Record<string, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        branchStartId?: {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        } | undefined;
        addFollowupStream?: {
            yes?: string | undefined;
        } | undefined;
        type: "YesNo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        placeholder?: string | undefined;
        keyboardType?: string | undefined;
        dropdownChoices?: {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        } | undefined;
        maxMinus?: string | undefined;
        repeatedItemStartId?: string | undefined;
        type: "MultipleText";
        id: string;
        question: string;
        next: string | null;
        indexName: string;
        variableName: string;
        max: number;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "HowLongAgo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Branch";
        id: string;
        question: string;
        next: string | null;
        branchStartId: {
            true?: string | null | undefined;
            false?: string | null | undefined;
        };
        condition: {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        };
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "BranchWithRelativeComparison";
        id: string;
        question: string;
        next: string | null;
        branchStartId: Record<string, string | null>;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Wrapper";
        id: string;
        question: string;
        next: string | null;
        innerNext: string;
    }>>;
    extraData: {
        reusableChoices?: Record<string, [string, ...string[]]> | undefined;
    } | {
        reusableChoices?: Record<string, [string, ...string[]]> | undefined;
    };
}, {
    studyInfo: {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            title?: string | undefined;
            buttonText?: string | undefined;
            message: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: string | Date;
        endDate: string | Date;
        pingsFrequency: {
            latestPingNotificationTime?: string | number | undefined;
            earliestPingNotificationTime: string | number;
            expireAfterTime: string | number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: string[] | {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        } | {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    } | {
        version?: string | undefined;
        dashboardURL?: string | undefined;
        contactEmail?: string | undefined;
        streamsForNthPings?: Record<string, string> | undefined;
        alwaysEnableNextButton?: boolean | undefined;
        specialVariablePlaceholderTreatments?: Record<string, {
            decapitalizeFirstCharacter?: {
                options?: {
                    includes?: undefined;
                    excludes: string[];
                } | {
                    excludes?: undefined;
                    includes: string[];
                } | undefined;
                enabled: boolean;
            } | undefined;
        }> | undefined;
        specialAlertOnLaunch?: {
            title?: string | undefined;
            buttonText?: string | undefined;
            message: string;
        } | undefined;
        id: string;
        studyFileURL: string;
        server: {
            firebase?: {
                config: Record<string, string>;
            } | undefined;
            beiwe?: {
                serverUrl: string;
            } | undefined;
        };
        consentFormUrl: string;
        weekStartsOn: 0 | 2 | 1 | 6 | 3 | 4 | 5;
        startDate: string | Date;
        endDate: string | Date;
        pingsFrequency: {
            latestPingNotificationTime?: string | number | undefined;
            earliestPingNotificationTime: string | number;
            expireAfterTime: string | number;
        }[];
        streamsStartingQuestionIds: Record<string, string>;
        streamsOrder: string[] | {
            0: string[];
            2: string[];
            1: string[];
            6: string[];
            3: string[];
            4: string[];
            5: string[];
        } | {
            sunday: string[];
            monday: string[];
            tuesday: string[];
            wednesday: string[];
            thursday: string[];
            friday: string[];
            saturday: string[];
        };
        streamInCaseOfError: string;
        streamsNotReplacedByFollowupStream: string[];
        notificationContent: {
            bonus?: {
                title: string;
                body: string;
                numberOfCompletionEachWeek: number;
            } | undefined;
            default: {
                title: string;
                body: string;
            };
        };
    };
    streams: Record<string, Record<string, {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        minimumValue?: number | undefined;
        maximumValue?: number | undefined;
        step?: number | undefined;
        defaultValue?: number | undefined;
        defaultValueFromQuestionId?: string | undefined;
        displayCurrentValueToUser?: boolean | undefined;
        type: "Slider";
        id: string;
        question: string;
        next: string | null;
        slider: [string, string];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        specialCasesStartId?: [string, string | null][] | undefined;
        randomizeChoicesOrder?: boolean | undefined;
        randomizeExceptForChoiceIds?: string[] | undefined;
        type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
        id: string;
        question: string;
        next: string | null;
        choices: string | [string, ...string[]];
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        branchStartId?: {
            yes?: string | null | undefined;
            no?: string | null | undefined;
        } | undefined;
        addFollowupStream?: {
            yes?: string | undefined;
        } | undefined;
        type: "YesNo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        placeholder?: string | undefined;
        keyboardType?: string | undefined;
        dropdownChoices?: {
            forceChoice?: boolean | undefined;
            alwaysShowChoices?: boolean | undefined;
            choices: string | [string, ...string[]];
        } | undefined;
        maxMinus?: string | undefined;
        repeatedItemStartId?: string | undefined;
        type: "MultipleText";
        id: string;
        question: string;
        next: string | null;
        indexName: string;
        variableName: string;
        max: number;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "HowLongAgo";
        id: string;
        question: string;
        next: string | null;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Branch";
        id: string;
        question: string;
        next: string | null;
        branchStartId: {
            true?: string | null | undefined;
            false?: string | null | undefined;
        };
        condition: {
            questionId: string;
            questionType: "ChoicesWithSingleAnswer" | "MultipleText";
            compare: "equal";
            target: string | number;
        };
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "BranchWithRelativeComparison";
        id: string;
        question: string;
        next: string | null;
        branchStartId: Record<string, string | null>;
    } | {
        description?: string | undefined;
        image?: {
            url: string;
            style: {
                maxHeight?: number | undefined;
                maxWidth?: number | undefined;
                aspectRatio?: number | undefined;
                width: string | number;
                height: string | number;
            };
            position: "inDescriptionBox" | "left";
        } | undefined;
        extraCustomNextWithoutAnsweringButton?: string | undefined;
        defaultPlaceholderValues?: Record<string, any> | undefined;
        fallbackNext?: {
            preferNotToAnswer?: string | null | undefined;
            nextWithoutAnswering?: string | null | undefined;
        } | undefined;
        type: "Wrapper";
        id: string;
        question: string;
        next: string | null;
        innerNext: string;
    }>>;
    extraData: {
        reusableChoices?: Record<string, [string, ...string[]]> | undefined;
    } | {
        reusableChoices?: Record<string, [string, ...string[]]> | undefined;
    };
}>;
