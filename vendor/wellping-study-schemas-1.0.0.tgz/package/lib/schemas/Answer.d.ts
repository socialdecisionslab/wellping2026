import * as z from "zod";
export declare const SliderAnswerDataSchema: z.ZodObject<{
    value: z.ZodNumber;
}, "strip", z.ZodTypeAny, {
    value: number;
}, {
    value: number;
}>;
export declare const ChoicesWithSingleAnswerAnswerDataSchema: z.ZodObject<{
    value: z.ZodString;
}, "strip", z.ZodTypeAny, {
    value: string;
}, {
    value: string;
}>;
export declare const ChoicesWithMultipleAnswersAnswerChoicesSchema: z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodBoolean], null>, "many">;
export declare const ChoicesWithMultipleAnswersAnswerDataSchema: z.ZodObject<{
    value: z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodBoolean], null>, "many">;
}, "strip", z.ZodTypeAny, {
    value: [string, boolean][];
}, {
    value: [string, boolean][];
}>;
export declare const YesNoAnswerDataSchema: z.ZodObject<{
    value: z.ZodBoolean;
}, "strip", z.ZodTypeAny, {
    value: boolean;
}, {
    value: boolean;
}>;
export declare const MultipleTextAnswerDataSchema: z.ZodObject<{
    value: z.ZodArray<z.ZodString, "many">;
}, "strip", z.ZodTypeAny, {
    value: string[];
}, {
    value: string[];
}>;
export declare const HowLongAgoAnswerDataTypeSchema: z.ZodTuple<[z.ZodNullable<z.ZodNumber>, z.ZodNullable<z.ZodString>], null>;
export declare const HowLongAgoAnswerDataSchema: z.ZodObject<{
    value: z.ZodTuple<[z.ZodNullable<z.ZodNumber>, z.ZodNullable<z.ZodString>], null>;
}, "strip", z.ZodTypeAny, {
    value: [number | null, string | null];
}, {
    value: [number | null, string | null];
}>;
export declare const AnswerDataSchema: z.ZodUnion<[z.ZodObject<{
    value: z.ZodNumber;
}, "strip", z.ZodTypeAny, {
    value: number;
}, {
    value: number;
}>, z.ZodObject<{
    value: z.ZodString;
}, "strip", z.ZodTypeAny, {
    value: string;
}, {
    value: string;
}>, z.ZodObject<{
    value: z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodBoolean], null>, "many">;
}, "strip", z.ZodTypeAny, {
    value: [string, boolean][];
}, {
    value: [string, boolean][];
}>, z.ZodObject<{
    value: z.ZodBoolean;
}, "strip", z.ZodTypeAny, {
    value: boolean;
}, {
    value: boolean;
}>, z.ZodObject<{
    value: z.ZodArray<z.ZodString, "many">;
}, "strip", z.ZodTypeAny, {
    value: string[];
}, {
    value: string[];
}>, z.ZodObject<{
    value: z.ZodTuple<[z.ZodNullable<z.ZodNumber>, z.ZodNullable<z.ZodString>], null>;
}, "strip", z.ZodTypeAny, {
    value: [number | null, string | null];
}, {
    value: [number | null, string | null];
}>]>;
export declare const SliderAnswerSchema: z.ZodObject<z.extendShape<{
    pingId: z.ZodString;
    questionId: z.ZodString;
    /**
     * MARK: WHY_PNA_TRUE_OR_NULL
     *
     * It should not be set to `false`. Instead, it should be either `null` or
     * `false`. This is because using `null` means this key will not be stored in
     * Firebase and hence saving the storage needed for each question.
     */
    preferNotToAnswer: z.ZodUnion<[z.ZodLiteral<true>, z.ZodLiteral<null>]>;
    /**
     * If `null` (and `preferNotToAnswer` is not true), it means that the user
     * clicks "Next" without answering.
     */
    data: z.ZodNullable<z.ZodUnion<[z.ZodObject<{
        value: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        value: number;
    }, {
        value: number;
    }>, z.ZodObject<{
        value: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        value: string;
    }, {
        value: string;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodBoolean], null>, "many">;
    }, "strip", z.ZodTypeAny, {
        value: [string, boolean][];
    }, {
        value: [string, boolean][];
    }>, z.ZodObject<{
        value: z.ZodBoolean;
    }, "strip", z.ZodTypeAny, {
        value: boolean;
    }, {
        value: boolean;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        value: string[];
    }, {
        value: string[];
    }>, z.ZodObject<{
        value: z.ZodTuple<[z.ZodNullable<z.ZodNumber>, z.ZodNullable<z.ZodString>], null>;
    }, "strip", z.ZodTypeAny, {
        value: [number | null, string | null];
    }, {
        value: [number | null, string | null];
    }>]>>;
    /**
     * The last update date for the answer (i.e., the last time the user interact
     * with this question - usually when the user clicks "Next").
     */
    date: z.ZodDate;
}, {
    data: z.ZodNullable<z.ZodObject<{
        value: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        value: number;
    }, {
        value: number;
    }>>;
}>, "strip", z.ZodTypeAny, {
    data: {
        value: number;
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}, {
    data: {
        value: number;
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}>;
export declare const ChoicesWithSingleAnswerAnswerSchema: z.ZodObject<z.extendShape<{
    pingId: z.ZodString;
    questionId: z.ZodString;
    /**
     * MARK: WHY_PNA_TRUE_OR_NULL
     *
     * It should not be set to `false`. Instead, it should be either `null` or
     * `false`. This is because using `null` means this key will not be stored in
     * Firebase and hence saving the storage needed for each question.
     */
    preferNotToAnswer: z.ZodUnion<[z.ZodLiteral<true>, z.ZodLiteral<null>]>;
    /**
     * If `null` (and `preferNotToAnswer` is not true), it means that the user
     * clicks "Next" without answering.
     */
    data: z.ZodNullable<z.ZodUnion<[z.ZodObject<{
        value: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        value: number;
    }, {
        value: number;
    }>, z.ZodObject<{
        value: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        value: string;
    }, {
        value: string;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodBoolean], null>, "many">;
    }, "strip", z.ZodTypeAny, {
        value: [string, boolean][];
    }, {
        value: [string, boolean][];
    }>, z.ZodObject<{
        value: z.ZodBoolean;
    }, "strip", z.ZodTypeAny, {
        value: boolean;
    }, {
        value: boolean;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        value: string[];
    }, {
        value: string[];
    }>, z.ZodObject<{
        value: z.ZodTuple<[z.ZodNullable<z.ZodNumber>, z.ZodNullable<z.ZodString>], null>;
    }, "strip", z.ZodTypeAny, {
        value: [number | null, string | null];
    }, {
        value: [number | null, string | null];
    }>]>>;
    /**
     * The last update date for the answer (i.e., the last time the user interact
     * with this question - usually when the user clicks "Next").
     */
    date: z.ZodDate;
}, {
    data: z.ZodNullable<z.ZodObject<{
        value: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        value: string;
    }, {
        value: string;
    }>>;
}>, "strip", z.ZodTypeAny, {
    data: {
        value: string;
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}, {
    data: {
        value: string;
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}>;
export declare const ChoicesWithMultipleAnswersAnswerSchema: z.ZodObject<z.extendShape<{
    pingId: z.ZodString;
    questionId: z.ZodString;
    /**
     * MARK: WHY_PNA_TRUE_OR_NULL
     *
     * It should not be set to `false`. Instead, it should be either `null` or
     * `false`. This is because using `null` means this key will not be stored in
     * Firebase and hence saving the storage needed for each question.
     */
    preferNotToAnswer: z.ZodUnion<[z.ZodLiteral<true>, z.ZodLiteral<null>]>;
    /**
     * If `null` (and `preferNotToAnswer` is not true), it means that the user
     * clicks "Next" without answering.
     */
    data: z.ZodNullable<z.ZodUnion<[z.ZodObject<{
        value: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        value: number;
    }, {
        value: number;
    }>, z.ZodObject<{
        value: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        value: string;
    }, {
        value: string;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodBoolean], null>, "many">;
    }, "strip", z.ZodTypeAny, {
        value: [string, boolean][];
    }, {
        value: [string, boolean][];
    }>, z.ZodObject<{
        value: z.ZodBoolean;
    }, "strip", z.ZodTypeAny, {
        value: boolean;
    }, {
        value: boolean;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        value: string[];
    }, {
        value: string[];
    }>, z.ZodObject<{
        value: z.ZodTuple<[z.ZodNullable<z.ZodNumber>, z.ZodNullable<z.ZodString>], null>;
    }, "strip", z.ZodTypeAny, {
        value: [number | null, string | null];
    }, {
        value: [number | null, string | null];
    }>]>>;
    /**
     * The last update date for the answer (i.e., the last time the user interact
     * with this question - usually when the user clicks "Next").
     */
    date: z.ZodDate;
}, {
    data: z.ZodNullable<z.ZodObject<{
        value: z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodBoolean], null>, "many">;
    }, "strip", z.ZodTypeAny, {
        value: [string, boolean][];
    }, {
        value: [string, boolean][];
    }>>;
}>, "strip", z.ZodTypeAny, {
    data: {
        value: [string, boolean][];
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}, {
    data: {
        value: [string, boolean][];
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}>;
export declare const YesNoAnswerSchema: z.ZodObject<z.extendShape<{
    pingId: z.ZodString;
    questionId: z.ZodString;
    /**
     * MARK: WHY_PNA_TRUE_OR_NULL
     *
     * It should not be set to `false`. Instead, it should be either `null` or
     * `false`. This is because using `null` means this key will not be stored in
     * Firebase and hence saving the storage needed for each question.
     */
    preferNotToAnswer: z.ZodUnion<[z.ZodLiteral<true>, z.ZodLiteral<null>]>;
    /**
     * If `null` (and `preferNotToAnswer` is not true), it means that the user
     * clicks "Next" without answering.
     */
    data: z.ZodNullable<z.ZodUnion<[z.ZodObject<{
        value: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        value: number;
    }, {
        value: number;
    }>, z.ZodObject<{
        value: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        value: string;
    }, {
        value: string;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodBoolean], null>, "many">;
    }, "strip", z.ZodTypeAny, {
        value: [string, boolean][];
    }, {
        value: [string, boolean][];
    }>, z.ZodObject<{
        value: z.ZodBoolean;
    }, "strip", z.ZodTypeAny, {
        value: boolean;
    }, {
        value: boolean;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        value: string[];
    }, {
        value: string[];
    }>, z.ZodObject<{
        value: z.ZodTuple<[z.ZodNullable<z.ZodNumber>, z.ZodNullable<z.ZodString>], null>;
    }, "strip", z.ZodTypeAny, {
        value: [number | null, string | null];
    }, {
        value: [number | null, string | null];
    }>]>>;
    /**
     * The last update date for the answer (i.e., the last time the user interact
     * with this question - usually when the user clicks "Next").
     */
    date: z.ZodDate;
}, {
    data: z.ZodNullable<z.ZodObject<{
        value: z.ZodBoolean;
    }, "strip", z.ZodTypeAny, {
        value: boolean;
    }, {
        value: boolean;
    }>>;
}>, "strip", z.ZodTypeAny, {
    data: {
        value: boolean;
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}, {
    data: {
        value: boolean;
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}>;
export declare const MultipleTextAnswerSchema: z.ZodObject<z.extendShape<{
    pingId: z.ZodString;
    questionId: z.ZodString;
    /**
     * MARK: WHY_PNA_TRUE_OR_NULL
     *
     * It should not be set to `false`. Instead, it should be either `null` or
     * `false`. This is because using `null` means this key will not be stored in
     * Firebase and hence saving the storage needed for each question.
     */
    preferNotToAnswer: z.ZodUnion<[z.ZodLiteral<true>, z.ZodLiteral<null>]>;
    /**
     * If `null` (and `preferNotToAnswer` is not true), it means that the user
     * clicks "Next" without answering.
     */
    data: z.ZodNullable<z.ZodUnion<[z.ZodObject<{
        value: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        value: number;
    }, {
        value: number;
    }>, z.ZodObject<{
        value: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        value: string;
    }, {
        value: string;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodBoolean], null>, "many">;
    }, "strip", z.ZodTypeAny, {
        value: [string, boolean][];
    }, {
        value: [string, boolean][];
    }>, z.ZodObject<{
        value: z.ZodBoolean;
    }, "strip", z.ZodTypeAny, {
        value: boolean;
    }, {
        value: boolean;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        value: string[];
    }, {
        value: string[];
    }>, z.ZodObject<{
        value: z.ZodTuple<[z.ZodNullable<z.ZodNumber>, z.ZodNullable<z.ZodString>], null>;
    }, "strip", z.ZodTypeAny, {
        value: [number | null, string | null];
    }, {
        value: [number | null, string | null];
    }>]>>;
    /**
     * The last update date for the answer (i.e., the last time the user interact
     * with this question - usually when the user clicks "Next").
     */
    date: z.ZodDate;
}, {
    data: z.ZodNullable<z.ZodObject<{
        value: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        value: string[];
    }, {
        value: string[];
    }>>;
}>, "strip", z.ZodTypeAny, {
    data: {
        value: string[];
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}, {
    data: {
        value: string[];
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}>;
export declare const HowLongAgoAnswerSchema: z.ZodObject<z.extendShape<{
    pingId: z.ZodString;
    questionId: z.ZodString;
    /**
     * MARK: WHY_PNA_TRUE_OR_NULL
     *
     * It should not be set to `false`. Instead, it should be either `null` or
     * `false`. This is because using `null` means this key will not be stored in
     * Firebase and hence saving the storage needed for each question.
     */
    preferNotToAnswer: z.ZodUnion<[z.ZodLiteral<true>, z.ZodLiteral<null>]>;
    /**
     * If `null` (and `preferNotToAnswer` is not true), it means that the user
     * clicks "Next" without answering.
     */
    data: z.ZodNullable<z.ZodUnion<[z.ZodObject<{
        value: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        value: number;
    }, {
        value: number;
    }>, z.ZodObject<{
        value: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        value: string;
    }, {
        value: string;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodBoolean], null>, "many">;
    }, "strip", z.ZodTypeAny, {
        value: [string, boolean][];
    }, {
        value: [string, boolean][];
    }>, z.ZodObject<{
        value: z.ZodBoolean;
    }, "strip", z.ZodTypeAny, {
        value: boolean;
    }, {
        value: boolean;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        value: string[];
    }, {
        value: string[];
    }>, z.ZodObject<{
        value: z.ZodTuple<[z.ZodNullable<z.ZodNumber>, z.ZodNullable<z.ZodString>], null>;
    }, "strip", z.ZodTypeAny, {
        value: [number | null, string | null];
    }, {
        value: [number | null, string | null];
    }>]>>;
    /**
     * The last update date for the answer (i.e., the last time the user interact
     * with this question - usually when the user clicks "Next").
     */
    date: z.ZodDate;
}, {
    data: z.ZodNullable<z.ZodObject<{
        value: z.ZodTuple<[z.ZodNullable<z.ZodNumber>, z.ZodNullable<z.ZodString>], null>;
    }, "strip", z.ZodTypeAny, {
        value: [number | null, string | null];
    }, {
        value: [number | null, string | null];
    }>>;
}>, "strip", z.ZodTypeAny, {
    data: {
        value: [number | null, string | null];
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}, {
    data: {
        value: [number | null, string | null];
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}>;
export declare const AnswerSchema: z.ZodUnion<[z.ZodObject<z.extendShape<{
    pingId: z.ZodString;
    questionId: z.ZodString;
    /**
     * MARK: WHY_PNA_TRUE_OR_NULL
     *
     * It should not be set to `false`. Instead, it should be either `null` or
     * `false`. This is because using `null` means this key will not be stored in
     * Firebase and hence saving the storage needed for each question.
     */
    preferNotToAnswer: z.ZodUnion<[z.ZodLiteral<true>, z.ZodLiteral<null>]>;
    /**
     * If `null` (and `preferNotToAnswer` is not true), it means that the user
     * clicks "Next" without answering.
     */
    data: z.ZodNullable<z.ZodUnion<[z.ZodObject<{
        value: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        value: number;
    }, {
        value: number;
    }>, z.ZodObject<{
        value: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        value: string;
    }, {
        value: string;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodBoolean], null>, "many">;
    }, "strip", z.ZodTypeAny, {
        value: [string, boolean][];
    }, {
        value: [string, boolean][];
    }>, z.ZodObject<{
        value: z.ZodBoolean;
    }, "strip", z.ZodTypeAny, {
        value: boolean;
    }, {
        value: boolean;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        value: string[];
    }, {
        value: string[];
    }>, z.ZodObject<{
        value: z.ZodTuple<[z.ZodNullable<z.ZodNumber>, z.ZodNullable<z.ZodString>], null>;
    }, "strip", z.ZodTypeAny, {
        value: [number | null, string | null];
    }, {
        value: [number | null, string | null];
    }>]>>;
    /**
     * The last update date for the answer (i.e., the last time the user interact
     * with this question - usually when the user clicks "Next").
     */
    date: z.ZodDate;
}, {
    data: z.ZodNullable<z.ZodObject<{
        value: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        value: number;
    }, {
        value: number;
    }>>;
}>, "strip", z.ZodTypeAny, {
    data: {
        value: number;
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}, {
    data: {
        value: number;
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}>, z.ZodObject<z.extendShape<{
    pingId: z.ZodString;
    questionId: z.ZodString;
    /**
     * MARK: WHY_PNA_TRUE_OR_NULL
     *
     * It should not be set to `false`. Instead, it should be either `null` or
     * `false`. This is because using `null` means this key will not be stored in
     * Firebase and hence saving the storage needed for each question.
     */
    preferNotToAnswer: z.ZodUnion<[z.ZodLiteral<true>, z.ZodLiteral<null>]>;
    /**
     * If `null` (and `preferNotToAnswer` is not true), it means that the user
     * clicks "Next" without answering.
     */
    data: z.ZodNullable<z.ZodUnion<[z.ZodObject<{
        value: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        value: number;
    }, {
        value: number;
    }>, z.ZodObject<{
        value: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        value: string;
    }, {
        value: string;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodBoolean], null>, "many">;
    }, "strip", z.ZodTypeAny, {
        value: [string, boolean][];
    }, {
        value: [string, boolean][];
    }>, z.ZodObject<{
        value: z.ZodBoolean;
    }, "strip", z.ZodTypeAny, {
        value: boolean;
    }, {
        value: boolean;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        value: string[];
    }, {
        value: string[];
    }>, z.ZodObject<{
        value: z.ZodTuple<[z.ZodNullable<z.ZodNumber>, z.ZodNullable<z.ZodString>], null>;
    }, "strip", z.ZodTypeAny, {
        value: [number | null, string | null];
    }, {
        value: [number | null, string | null];
    }>]>>;
    /**
     * The last update date for the answer (i.e., the last time the user interact
     * with this question - usually when the user clicks "Next").
     */
    date: z.ZodDate;
}, {
    data: z.ZodNullable<z.ZodObject<{
        value: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        value: string;
    }, {
        value: string;
    }>>;
}>, "strip", z.ZodTypeAny, {
    data: {
        value: string;
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}, {
    data: {
        value: string;
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}>, z.ZodObject<z.extendShape<{
    pingId: z.ZodString;
    questionId: z.ZodString;
    /**
     * MARK: WHY_PNA_TRUE_OR_NULL
     *
     * It should not be set to `false`. Instead, it should be either `null` or
     * `false`. This is because using `null` means this key will not be stored in
     * Firebase and hence saving the storage needed for each question.
     */
    preferNotToAnswer: z.ZodUnion<[z.ZodLiteral<true>, z.ZodLiteral<null>]>;
    /**
     * If `null` (and `preferNotToAnswer` is not true), it means that the user
     * clicks "Next" without answering.
     */
    data: z.ZodNullable<z.ZodUnion<[z.ZodObject<{
        value: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        value: number;
    }, {
        value: number;
    }>, z.ZodObject<{
        value: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        value: string;
    }, {
        value: string;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodBoolean], null>, "many">;
    }, "strip", z.ZodTypeAny, {
        value: [string, boolean][];
    }, {
        value: [string, boolean][];
    }>, z.ZodObject<{
        value: z.ZodBoolean;
    }, "strip", z.ZodTypeAny, {
        value: boolean;
    }, {
        value: boolean;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        value: string[];
    }, {
        value: string[];
    }>, z.ZodObject<{
        value: z.ZodTuple<[z.ZodNullable<z.ZodNumber>, z.ZodNullable<z.ZodString>], null>;
    }, "strip", z.ZodTypeAny, {
        value: [number | null, string | null];
    }, {
        value: [number | null, string | null];
    }>]>>;
    /**
     * The last update date for the answer (i.e., the last time the user interact
     * with this question - usually when the user clicks "Next").
     */
    date: z.ZodDate;
}, {
    data: z.ZodNullable<z.ZodObject<{
        value: z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodBoolean], null>, "many">;
    }, "strip", z.ZodTypeAny, {
        value: [string, boolean][];
    }, {
        value: [string, boolean][];
    }>>;
}>, "strip", z.ZodTypeAny, {
    data: {
        value: [string, boolean][];
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}, {
    data: {
        value: [string, boolean][];
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}>, z.ZodObject<z.extendShape<{
    pingId: z.ZodString;
    questionId: z.ZodString;
    /**
     * MARK: WHY_PNA_TRUE_OR_NULL
     *
     * It should not be set to `false`. Instead, it should be either `null` or
     * `false`. This is because using `null` means this key will not be stored in
     * Firebase and hence saving the storage needed for each question.
     */
    preferNotToAnswer: z.ZodUnion<[z.ZodLiteral<true>, z.ZodLiteral<null>]>;
    /**
     * If `null` (and `preferNotToAnswer` is not true), it means that the user
     * clicks "Next" without answering.
     */
    data: z.ZodNullable<z.ZodUnion<[z.ZodObject<{
        value: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        value: number;
    }, {
        value: number;
    }>, z.ZodObject<{
        value: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        value: string;
    }, {
        value: string;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodBoolean], null>, "many">;
    }, "strip", z.ZodTypeAny, {
        value: [string, boolean][];
    }, {
        value: [string, boolean][];
    }>, z.ZodObject<{
        value: z.ZodBoolean;
    }, "strip", z.ZodTypeAny, {
        value: boolean;
    }, {
        value: boolean;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        value: string[];
    }, {
        value: string[];
    }>, z.ZodObject<{
        value: z.ZodTuple<[z.ZodNullable<z.ZodNumber>, z.ZodNullable<z.ZodString>], null>;
    }, "strip", z.ZodTypeAny, {
        value: [number | null, string | null];
    }, {
        value: [number | null, string | null];
    }>]>>;
    /**
     * The last update date for the answer (i.e., the last time the user interact
     * with this question - usually when the user clicks "Next").
     */
    date: z.ZodDate;
}, {
    data: z.ZodNullable<z.ZodObject<{
        value: z.ZodBoolean;
    }, "strip", z.ZodTypeAny, {
        value: boolean;
    }, {
        value: boolean;
    }>>;
}>, "strip", z.ZodTypeAny, {
    data: {
        value: boolean;
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}, {
    data: {
        value: boolean;
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}>, z.ZodObject<z.extendShape<{
    pingId: z.ZodString;
    questionId: z.ZodString;
    /**
     * MARK: WHY_PNA_TRUE_OR_NULL
     *
     * It should not be set to `false`. Instead, it should be either `null` or
     * `false`. This is because using `null` means this key will not be stored in
     * Firebase and hence saving the storage needed for each question.
     */
    preferNotToAnswer: z.ZodUnion<[z.ZodLiteral<true>, z.ZodLiteral<null>]>;
    /**
     * If `null` (and `preferNotToAnswer` is not true), it means that the user
     * clicks "Next" without answering.
     */
    data: z.ZodNullable<z.ZodUnion<[z.ZodObject<{
        value: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        value: number;
    }, {
        value: number;
    }>, z.ZodObject<{
        value: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        value: string;
    }, {
        value: string;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodBoolean], null>, "many">;
    }, "strip", z.ZodTypeAny, {
        value: [string, boolean][];
    }, {
        value: [string, boolean][];
    }>, z.ZodObject<{
        value: z.ZodBoolean;
    }, "strip", z.ZodTypeAny, {
        value: boolean;
    }, {
        value: boolean;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        value: string[];
    }, {
        value: string[];
    }>, z.ZodObject<{
        value: z.ZodTuple<[z.ZodNullable<z.ZodNumber>, z.ZodNullable<z.ZodString>], null>;
    }, "strip", z.ZodTypeAny, {
        value: [number | null, string | null];
    }, {
        value: [number | null, string | null];
    }>]>>;
    /**
     * The last update date for the answer (i.e., the last time the user interact
     * with this question - usually when the user clicks "Next").
     */
    date: z.ZodDate;
}, {
    data: z.ZodNullable<z.ZodObject<{
        value: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        value: string[];
    }, {
        value: string[];
    }>>;
}>, "strip", z.ZodTypeAny, {
    data: {
        value: string[];
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}, {
    data: {
        value: string[];
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}>, z.ZodObject<z.extendShape<{
    pingId: z.ZodString;
    questionId: z.ZodString;
    /**
     * MARK: WHY_PNA_TRUE_OR_NULL
     *
     * It should not be set to `false`. Instead, it should be either `null` or
     * `false`. This is because using `null` means this key will not be stored in
     * Firebase and hence saving the storage needed for each question.
     */
    preferNotToAnswer: z.ZodUnion<[z.ZodLiteral<true>, z.ZodLiteral<null>]>;
    /**
     * If `null` (and `preferNotToAnswer` is not true), it means that the user
     * clicks "Next" without answering.
     */
    data: z.ZodNullable<z.ZodUnion<[z.ZodObject<{
        value: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        value: number;
    }, {
        value: number;
    }>, z.ZodObject<{
        value: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        value: string;
    }, {
        value: string;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodBoolean], null>, "many">;
    }, "strip", z.ZodTypeAny, {
        value: [string, boolean][];
    }, {
        value: [string, boolean][];
    }>, z.ZodObject<{
        value: z.ZodBoolean;
    }, "strip", z.ZodTypeAny, {
        value: boolean;
    }, {
        value: boolean;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        value: string[];
    }, {
        value: string[];
    }>, z.ZodObject<{
        value: z.ZodTuple<[z.ZodNullable<z.ZodNumber>, z.ZodNullable<z.ZodString>], null>;
    }, "strip", z.ZodTypeAny, {
        value: [number | null, string | null];
    }, {
        value: [number | null, string | null];
    }>]>>;
    /**
     * The last update date for the answer (i.e., the last time the user interact
     * with this question - usually when the user clicks "Next").
     */
    date: z.ZodDate;
}, {
    data: z.ZodNullable<z.ZodObject<{
        value: z.ZodTuple<[z.ZodNullable<z.ZodNumber>, z.ZodNullable<z.ZodString>], null>;
    }, "strip", z.ZodTypeAny, {
        value: [number | null, string | null];
    }, {
        value: [number | null, string | null];
    }>>;
}>, "strip", z.ZodTypeAny, {
    data: {
        value: [number | null, string | null];
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}, {
    data: {
        value: [number | null, string | null];
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}>]>;
export declare const AnswersListSchema: z.ZodRecord<z.ZodString, z.ZodUnion<[z.ZodObject<z.extendShape<{
    pingId: z.ZodString;
    questionId: z.ZodString;
    /**
     * MARK: WHY_PNA_TRUE_OR_NULL
     *
     * It should not be set to `false`. Instead, it should be either `null` or
     * `false`. This is because using `null` means this key will not be stored in
     * Firebase and hence saving the storage needed for each question.
     */
    preferNotToAnswer: z.ZodUnion<[z.ZodLiteral<true>, z.ZodLiteral<null>]>;
    /**
     * If `null` (and `preferNotToAnswer` is not true), it means that the user
     * clicks "Next" without answering.
     */
    data: z.ZodNullable<z.ZodUnion<[z.ZodObject<{
        value: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        value: number;
    }, {
        value: number;
    }>, z.ZodObject<{
        value: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        value: string;
    }, {
        value: string;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodBoolean], null>, "many">;
    }, "strip", z.ZodTypeAny, {
        value: [string, boolean][];
    }, {
        value: [string, boolean][];
    }>, z.ZodObject<{
        value: z.ZodBoolean;
    }, "strip", z.ZodTypeAny, {
        value: boolean;
    }, {
        value: boolean;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        value: string[];
    }, {
        value: string[];
    }>, z.ZodObject<{
        value: z.ZodTuple<[z.ZodNullable<z.ZodNumber>, z.ZodNullable<z.ZodString>], null>;
    }, "strip", z.ZodTypeAny, {
        value: [number | null, string | null];
    }, {
        value: [number | null, string | null];
    }>]>>;
    /**
     * The last update date for the answer (i.e., the last time the user interact
     * with this question - usually when the user clicks "Next").
     */
    date: z.ZodDate;
}, {
    data: z.ZodNullable<z.ZodObject<{
        value: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        value: number;
    }, {
        value: number;
    }>>;
}>, "strip", z.ZodTypeAny, {
    data: {
        value: number;
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}, {
    data: {
        value: number;
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}>, z.ZodObject<z.extendShape<{
    pingId: z.ZodString;
    questionId: z.ZodString;
    /**
     * MARK: WHY_PNA_TRUE_OR_NULL
     *
     * It should not be set to `false`. Instead, it should be either `null` or
     * `false`. This is because using `null` means this key will not be stored in
     * Firebase and hence saving the storage needed for each question.
     */
    preferNotToAnswer: z.ZodUnion<[z.ZodLiteral<true>, z.ZodLiteral<null>]>;
    /**
     * If `null` (and `preferNotToAnswer` is not true), it means that the user
     * clicks "Next" without answering.
     */
    data: z.ZodNullable<z.ZodUnion<[z.ZodObject<{
        value: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        value: number;
    }, {
        value: number;
    }>, z.ZodObject<{
        value: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        value: string;
    }, {
        value: string;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodBoolean], null>, "many">;
    }, "strip", z.ZodTypeAny, {
        value: [string, boolean][];
    }, {
        value: [string, boolean][];
    }>, z.ZodObject<{
        value: z.ZodBoolean;
    }, "strip", z.ZodTypeAny, {
        value: boolean;
    }, {
        value: boolean;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        value: string[];
    }, {
        value: string[];
    }>, z.ZodObject<{
        value: z.ZodTuple<[z.ZodNullable<z.ZodNumber>, z.ZodNullable<z.ZodString>], null>;
    }, "strip", z.ZodTypeAny, {
        value: [number | null, string | null];
    }, {
        value: [number | null, string | null];
    }>]>>;
    /**
     * The last update date for the answer (i.e., the last time the user interact
     * with this question - usually when the user clicks "Next").
     */
    date: z.ZodDate;
}, {
    data: z.ZodNullable<z.ZodObject<{
        value: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        value: string;
    }, {
        value: string;
    }>>;
}>, "strip", z.ZodTypeAny, {
    data: {
        value: string;
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}, {
    data: {
        value: string;
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}>, z.ZodObject<z.extendShape<{
    pingId: z.ZodString;
    questionId: z.ZodString;
    /**
     * MARK: WHY_PNA_TRUE_OR_NULL
     *
     * It should not be set to `false`. Instead, it should be either `null` or
     * `false`. This is because using `null` means this key will not be stored in
     * Firebase and hence saving the storage needed for each question.
     */
    preferNotToAnswer: z.ZodUnion<[z.ZodLiteral<true>, z.ZodLiteral<null>]>;
    /**
     * If `null` (and `preferNotToAnswer` is not true), it means that the user
     * clicks "Next" without answering.
     */
    data: z.ZodNullable<z.ZodUnion<[z.ZodObject<{
        value: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        value: number;
    }, {
        value: number;
    }>, z.ZodObject<{
        value: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        value: string;
    }, {
        value: string;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodBoolean], null>, "many">;
    }, "strip", z.ZodTypeAny, {
        value: [string, boolean][];
    }, {
        value: [string, boolean][];
    }>, z.ZodObject<{
        value: z.ZodBoolean;
    }, "strip", z.ZodTypeAny, {
        value: boolean;
    }, {
        value: boolean;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        value: string[];
    }, {
        value: string[];
    }>, z.ZodObject<{
        value: z.ZodTuple<[z.ZodNullable<z.ZodNumber>, z.ZodNullable<z.ZodString>], null>;
    }, "strip", z.ZodTypeAny, {
        value: [number | null, string | null];
    }, {
        value: [number | null, string | null];
    }>]>>;
    /**
     * The last update date for the answer (i.e., the last time the user interact
     * with this question - usually when the user clicks "Next").
     */
    date: z.ZodDate;
}, {
    data: z.ZodNullable<z.ZodObject<{
        value: z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodBoolean], null>, "many">;
    }, "strip", z.ZodTypeAny, {
        value: [string, boolean][];
    }, {
        value: [string, boolean][];
    }>>;
}>, "strip", z.ZodTypeAny, {
    data: {
        value: [string, boolean][];
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}, {
    data: {
        value: [string, boolean][];
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}>, z.ZodObject<z.extendShape<{
    pingId: z.ZodString;
    questionId: z.ZodString;
    /**
     * MARK: WHY_PNA_TRUE_OR_NULL
     *
     * It should not be set to `false`. Instead, it should be either `null` or
     * `false`. This is because using `null` means this key will not be stored in
     * Firebase and hence saving the storage needed for each question.
     */
    preferNotToAnswer: z.ZodUnion<[z.ZodLiteral<true>, z.ZodLiteral<null>]>;
    /**
     * If `null` (and `preferNotToAnswer` is not true), it means that the user
     * clicks "Next" without answering.
     */
    data: z.ZodNullable<z.ZodUnion<[z.ZodObject<{
        value: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        value: number;
    }, {
        value: number;
    }>, z.ZodObject<{
        value: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        value: string;
    }, {
        value: string;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodBoolean], null>, "many">;
    }, "strip", z.ZodTypeAny, {
        value: [string, boolean][];
    }, {
        value: [string, boolean][];
    }>, z.ZodObject<{
        value: z.ZodBoolean;
    }, "strip", z.ZodTypeAny, {
        value: boolean;
    }, {
        value: boolean;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        value: string[];
    }, {
        value: string[];
    }>, z.ZodObject<{
        value: z.ZodTuple<[z.ZodNullable<z.ZodNumber>, z.ZodNullable<z.ZodString>], null>;
    }, "strip", z.ZodTypeAny, {
        value: [number | null, string | null];
    }, {
        value: [number | null, string | null];
    }>]>>;
    /**
     * The last update date for the answer (i.e., the last time the user interact
     * with this question - usually when the user clicks "Next").
     */
    date: z.ZodDate;
}, {
    data: z.ZodNullable<z.ZodObject<{
        value: z.ZodBoolean;
    }, "strip", z.ZodTypeAny, {
        value: boolean;
    }, {
        value: boolean;
    }>>;
}>, "strip", z.ZodTypeAny, {
    data: {
        value: boolean;
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}, {
    data: {
        value: boolean;
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}>, z.ZodObject<z.extendShape<{
    pingId: z.ZodString;
    questionId: z.ZodString;
    /**
     * MARK: WHY_PNA_TRUE_OR_NULL
     *
     * It should not be set to `false`. Instead, it should be either `null` or
     * `false`. This is because using `null` means this key will not be stored in
     * Firebase and hence saving the storage needed for each question.
     */
    preferNotToAnswer: z.ZodUnion<[z.ZodLiteral<true>, z.ZodLiteral<null>]>;
    /**
     * If `null` (and `preferNotToAnswer` is not true), it means that the user
     * clicks "Next" without answering.
     */
    data: z.ZodNullable<z.ZodUnion<[z.ZodObject<{
        value: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        value: number;
    }, {
        value: number;
    }>, z.ZodObject<{
        value: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        value: string;
    }, {
        value: string;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodBoolean], null>, "many">;
    }, "strip", z.ZodTypeAny, {
        value: [string, boolean][];
    }, {
        value: [string, boolean][];
    }>, z.ZodObject<{
        value: z.ZodBoolean;
    }, "strip", z.ZodTypeAny, {
        value: boolean;
    }, {
        value: boolean;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        value: string[];
    }, {
        value: string[];
    }>, z.ZodObject<{
        value: z.ZodTuple<[z.ZodNullable<z.ZodNumber>, z.ZodNullable<z.ZodString>], null>;
    }, "strip", z.ZodTypeAny, {
        value: [number | null, string | null];
    }, {
        value: [number | null, string | null];
    }>]>>;
    /**
     * The last update date for the answer (i.e., the last time the user interact
     * with this question - usually when the user clicks "Next").
     */
    date: z.ZodDate;
}, {
    data: z.ZodNullable<z.ZodObject<{
        value: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        value: string[];
    }, {
        value: string[];
    }>>;
}>, "strip", z.ZodTypeAny, {
    data: {
        value: string[];
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}, {
    data: {
        value: string[];
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}>, z.ZodObject<z.extendShape<{
    pingId: z.ZodString;
    questionId: z.ZodString;
    /**
     * MARK: WHY_PNA_TRUE_OR_NULL
     *
     * It should not be set to `false`. Instead, it should be either `null` or
     * `false`. This is because using `null` means this key will not be stored in
     * Firebase and hence saving the storage needed for each question.
     */
    preferNotToAnswer: z.ZodUnion<[z.ZodLiteral<true>, z.ZodLiteral<null>]>;
    /**
     * If `null` (and `preferNotToAnswer` is not true), it means that the user
     * clicks "Next" without answering.
     */
    data: z.ZodNullable<z.ZodUnion<[z.ZodObject<{
        value: z.ZodNumber;
    }, "strip", z.ZodTypeAny, {
        value: number;
    }, {
        value: number;
    }>, z.ZodObject<{
        value: z.ZodString;
    }, "strip", z.ZodTypeAny, {
        value: string;
    }, {
        value: string;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodBoolean], null>, "many">;
    }, "strip", z.ZodTypeAny, {
        value: [string, boolean][];
    }, {
        value: [string, boolean][];
    }>, z.ZodObject<{
        value: z.ZodBoolean;
    }, "strip", z.ZodTypeAny, {
        value: boolean;
    }, {
        value: boolean;
    }>, z.ZodObject<{
        value: z.ZodArray<z.ZodString, "many">;
    }, "strip", z.ZodTypeAny, {
        value: string[];
    }, {
        value: string[];
    }>, z.ZodObject<{
        value: z.ZodTuple<[z.ZodNullable<z.ZodNumber>, z.ZodNullable<z.ZodString>], null>;
    }, "strip", z.ZodTypeAny, {
        value: [number | null, string | null];
    }, {
        value: [number | null, string | null];
    }>]>>;
    /**
     * The last update date for the answer (i.e., the last time the user interact
     * with this question - usually when the user clicks "Next").
     */
    date: z.ZodDate;
}, {
    data: z.ZodNullable<z.ZodObject<{
        value: z.ZodTuple<[z.ZodNullable<z.ZodNumber>, z.ZodNullable<z.ZodString>], null>;
    }, "strip", z.ZodTypeAny, {
        value: [number | null, string | null];
    }, {
        value: [number | null, string | null];
    }>>;
}>, "strip", z.ZodTypeAny, {
    data: {
        value: [number | null, string | null];
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}, {
    data: {
        value: [number | null, string | null];
    } | null;
    pingId: string;
    questionId: string;
    preferNotToAnswer: true | null;
    date: Date;
}>]>>;
