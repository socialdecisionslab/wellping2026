/**
 * These are common schemas that are used by other schemas.
 * It is moved here to avoid circular dependency.
 */
import * as z from "zod";
/**
 * Used to indicate a key should not be in an object.
 */
export declare const EXCLUDE_KEY_SCHEMA: z.ZodOptional<z.ZodNever>;
export declare const StudyIdSchema: z.ZodString;
export declare const StreamNameSchema: z.ZodString;
export declare const QuestionIdSchema: z.ZodString;
export declare const PingIdSchema: z.ZodString;
/**
 * Note: This isn't current used anywhere because this breaks the type
 * inference (it will set the type to `any`).
 *
 * This is a workaround such that the error message for missing it will be
 * > Issue #0: invalid_type at
 * > Required
 * instead of the more confusing
 * > Issue #0: invalid_union at
 * > Invalid input
 *
 * Notice that if an `.optional()` follows, it is unnecessary to use this.
 *
 * Probably don't need to use it after https://github.com/vriad/zod/issues/97
 * is addressed.
 */
export declare const CustomNullable: (Schema: z.ZodType<any, any>, path: string[]) => z.ZodEffects<z.ZodNullable<z.ZodType<any, any, any>>, any, any>;
export declare const ChoiceSchema: z.ZodString;
export declare const ChoicesListSchema: z.ZodEffects<z.ZodArray<z.ZodString, "atleastone">, [string, ...string[]], [string, ...string[]]>;
export declare type GetSchemaOptions = {
    strict?: boolean;
};
