import * as z from "zod";
export declare const StreamsSchema: z.ZodRecord<z.ZodString, z.ZodEffects<z.ZodEffects<z.ZodRecord<z.ZodString, z.ZodEffects<z.ZodUnion<[z.ZodEffects<z.ZodObject<z.extendShape<{
    id: z.ZodString;
    type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
    question: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    image: z.ZodOptional<z.ZodObject<{
        url: z.ZodString;
        style: z.ZodObject<{
            width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            maxHeight: z.ZodOptional<z.ZodNumber>;
            maxWidth: z.ZodOptional<z.ZodNumber>;
            aspectRatio: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }>;
        position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
    }, "strip", z.ZodTypeAny, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }>>;
    extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
    defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    fallbackNext: z.ZodOptional<z.ZodObject<{
        preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, "strip", z.ZodTypeAny, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }>>;
    next: z.ZodNullable<z.ZodString>;
}, {
    type: z.ZodLiteral<"Slider">;
    slider: z.ZodTuple<[z.ZodString, z.ZodString], null>;
    minimumValue: z.ZodOptional<z.ZodNumber>;
    maximumValue: z.ZodOptional<z.ZodNumber>;
    step: z.ZodOptional<z.ZodNumber>;
    defaultValue: z.ZodOptional<z.ZodNumber>;
    defaultValueFromQuestionId: z.ZodOptional<z.ZodString>;
    displayCurrentValueToUser: z.ZodOptional<z.ZodBoolean>;
}>, "strict", z.ZodTypeAny, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    minimumValue?: number | undefined;
    maximumValue?: number | undefined;
    step?: number | undefined;
    defaultValue?: number | undefined;
    defaultValueFromQuestionId?: string | undefined;
    displayCurrentValueToUser?: boolean | undefined;
    type: "Slider";
    id: string;
    question: string;
    next: string | null;
    slider: [string, string];
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    minimumValue?: number | undefined;
    maximumValue?: number | undefined;
    step?: number | undefined;
    defaultValue?: number | undefined;
    defaultValueFromQuestionId?: string | undefined;
    displayCurrentValueToUser?: boolean | undefined;
    type: "Slider";
    id: string;
    question: string;
    next: string | null;
    slider: [string, string];
}>, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    minimumValue?: number | undefined;
    maximumValue?: number | undefined;
    step?: number | undefined;
    defaultValue?: number | undefined;
    defaultValueFromQuestionId?: string | undefined;
    displayCurrentValueToUser?: boolean | undefined;
    type: "Slider";
    id: string;
    question: string;
    next: string | null;
    slider: [string, string];
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    minimumValue?: number | undefined;
    maximumValue?: number | undefined;
    step?: number | undefined;
    defaultValue?: number | undefined;
    defaultValueFromQuestionId?: string | undefined;
    displayCurrentValueToUser?: boolean | undefined;
    type: "Slider";
    id: string;
    question: string;
    next: string | null;
    slider: [string, string];
}> | z.ZodEffects<z.ZodObject<z.extendShape<{
    id: z.ZodString;
    type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
    question: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    image: z.ZodOptional<z.ZodObject<{
        url: z.ZodString;
        style: z.ZodObject<{
            width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            maxHeight: z.ZodOptional<z.ZodNumber>;
            maxWidth: z.ZodOptional<z.ZodNumber>;
            aspectRatio: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }>;
        position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
    }, "strip", z.ZodTypeAny, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }>>;
    extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
    defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    fallbackNext: z.ZodOptional<z.ZodObject<{
        preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, "strip", z.ZodTypeAny, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }>>;
    next: z.ZodNullable<z.ZodString>;
}, {
    type: z.ZodLiteral<"Slider">;
    slider: z.ZodTuple<[z.ZodString, z.ZodString], null>;
    minimumValue: z.ZodOptional<z.ZodNumber>;
    maximumValue: z.ZodOptional<z.ZodNumber>;
    step: z.ZodOptional<z.ZodNumber>;
    defaultValue: z.ZodOptional<z.ZodNumber>;
    defaultValueFromQuestionId: z.ZodOptional<z.ZodString>;
    displayCurrentValueToUser: z.ZodOptional<z.ZodBoolean>;
}>, "strip", z.ZodTypeAny, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    minimumValue?: number | undefined;
    maximumValue?: number | undefined;
    step?: number | undefined;
    defaultValue?: number | undefined;
    defaultValueFromQuestionId?: string | undefined;
    displayCurrentValueToUser?: boolean | undefined;
    type: "Slider";
    id: string;
    question: string;
    next: string | null;
    slider: [string, string];
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    minimumValue?: number | undefined;
    maximumValue?: number | undefined;
    step?: number | undefined;
    defaultValue?: number | undefined;
    defaultValueFromQuestionId?: string | undefined;
    displayCurrentValueToUser?: boolean | undefined;
    type: "Slider";
    id: string;
    question: string;
    next: string | null;
    slider: [string, string];
}>, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    minimumValue?: number | undefined;
    maximumValue?: number | undefined;
    step?: number | undefined;
    defaultValue?: number | undefined;
    defaultValueFromQuestionId?: string | undefined;
    displayCurrentValueToUser?: boolean | undefined;
    type: "Slider";
    id: string;
    question: string;
    next: string | null;
    slider: [string, string];
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    minimumValue?: number | undefined;
    maximumValue?: number | undefined;
    step?: number | undefined;
    defaultValue?: number | undefined;
    defaultValueFromQuestionId?: string | undefined;
    displayCurrentValueToUser?: boolean | undefined;
    type: "Slider";
    id: string;
    question: string;
    next: string | null;
    slider: [string, string];
}>, z.ZodEffects<z.ZodEffects<z.ZodEffects<z.ZodEffects<z.ZodObject<z.extendShape<{
    id: z.ZodString;
    type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
    question: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    image: z.ZodOptional<z.ZodObject<{
        url: z.ZodString;
        style: z.ZodObject<{
            width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            maxHeight: z.ZodOptional<z.ZodNumber>;
            maxWidth: z.ZodOptional<z.ZodNumber>;
            aspectRatio: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }>;
        position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
    }, "strip", z.ZodTypeAny, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }>>;
    extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
    defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    fallbackNext: z.ZodOptional<z.ZodObject<{
        preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, "strip", z.ZodTypeAny, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }>>;
    next: z.ZodNullable<z.ZodString>;
}, {
    type: z.ZodUnion<[z.ZodLiteral<"ChoicesWithSingleAnswer">, z.ZodLiteral<"ChoicesWithMultipleAnswers">]>;
    choices: z.ZodUnion<[z.ZodString, z.ZodEffects<z.ZodArray<z.ZodString, "atleastone">, [string, ...string[]], [string, ...string[]]>]>;
    specialCasesStartId: z.ZodOptional<z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodNullable<z.ZodString>], null>, "many">>;
    randomizeChoicesOrder: z.ZodOptional<z.ZodBoolean>;
    randomizeExceptForChoiceIds: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
}>, "strip", z.ZodTypeAny, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}>, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}>, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}>, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}>, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}> | z.ZodEffects<z.ZodEffects<z.ZodEffects<z.ZodEffects<z.ZodObject<z.extendShape<{
    id: z.ZodString;
    type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
    question: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    image: z.ZodOptional<z.ZodObject<{
        url: z.ZodString;
        style: z.ZodObject<{
            width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            maxHeight: z.ZodOptional<z.ZodNumber>;
            maxWidth: z.ZodOptional<z.ZodNumber>;
            aspectRatio: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }>;
        position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
    }, "strip", z.ZodTypeAny, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }>>;
    extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
    defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    fallbackNext: z.ZodOptional<z.ZodObject<{
        preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, "strip", z.ZodTypeAny, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }>>;
    next: z.ZodNullable<z.ZodString>;
}, {
    type: z.ZodUnion<[z.ZodLiteral<"ChoicesWithSingleAnswer">, z.ZodLiteral<"ChoicesWithMultipleAnswers">]>;
    choices: z.ZodUnion<[z.ZodString, z.ZodEffects<z.ZodArray<z.ZodString, "atleastone">, [string, ...string[]], [string, ...string[]]>]>;
    specialCasesStartId: z.ZodOptional<z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodNullable<z.ZodString>], null>, "many">>;
    randomizeChoicesOrder: z.ZodOptional<z.ZodBoolean>;
    randomizeExceptForChoiceIds: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
}>, "strict", z.ZodTypeAny, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}>, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}>, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}>, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}>, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}>, z.ZodEffects<z.ZodEffects<z.ZodEffects<z.ZodEffects<z.ZodObject<z.extendShape<{
    id: z.ZodString;
    type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
    question: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    image: z.ZodOptional<z.ZodObject<{
        url: z.ZodString;
        style: z.ZodObject<{
            width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            maxHeight: z.ZodOptional<z.ZodNumber>;
            maxWidth: z.ZodOptional<z.ZodNumber>;
            aspectRatio: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }>;
        position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
    }, "strip", z.ZodTypeAny, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }>>;
    extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
    defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    fallbackNext: z.ZodOptional<z.ZodObject<{
        preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, "strip", z.ZodTypeAny, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }>>;
    next: z.ZodNullable<z.ZodString>;
}, {
    type: z.ZodUnion<[z.ZodLiteral<"ChoicesWithSingleAnswer">, z.ZodLiteral<"ChoicesWithMultipleAnswers">]>;
    choices: z.ZodUnion<[z.ZodString, z.ZodEffects<z.ZodArray<z.ZodString, "atleastone">, [string, ...string[]], [string, ...string[]]>]>;
    specialCasesStartId: z.ZodOptional<z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodNullable<z.ZodString>], null>, "many">>;
    randomizeChoicesOrder: z.ZodOptional<z.ZodBoolean>;
    randomizeExceptForChoiceIds: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
}>, "strip", z.ZodTypeAny, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}>, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}>, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}>, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}>, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}> | z.ZodEffects<z.ZodEffects<z.ZodEffects<z.ZodEffects<z.ZodObject<z.extendShape<{
    id: z.ZodString;
    type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
    question: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    image: z.ZodOptional<z.ZodObject<{
        url: z.ZodString;
        style: z.ZodObject<{
            width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            maxHeight: z.ZodOptional<z.ZodNumber>;
            maxWidth: z.ZodOptional<z.ZodNumber>;
            aspectRatio: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }>;
        position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
    }, "strip", z.ZodTypeAny, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }>>;
    extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
    defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    fallbackNext: z.ZodOptional<z.ZodObject<{
        preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, "strip", z.ZodTypeAny, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }>>;
    next: z.ZodNullable<z.ZodString>;
}, {
    type: z.ZodUnion<[z.ZodLiteral<"ChoicesWithSingleAnswer">, z.ZodLiteral<"ChoicesWithMultipleAnswers">]>;
    choices: z.ZodUnion<[z.ZodString, z.ZodEffects<z.ZodArray<z.ZodString, "atleastone">, [string, ...string[]], [string, ...string[]]>]>;
    specialCasesStartId: z.ZodOptional<z.ZodArray<z.ZodTuple<[z.ZodString, z.ZodNullable<z.ZodString>], null>, "many">>;
    randomizeChoicesOrder: z.ZodOptional<z.ZodBoolean>;
    randomizeExceptForChoiceIds: z.ZodOptional<z.ZodArray<z.ZodString, "many">>;
}>, "strict", z.ZodTypeAny, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}>, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}>, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}>, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}>, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
}>, z.ZodObject<z.extendShape<{
    id: z.ZodString;
    type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
    question: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    image: z.ZodOptional<z.ZodObject<{
        url: z.ZodString;
        style: z.ZodObject<{
            width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            maxHeight: z.ZodOptional<z.ZodNumber>;
            maxWidth: z.ZodOptional<z.ZodNumber>;
            aspectRatio: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }>;
        position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
    }, "strip", z.ZodTypeAny, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }>>;
    extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
    defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    fallbackNext: z.ZodOptional<z.ZodObject<{
        preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, "strip", z.ZodTypeAny, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }>>;
    next: z.ZodNullable<z.ZodString>;
}, {
    type: z.ZodLiteral<"YesNo">;
    branchStartId: z.ZodOptional<z.ZodObject<{
        yes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        no: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, "strict", z.ZodTypeAny, {
        yes?: string | null | undefined;
        no?: string | null | undefined;
    }, {
        yes?: string | null | undefined;
        no?: string | null | undefined;
    }>>;
    addFollowupStream: z.ZodOptional<z.ZodObject<{
        yes: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        yes?: string | undefined;
    }, {
        yes?: string | undefined;
    }>>;
}>, "strict", z.ZodTypeAny, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    branchStartId?: {
        yes?: string | null | undefined;
        no?: string | null | undefined;
    } | undefined;
    addFollowupStream?: {
        yes?: string | undefined;
    } | undefined;
    type: "YesNo";
    id: string;
    question: string;
    next: string | null;
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    branchStartId?: {
        yes?: string | null | undefined;
        no?: string | null | undefined;
    } | undefined;
    addFollowupStream?: {
        yes?: string | undefined;
    } | undefined;
    type: "YesNo";
    id: string;
    question: string;
    next: string | null;
}> | z.ZodObject<z.extendShape<{
    id: z.ZodString;
    type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
    question: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    image: z.ZodOptional<z.ZodObject<{
        url: z.ZodString;
        style: z.ZodObject<{
            width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            maxHeight: z.ZodOptional<z.ZodNumber>;
            maxWidth: z.ZodOptional<z.ZodNumber>;
            aspectRatio: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }>;
        position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
    }, "strip", z.ZodTypeAny, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }>>;
    extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
    defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    fallbackNext: z.ZodOptional<z.ZodObject<{
        preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, "strip", z.ZodTypeAny, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }>>;
    next: z.ZodNullable<z.ZodString>;
}, {
    type: z.ZodLiteral<"YesNo">;
    branchStartId: z.ZodOptional<z.ZodObject<{
        yes: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        no: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, "strict", z.ZodTypeAny, {
        yes?: string | null | undefined;
        no?: string | null | undefined;
    }, {
        yes?: string | null | undefined;
        no?: string | null | undefined;
    }>>;
    addFollowupStream: z.ZodOptional<z.ZodObject<{
        yes: z.ZodOptional<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        yes?: string | undefined;
    }, {
        yes?: string | undefined;
    }>>;
}>, "strip", z.ZodTypeAny, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    branchStartId?: {
        yes?: string | null | undefined;
        no?: string | null | undefined;
    } | undefined;
    addFollowupStream?: {
        yes?: string | undefined;
    } | undefined;
    type: "YesNo";
    id: string;
    question: string;
    next: string | null;
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    branchStartId?: {
        yes?: string | null | undefined;
        no?: string | null | undefined;
    } | undefined;
    addFollowupStream?: {
        yes?: string | undefined;
    } | undefined;
    type: "YesNo";
    id: string;
    question: string;
    next: string | null;
}>, z.ZodObject<z.extendShape<{
    id: z.ZodString;
    type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
    question: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    image: z.ZodOptional<z.ZodObject<{
        url: z.ZodString;
        style: z.ZodObject<{
            width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            maxHeight: z.ZodOptional<z.ZodNumber>;
            maxWidth: z.ZodOptional<z.ZodNumber>;
            aspectRatio: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }>;
        position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
    }, "strip", z.ZodTypeAny, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }>>;
    extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
    defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    fallbackNext: z.ZodOptional<z.ZodObject<{
        preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, "strip", z.ZodTypeAny, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }>>;
    next: z.ZodNullable<z.ZodString>;
}, {
    type: z.ZodLiteral<"MultipleText">;
    indexName: z.ZodString;
    variableName: z.ZodString;
    placeholder: z.ZodOptional<z.ZodString>;
    keyboardType: z.ZodOptional<z.ZodString>;
    dropdownChoices: z.ZodOptional<z.ZodObject<{
        choices: z.ZodUnion<[z.ZodString, z.ZodEffects<z.ZodArray<z.ZodString, "atleastone">, [string, ...string[]], [string, ...string[]]>]>;
        forceChoice: z.ZodOptional<z.ZodBoolean>;
        alwaysShowChoices: z.ZodOptional<z.ZodBoolean>;
    }, "strip", z.ZodTypeAny, {
        forceChoice?: boolean | undefined;
        alwaysShowChoices?: boolean | undefined;
        choices: string | [string, ...string[]];
    }, {
        forceChoice?: boolean | undefined;
        alwaysShowChoices?: boolean | undefined;
        choices: string | [string, ...string[]];
    }>>;
    max: z.ZodNumber;
    maxMinus: z.ZodOptional<z.ZodString>;
    repeatedItemStartId: z.ZodOptional<z.ZodString>;
}>, "strict", z.ZodTypeAny, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    placeholder?: string | undefined;
    keyboardType?: string | undefined;
    dropdownChoices?: {
        forceChoice?: boolean | undefined;
        alwaysShowChoices?: boolean | undefined;
        choices: string | [string, ...string[]];
    } | undefined;
    maxMinus?: string | undefined;
    repeatedItemStartId?: string | undefined;
    type: "MultipleText";
    id: string;
    question: string;
    next: string | null;
    indexName: string;
    variableName: string;
    max: number;
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    placeholder?: string | undefined;
    keyboardType?: string | undefined;
    dropdownChoices?: {
        forceChoice?: boolean | undefined;
        alwaysShowChoices?: boolean | undefined;
        choices: string | [string, ...string[]];
    } | undefined;
    maxMinus?: string | undefined;
    repeatedItemStartId?: string | undefined;
    type: "MultipleText";
    id: string;
    question: string;
    next: string | null;
    indexName: string;
    variableName: string;
    max: number;
}> | z.ZodObject<z.extendShape<{
    id: z.ZodString;
    type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
    question: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    image: z.ZodOptional<z.ZodObject<{
        url: z.ZodString;
        style: z.ZodObject<{
            width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            maxHeight: z.ZodOptional<z.ZodNumber>;
            maxWidth: z.ZodOptional<z.ZodNumber>;
            aspectRatio: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }>;
        position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
    }, "strip", z.ZodTypeAny, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }>>;
    extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
    defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    fallbackNext: z.ZodOptional<z.ZodObject<{
        preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, "strip", z.ZodTypeAny, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }>>;
    next: z.ZodNullable<z.ZodString>;
}, {
    type: z.ZodLiteral<"MultipleText">;
    indexName: z.ZodString;
    variableName: z.ZodString;
    placeholder: z.ZodOptional<z.ZodString>;
    keyboardType: z.ZodOptional<z.ZodString>;
    dropdownChoices: z.ZodOptional<z.ZodObject<{
        choices: z.ZodUnion<[z.ZodString, z.ZodEffects<z.ZodArray<z.ZodString, "atleastone">, [string, ...string[]], [string, ...string[]]>]>;
        forceChoice: z.ZodOptional<z.ZodBoolean>;
        alwaysShowChoices: z.ZodOptional<z.ZodBoolean>;
    }, "strip", z.ZodTypeAny, {
        forceChoice?: boolean | undefined;
        alwaysShowChoices?: boolean | undefined;
        choices: string | [string, ...string[]];
    }, {
        forceChoice?: boolean | undefined;
        alwaysShowChoices?: boolean | undefined;
        choices: string | [string, ...string[]];
    }>>;
    max: z.ZodNumber;
    maxMinus: z.ZodOptional<z.ZodString>;
    repeatedItemStartId: z.ZodOptional<z.ZodString>;
}>, "strip", z.ZodTypeAny, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    placeholder?: string | undefined;
    keyboardType?: string | undefined;
    dropdownChoices?: {
        forceChoice?: boolean | undefined;
        alwaysShowChoices?: boolean | undefined;
        choices: string | [string, ...string[]];
    } | undefined;
    maxMinus?: string | undefined;
    repeatedItemStartId?: string | undefined;
    type: "MultipleText";
    id: string;
    question: string;
    next: string | null;
    indexName: string;
    variableName: string;
    max: number;
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    placeholder?: string | undefined;
    keyboardType?: string | undefined;
    dropdownChoices?: {
        forceChoice?: boolean | undefined;
        alwaysShowChoices?: boolean | undefined;
        choices: string | [string, ...string[]];
    } | undefined;
    maxMinus?: string | undefined;
    repeatedItemStartId?: string | undefined;
    type: "MultipleText";
    id: string;
    question: string;
    next: string | null;
    indexName: string;
    variableName: string;
    max: number;
}>, z.ZodObject<z.extendShape<{
    id: z.ZodString;
    type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
    question: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    image: z.ZodOptional<z.ZodObject<{
        url: z.ZodString;
        style: z.ZodObject<{
            width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            maxHeight: z.ZodOptional<z.ZodNumber>;
            maxWidth: z.ZodOptional<z.ZodNumber>;
            aspectRatio: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }>;
        position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
    }, "strip", z.ZodTypeAny, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }>>;
    extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
    defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    fallbackNext: z.ZodOptional<z.ZodObject<{
        preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, "strip", z.ZodTypeAny, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }>>;
    next: z.ZodNullable<z.ZodString>;
}, {
    type: z.ZodLiteral<"HowLongAgo">;
}>, "strict", z.ZodTypeAny, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "HowLongAgo";
    id: string;
    question: string;
    next: string | null;
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "HowLongAgo";
    id: string;
    question: string;
    next: string | null;
}> | z.ZodObject<z.extendShape<{
    id: z.ZodString;
    type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
    question: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    image: z.ZodOptional<z.ZodObject<{
        url: z.ZodString;
        style: z.ZodObject<{
            width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            maxHeight: z.ZodOptional<z.ZodNumber>;
            maxWidth: z.ZodOptional<z.ZodNumber>;
            aspectRatio: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }>;
        position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
    }, "strip", z.ZodTypeAny, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }>>;
    extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
    defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    fallbackNext: z.ZodOptional<z.ZodObject<{
        preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, "strip", z.ZodTypeAny, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }>>;
    next: z.ZodNullable<z.ZodString>;
}, {
    type: z.ZodLiteral<"HowLongAgo">;
}>, "strip", z.ZodTypeAny, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "HowLongAgo";
    id: string;
    question: string;
    next: string | null;
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "HowLongAgo";
    id: string;
    question: string;
    next: string | null;
}>, z.ZodObject<z.extendShape<{
    id: z.ZodString;
    type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
    question: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    image: z.ZodOptional<z.ZodObject<{
        url: z.ZodString;
        style: z.ZodObject<{
            width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            maxHeight: z.ZodOptional<z.ZodNumber>;
            maxWidth: z.ZodOptional<z.ZodNumber>;
            aspectRatio: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }>;
        position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
    }, "strip", z.ZodTypeAny, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }>>;
    extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
    defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    fallbackNext: z.ZodOptional<z.ZodObject<{
        preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, "strip", z.ZodTypeAny, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }>>;
    next: z.ZodNullable<z.ZodString>;
}, {
    type: z.ZodLiteral<"Branch">;
    condition: z.ZodObject<{
        questionId: z.ZodString;
        questionType: z.ZodUnion<[z.ZodLiteral<"MultipleText">, z.ZodLiteral<"ChoicesWithSingleAnswer">]>;
        compare: z.ZodLiteral<"equal">;
        target: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
    }, "strip", z.ZodTypeAny, {
        questionId: string;
        questionType: "ChoicesWithSingleAnswer" | "MultipleText";
        compare: "equal";
        target: string | number;
    }, {
        questionId: string;
        questionType: "ChoicesWithSingleAnswer" | "MultipleText";
        compare: "equal";
        target: string | number;
    }>;
    branchStartId: z.ZodObject<{
        true: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        false: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, "strip", z.ZodTypeAny, {
        true?: string | null | undefined;
        false?: string | null | undefined;
    }, {
        true?: string | null | undefined;
        false?: string | null | undefined;
    }>;
}>, "strict", z.ZodTypeAny, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "Branch";
    id: string;
    question: string;
    next: string | null;
    branchStartId: {
        true?: string | null | undefined;
        false?: string | null | undefined;
    };
    condition: {
        questionId: string;
        questionType: "ChoicesWithSingleAnswer" | "MultipleText";
        compare: "equal";
        target: string | number;
    };
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "Branch";
    id: string;
    question: string;
    next: string | null;
    branchStartId: {
        true?: string | null | undefined;
        false?: string | null | undefined;
    };
    condition: {
        questionId: string;
        questionType: "ChoicesWithSingleAnswer" | "MultipleText";
        compare: "equal";
        target: string | number;
    };
}> | z.ZodObject<z.extendShape<{
    id: z.ZodString;
    type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
    question: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    image: z.ZodOptional<z.ZodObject<{
        url: z.ZodString;
        style: z.ZodObject<{
            width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            maxHeight: z.ZodOptional<z.ZodNumber>;
            maxWidth: z.ZodOptional<z.ZodNumber>;
            aspectRatio: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }>;
        position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
    }, "strip", z.ZodTypeAny, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }>>;
    extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
    defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    fallbackNext: z.ZodOptional<z.ZodObject<{
        preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, "strip", z.ZodTypeAny, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }>>;
    next: z.ZodNullable<z.ZodString>;
}, {
    type: z.ZodLiteral<"Branch">;
    condition: z.ZodObject<{
        questionId: z.ZodString;
        questionType: z.ZodUnion<[z.ZodLiteral<"MultipleText">, z.ZodLiteral<"ChoicesWithSingleAnswer">]>;
        compare: z.ZodLiteral<"equal">;
        target: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
    }, "strip", z.ZodTypeAny, {
        questionId: string;
        questionType: "ChoicesWithSingleAnswer" | "MultipleText";
        compare: "equal";
        target: string | number;
    }, {
        questionId: string;
        questionType: "ChoicesWithSingleAnswer" | "MultipleText";
        compare: "equal";
        target: string | number;
    }>;
    branchStartId: z.ZodObject<{
        true: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        false: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, "strip", z.ZodTypeAny, {
        true?: string | null | undefined;
        false?: string | null | undefined;
    }, {
        true?: string | null | undefined;
        false?: string | null | undefined;
    }>;
}>, "strip", z.ZodTypeAny, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "Branch";
    id: string;
    question: string;
    next: string | null;
    branchStartId: {
        true?: string | null | undefined;
        false?: string | null | undefined;
    };
    condition: {
        questionId: string;
        questionType: "ChoicesWithSingleAnswer" | "MultipleText";
        compare: "equal";
        target: string | number;
    };
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "Branch";
    id: string;
    question: string;
    next: string | null;
    branchStartId: {
        true?: string | null | undefined;
        false?: string | null | undefined;
    };
    condition: {
        questionId: string;
        questionType: "ChoicesWithSingleAnswer" | "MultipleText";
        compare: "equal";
        target: string | number;
    };
}>, z.ZodObject<z.extendShape<{
    id: z.ZodString;
    type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
    question: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    image: z.ZodOptional<z.ZodObject<{
        url: z.ZodString;
        style: z.ZodObject<{
            width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            maxHeight: z.ZodOptional<z.ZodNumber>;
            maxWidth: z.ZodOptional<z.ZodNumber>;
            aspectRatio: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }>;
        position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
    }, "strip", z.ZodTypeAny, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }>>;
    extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
    defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    fallbackNext: z.ZodOptional<z.ZodObject<{
        preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, "strip", z.ZodTypeAny, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }>>;
    next: z.ZodNullable<z.ZodString>;
}, {
    type: z.ZodLiteral<"BranchWithRelativeComparison">;
    branchStartId: z.ZodRecord<z.ZodString, z.ZodNullable<z.ZodString>>;
}>, "strict", z.ZodTypeAny, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "BranchWithRelativeComparison";
    id: string;
    question: string;
    next: string | null;
    branchStartId: Record<string, string | null>;
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "BranchWithRelativeComparison";
    id: string;
    question: string;
    next: string | null;
    branchStartId: Record<string, string | null>;
}> | z.ZodObject<z.extendShape<{
    id: z.ZodString;
    type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
    question: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    image: z.ZodOptional<z.ZodObject<{
        url: z.ZodString;
        style: z.ZodObject<{
            width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            maxHeight: z.ZodOptional<z.ZodNumber>;
            maxWidth: z.ZodOptional<z.ZodNumber>;
            aspectRatio: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }>;
        position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
    }, "strip", z.ZodTypeAny, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }>>;
    extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
    defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    fallbackNext: z.ZodOptional<z.ZodObject<{
        preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, "strip", z.ZodTypeAny, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }>>;
    next: z.ZodNullable<z.ZodString>;
}, {
    type: z.ZodLiteral<"BranchWithRelativeComparison">;
    branchStartId: z.ZodRecord<z.ZodString, z.ZodNullable<z.ZodString>>;
}>, "strip", z.ZodTypeAny, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "BranchWithRelativeComparison";
    id: string;
    question: string;
    next: string | null;
    branchStartId: Record<string, string | null>;
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "BranchWithRelativeComparison";
    id: string;
    question: string;
    next: string | null;
    branchStartId: Record<string, string | null>;
}>, z.ZodObject<z.extendShape<{
    id: z.ZodString;
    type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
    question: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    image: z.ZodOptional<z.ZodObject<{
        url: z.ZodString;
        style: z.ZodObject<{
            width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            maxHeight: z.ZodOptional<z.ZodNumber>;
            maxWidth: z.ZodOptional<z.ZodNumber>;
            aspectRatio: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }>;
        position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
    }, "strip", z.ZodTypeAny, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }>>;
    extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
    defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    fallbackNext: z.ZodOptional<z.ZodObject<{
        preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, "strip", z.ZodTypeAny, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }>>;
    next: z.ZodNullable<z.ZodString>;
}, {
    type: z.ZodLiteral<"Wrapper">;
    innerNext: z.ZodString;
}>, "strict", z.ZodTypeAny, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "Wrapper";
    id: string;
    question: string;
    next: string | null;
    innerNext: string;
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "Wrapper";
    id: string;
    question: string;
    next: string | null;
    innerNext: string;
}> | z.ZodObject<z.extendShape<{
    id: z.ZodString;
    type: z.ZodEnum<["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"]>;
    question: z.ZodString;
    description: z.ZodOptional<z.ZodString>;
    image: z.ZodOptional<z.ZodObject<{
        url: z.ZodString;
        style: z.ZodObject<{
            width: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            height: z.ZodUnion<[z.ZodNumber, z.ZodString]>;
            maxHeight: z.ZodOptional<z.ZodNumber>;
            maxWidth: z.ZodOptional<z.ZodNumber>;
            aspectRatio: z.ZodOptional<z.ZodNumber>;
        }, "strip", z.ZodTypeAny, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }, {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        }>;
        position: z.ZodUnion<[z.ZodLiteral<"inDescriptionBox">, z.ZodLiteral<"left">]>;
    }, "strip", z.ZodTypeAny, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }, {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    }>>;
    extraCustomNextWithoutAnsweringButton: z.ZodOptional<z.ZodString>;
    defaultPlaceholderValues: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    fallbackNext: z.ZodOptional<z.ZodObject<{
        preferNotToAnswer: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        nextWithoutAnswering: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, "strip", z.ZodTypeAny, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }, {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    }>>;
    next: z.ZodNullable<z.ZodString>;
}, {
    type: z.ZodLiteral<"Wrapper">;
    innerNext: z.ZodString;
}>, "strip", z.ZodTypeAny, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "Wrapper";
    id: string;
    question: string;
    next: string | null;
    innerNext: string;
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "Wrapper";
    id: string;
    question: string;
    next: string | null;
    innerNext: string;
}>]>, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    minimumValue?: number | undefined;
    maximumValue?: number | undefined;
    step?: number | undefined;
    defaultValue?: number | undefined;
    defaultValueFromQuestionId?: string | undefined;
    displayCurrentValueToUser?: boolean | undefined;
    type: "Slider";
    id: string;
    question: string;
    next: string | null;
    slider: [string, string];
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    branchStartId?: {
        yes?: string | null | undefined;
        no?: string | null | undefined;
    } | undefined;
    addFollowupStream?: {
        yes?: string | undefined;
    } | undefined;
    type: "YesNo";
    id: string;
    question: string;
    next: string | null;
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    placeholder?: string | undefined;
    keyboardType?: string | undefined;
    dropdownChoices?: {
        forceChoice?: boolean | undefined;
        alwaysShowChoices?: boolean | undefined;
        choices: string | [string, ...string[]];
    } | undefined;
    maxMinus?: string | undefined;
    repeatedItemStartId?: string | undefined;
    type: "MultipleText";
    id: string;
    question: string;
    next: string | null;
    indexName: string;
    variableName: string;
    max: number;
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "HowLongAgo";
    id: string;
    question: string;
    next: string | null;
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "Branch";
    id: string;
    question: string;
    next: string | null;
    branchStartId: {
        true?: string | null | undefined;
        false?: string | null | undefined;
    };
    condition: {
        questionId: string;
        questionType: "ChoicesWithSingleAnswer" | "MultipleText";
        compare: "equal";
        target: string | number;
    };
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "BranchWithRelativeComparison";
    id: string;
    question: string;
    next: string | null;
    branchStartId: Record<string, string | null>;
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "Wrapper";
    id: string;
    question: string;
    next: string | null;
    innerNext: string;
}, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    minimumValue?: number | undefined;
    maximumValue?: number | undefined;
    step?: number | undefined;
    defaultValue?: number | undefined;
    defaultValueFromQuestionId?: string | undefined;
    displayCurrentValueToUser?: boolean | undefined;
    type: "Slider";
    id: string;
    question: string;
    next: string | null;
    slider: [string, string];
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    branchStartId?: {
        yes?: string | null | undefined;
        no?: string | null | undefined;
    } | undefined;
    addFollowupStream?: {
        yes?: string | undefined;
    } | undefined;
    type: "YesNo";
    id: string;
    question: string;
    next: string | null;
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    placeholder?: string | undefined;
    keyboardType?: string | undefined;
    dropdownChoices?: {
        forceChoice?: boolean | undefined;
        alwaysShowChoices?: boolean | undefined;
        choices: string | [string, ...string[]];
    } | undefined;
    maxMinus?: string | undefined;
    repeatedItemStartId?: string | undefined;
    type: "MultipleText";
    id: string;
    question: string;
    next: string | null;
    indexName: string;
    variableName: string;
    max: number;
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "HowLongAgo";
    id: string;
    question: string;
    next: string | null;
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "Branch";
    id: string;
    question: string;
    next: string | null;
    branchStartId: {
        true?: string | null | undefined;
        false?: string | null | undefined;
    };
    condition: {
        questionId: string;
        questionType: "ChoicesWithSingleAnswer" | "MultipleText";
        compare: "equal";
        target: string | number;
    };
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "BranchWithRelativeComparison";
    id: string;
    question: string;
    next: string | null;
    branchStartId: Record<string, string | null>;
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "Wrapper";
    id: string;
    question: string;
    next: string | null;
    innerNext: string;
}>>, Record<string, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    minimumValue?: number | undefined;
    maximumValue?: number | undefined;
    step?: number | undefined;
    defaultValue?: number | undefined;
    defaultValueFromQuestionId?: string | undefined;
    displayCurrentValueToUser?: boolean | undefined;
    type: "Slider";
    id: string;
    question: string;
    next: string | null;
    slider: [string, string];
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    branchStartId?: {
        yes?: string | null | undefined;
        no?: string | null | undefined;
    } | undefined;
    addFollowupStream?: {
        yes?: string | undefined;
    } | undefined;
    type: "YesNo";
    id: string;
    question: string;
    next: string | null;
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    placeholder?: string | undefined;
    keyboardType?: string | undefined;
    dropdownChoices?: {
        forceChoice?: boolean | undefined;
        alwaysShowChoices?: boolean | undefined;
        choices: string | [string, ...string[]];
    } | undefined;
    maxMinus?: string | undefined;
    repeatedItemStartId?: string | undefined;
    type: "MultipleText";
    id: string;
    question: string;
    next: string | null;
    indexName: string;
    variableName: string;
    max: number;
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "HowLongAgo";
    id: string;
    question: string;
    next: string | null;
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "Branch";
    id: string;
    question: string;
    next: string | null;
    branchStartId: {
        true?: string | null | undefined;
        false?: string | null | undefined;
    };
    condition: {
        questionId: string;
        questionType: "ChoicesWithSingleAnswer" | "MultipleText";
        compare: "equal";
        target: string | number;
    };
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "BranchWithRelativeComparison";
    id: string;
    question: string;
    next: string | null;
    branchStartId: Record<string, string | null>;
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "Wrapper";
    id: string;
    question: string;
    next: string | null;
    innerNext: string;
}>, Record<string, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    minimumValue?: number | undefined;
    maximumValue?: number | undefined;
    step?: number | undefined;
    defaultValue?: number | undefined;
    defaultValueFromQuestionId?: string | undefined;
    displayCurrentValueToUser?: boolean | undefined;
    type: "Slider";
    id: string;
    question: string;
    next: string | null;
    slider: [string, string];
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    branchStartId?: {
        yes?: string | null | undefined;
        no?: string | null | undefined;
    } | undefined;
    addFollowupStream?: {
        yes?: string | undefined;
    } | undefined;
    type: "YesNo";
    id: string;
    question: string;
    next: string | null;
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    placeholder?: string | undefined;
    keyboardType?: string | undefined;
    dropdownChoices?: {
        forceChoice?: boolean | undefined;
        alwaysShowChoices?: boolean | undefined;
        choices: string | [string, ...string[]];
    } | undefined;
    maxMinus?: string | undefined;
    repeatedItemStartId?: string | undefined;
    type: "MultipleText";
    id: string;
    question: string;
    next: string | null;
    indexName: string;
    variableName: string;
    max: number;
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "HowLongAgo";
    id: string;
    question: string;
    next: string | null;
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "Branch";
    id: string;
    question: string;
    next: string | null;
    branchStartId: {
        true?: string | null | undefined;
        false?: string | null | undefined;
    };
    condition: {
        questionId: string;
        questionType: "ChoicesWithSingleAnswer" | "MultipleText";
        compare: "equal";
        target: string | number;
    };
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "BranchWithRelativeComparison";
    id: string;
    question: string;
    next: string | null;
    branchStartId: Record<string, string | null>;
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "Wrapper";
    id: string;
    question: string;
    next: string | null;
    innerNext: string;
}>>, Record<string, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    minimumValue?: number | undefined;
    maximumValue?: number | undefined;
    step?: number | undefined;
    defaultValue?: number | undefined;
    defaultValueFromQuestionId?: string | undefined;
    displayCurrentValueToUser?: boolean | undefined;
    type: "Slider";
    id: string;
    question: string;
    next: string | null;
    slider: [string, string];
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    branchStartId?: {
        yes?: string | null | undefined;
        no?: string | null | undefined;
    } | undefined;
    addFollowupStream?: {
        yes?: string | undefined;
    } | undefined;
    type: "YesNo";
    id: string;
    question: string;
    next: string | null;
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    placeholder?: string | undefined;
    keyboardType?: string | undefined;
    dropdownChoices?: {
        forceChoice?: boolean | undefined;
        alwaysShowChoices?: boolean | undefined;
        choices: string | [string, ...string[]];
    } | undefined;
    maxMinus?: string | undefined;
    repeatedItemStartId?: string | undefined;
    type: "MultipleText";
    id: string;
    question: string;
    next: string | null;
    indexName: string;
    variableName: string;
    max: number;
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "HowLongAgo";
    id: string;
    question: string;
    next: string | null;
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "Branch";
    id: string;
    question: string;
    next: string | null;
    branchStartId: {
        true?: string | null | undefined;
        false?: string | null | undefined;
    };
    condition: {
        questionId: string;
        questionType: "ChoicesWithSingleAnswer" | "MultipleText";
        compare: "equal";
        target: string | number;
    };
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "BranchWithRelativeComparison";
    id: string;
    question: string;
    next: string | null;
    branchStartId: Record<string, string | null>;
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "Wrapper";
    id: string;
    question: string;
    next: string | null;
    innerNext: string;
}>, Record<string, {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    minimumValue?: number | undefined;
    maximumValue?: number | undefined;
    step?: number | undefined;
    defaultValue?: number | undefined;
    defaultValueFromQuestionId?: string | undefined;
    displayCurrentValueToUser?: boolean | undefined;
    type: "Slider";
    id: string;
    question: string;
    next: string | null;
    slider: [string, string];
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    specialCasesStartId?: [string, string | null][] | undefined;
    randomizeChoicesOrder?: boolean | undefined;
    randomizeExceptForChoiceIds?: string[] | undefined;
    type: "ChoicesWithSingleAnswer" | "ChoicesWithMultipleAnswers";
    id: string;
    question: string;
    next: string | null;
    choices: string | [string, ...string[]];
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    branchStartId?: {
        yes?: string | null | undefined;
        no?: string | null | undefined;
    } | undefined;
    addFollowupStream?: {
        yes?: string | undefined;
    } | undefined;
    type: "YesNo";
    id: string;
    question: string;
    next: string | null;
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    placeholder?: string | undefined;
    keyboardType?: string | undefined;
    dropdownChoices?: {
        forceChoice?: boolean | undefined;
        alwaysShowChoices?: boolean | undefined;
        choices: string | [string, ...string[]];
    } | undefined;
    maxMinus?: string | undefined;
    repeatedItemStartId?: string | undefined;
    type: "MultipleText";
    id: string;
    question: string;
    next: string | null;
    indexName: string;
    variableName: string;
    max: number;
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "HowLongAgo";
    id: string;
    question: string;
    next: string | null;
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "Branch";
    id: string;
    question: string;
    next: string | null;
    branchStartId: {
        true?: string | null | undefined;
        false?: string | null | undefined;
    };
    condition: {
        questionId: string;
        questionType: "ChoicesWithSingleAnswer" | "MultipleText";
        compare: "equal";
        target: string | number;
    };
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "BranchWithRelativeComparison";
    id: string;
    question: string;
    next: string | null;
    branchStartId: Record<string, string | null>;
} | {
    description?: string | undefined;
    image?: {
        url: string;
        style: {
            maxHeight?: number | undefined;
            maxWidth?: number | undefined;
            aspectRatio?: number | undefined;
            width: string | number;
            height: string | number;
        };
        position: "inDescriptionBox" | "left";
    } | undefined;
    extraCustomNextWithoutAnsweringButton?: string | undefined;
    defaultPlaceholderValues?: Record<string, any> | undefined;
    fallbackNext?: {
        preferNotToAnswer?: string | null | undefined;
        nextWithoutAnswering?: string | null | undefined;
    } | undefined;
    type: "Wrapper";
    id: string;
    question: string;
    next: string | null;
    innerNext: string;
}>>>;
export declare const StreamsStartingQuestionIdsSchema: z.ZodRecord<z.ZodString, z.ZodString>;
