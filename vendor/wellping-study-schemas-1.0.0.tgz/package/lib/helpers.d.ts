import { QuestionTypeType } from "./types";
export declare const QuestionType: {
    Slider: "Slider";
    ChoicesWithSingleAnswer: "ChoicesWithSingleAnswer";
    ChoicesWithMultipleAnswers: "ChoicesWithMultipleAnswers";
    YesNo: "YesNo";
    MultipleText: "MultipleText";
    HowLongAgo: "HowLongAgo";
    Branch: "Branch";
    BranchWithRelativeComparison: "BranchWithRelativeComparison";
    Wrapper: "Wrapper";
};
export declare const QUESTION_TYPES: ["Slider", "ChoicesWithSingleAnswer", "ChoicesWithMultipleAnswers", "YesNo", "MultipleText", "HowLongAgo", "Branch", "BranchWithRelativeComparison", "Wrapper"];
export declare const NON_USER_QUESTION_TYPES: QuestionTypeType[];
