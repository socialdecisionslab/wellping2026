export declare const ID_REGEX: RegExp;
export declare const idRegexErrorMessage: (name: string) => string;
export declare const QUESTION_ID_REGEX: RegExp;
export declare const questionIdRegexErrorMessage: (name: string) => string;
export declare const DATETIME_REGEX: RegExp;
export declare const datetimeRegexErrorMessage: (name?: string) => string;
export declare const HOURMINUTESECOND_REGEX: RegExp;
export declare const hourMinuteSecondRegexErrorMessage: (name?: string) => string;
